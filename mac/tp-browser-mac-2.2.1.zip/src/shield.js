'use strict';
/*
 * TP Shield: blocks ads and trackers.
 * - Network blocking of well-known ad, analytics and tracking domains
 *   (only when they are third-party to the page you're on).
 * - Hides leftover empty ad boxes.
 * - Speeds through and skips YouTube video ads.
 */

const { rootDomain } = require('./util');

const DOMAINS = [
  // Google ads & analytics
  'doubleclick.net', 'googlesyndication.com', 'googleadservices.com', 'google-analytics.com',
  'googletagmanager.com', 'googletagservices.com', 'adservice.google.com', 'analytics.google.com',
  'app-measurement.com', '2mdn.net', 'admob.com', 'googleoptimize.com',
  // Amazon, Microsoft, Yahoo
  'amazon-adsystem.com', 'bat.bing.com', 'clarity.ms', 'ads.yahoo.com', 'analytics.yahoo.com',
  'advertising.com', 'adtechus.com',
  // Social trackers (third-party only)
  'ads-twitter.com', 'analytics.twitter.com', 'ads.linkedin.com', 'px.ads.linkedin.com', 'snap.licdn.com',
  'ct.pinterest.com', 'tr.snapchat.com', 'analytics.tiktok.com', 'events.redditmedia.com',
  // Ad exchanges & networks
  'adnxs.com', 'adsrvr.org', 'criteo.com', 'criteo.net', 'taboola.com', 'taboolasyndication.com',
  'outbrain.com', 'outbrainimg.com', 'rubiconproject.com', 'pubmatic.com', 'openx.net', 'casalemedia.com',
  'indexww.com', 'smartadserver.com', 'adform.net', 'yieldmo.com', 'sharethrough.com', 'triplelift.com',
  '33across.com', 'media.net', 'contextweb.com', 'sovrn.com', 'lijit.com', 'gumgum.com', 'teads.tv',
  'adcolony.com', 'applovin.com', 'unityads.unity3d.com', 'inmobi.com', 'mopub.com', 'vungle.com',
  'chartboost.com', 'revcontent.com', 'mgid.com', 'zergnet.com', 'propellerads.com', 'popads.net',
  'popcash.net', 'adsterra.com', 'exoclick.com', 'juicyads.com', 'trafficjunky.net', 'hilltopads.net',
  'a-ads.com', 'adskeeper.com', 'adblade.com', 'bidswitch.net', 'spotxchange.com', 'spotx.tv',
  'springserve.com', 'lkqd.net', 'smaato.net', 'bidr.io', 'adroll.com', 'perfectaudience.com',
  'yieldlab.net', 'adition.com', 'serving-sys.com', 'flashtalking.com', 'innovid.com', 'tremorhub.com',
  'zemanta.com', 'adzerk.net', 'carbonads.com', 'carbonads.net', 'buysellads.com', 'onclickads.net',
  'adsco.re', 'admixer.net', 'districtm.io', 'emxdgt.com', 'undertone.com', 'kargo.com', 'improvedigital.com',
  '360yield.com', 'adhigh.net', 'adkernel.com', 'adpushup.com', 'ezoic.net', 'amxrtb.com',
  'yandexadexchange.net', 'adfox.ru', 'mookie1.com', 'nativo.com', 'connatix.com', 'primis.tech',
  'vidazoo.com', 'aniview.com', 'sekindo.com', 'playwire.com', 'freestar.io', 'pubnation.com',
  // Measurement, data brokers & verification
  'scorecardresearch.com', 'quantserve.com', 'quantcount.com', 'imrworldwide.com', 'moatads.com',
  'adsafeprotected.com', 'doubleverify.com', 'rlcdn.com', 'bluekai.com', 'krxd.net', 'exelator.com',
  'demdex.net', 'everesttech.net', 'omtrdc.net', '2o7.net', 'mathtag.com', 'turn.com', 'agkn.com',
  'crwdcntrl.net', 'tapad.com', 'liadm.com', 'rfihub.com', 'eyeota.net', 'adsymptotic.com',
  'bounceexchange.com', 'bouncex.net', 'id5-sync.com', 'zeotap.com', 'semasio.net', 'lotame.com',
  'adlightning.com', 'confiant-integrations.net', 'permutive.com', 'permutive.app',
  // Analytics & session recording
  'chartbeat.com', 'chartbeat.net', 'hotjar.com', 'hotjar.io', 'mouseflow.com', 'fullstory.com',
  'crazyegg.com', 'luckyorange.com', 'luckyorange.net', 'inspectlet.com', 'clicktale.net',
  'contentsquare.net', 'nr-data.net', 'js-agent.newrelic.com', 'cdn.segment.com', 'api.segment.io',
  'mixpanel.com', 'mxpnl.com', 'api.amplitude.com', 'cdn.amplitude.com', 'heapanalytics.com',
  'kissmetrics.com', 'statcounter.com', 'histats.com', 'hs-analytics.net', 'track.hubspot.com',
  'mc.yandex.ru', 'mc.yandex.com', 'hm.baidu.com', 'cnzz.com', 'truehits.net', 'addthis.com',
  'addthisedge.com', 'sharethis.com', 'gemius.pl', 'webtrends.com', 'pingdom.net',
  'getclicky.com', 'woopra.com', 'smartlook.com', 'logrocket.io', 'mouseflow.net', 'quantummetric.com',
];

const SET = new Set(DOMAINS);

// A few trackers that live on otherwise useful domains.
const PATH_RULES = [
  /^https?:\/\/(www\.)?facebook\.com\/tr\b/i,
  /^https?:\/\/connect\.facebook\.net\/[^/]+\/fbevents\.js/i,
  /^https?:\/\/connect\.facebook\.net\/signals\//i,
  /^https?:\/\/(www\.)?google\.[a-z.]+\/pagead\//i,
  /^https?:\/\/(www\.)?youtube\.com\/(api\/stats\/ads|pagead\/|ptracking)/i,
];

function isTrackerHost(host) {
  let h = String(host || '').toLowerCase();
  while (h) {
    if (SET.has(h)) return true;
    const dot = h.indexOf('.');
    if (dot === -1) return false;
    h = h.slice(dot + 1);
  }
  return false;
}

/** Should a request from a page on `pageHost` to `url` be blocked? */
function shouldBlock(url, requestHost, pageHost) {
  if (pageHost && rootDomain(requestHost) === rootDomain(pageHost)) {
    // First-party requests are allowed, except a couple of ad endpoints.
    return /youtube\.com$/.test(pageHost) && PATH_RULES[4].test(url);
  }
  if (isTrackerHost(requestHost)) return true;
  return PATH_RULES.some((re) => re.test(url));
}

// Hide the empty boxes ads leave behind. Kept conservative so pages don't break.
const COSMETIC_CSS = `
ins.adsbygoogle, .adsbygoogle, [id^="google_ads_iframe"], [id^="div-gpt-ad"], [data-google-query-id],
iframe[src*="doubleclick.net"], iframe[src*="googlesyndication.com"], iframe[id^="google_ads_"],
[id^="taboola-"], .trc_rbox_container, .OUTBRAIN, amp-ad, amp-embed[type="taboola"], amp-embed[type="outbrain"],
[data-ad-slot], [data-ad-unit-path], .adsbox, .ad-slot, .adslot, .ad-banner, .advertisement,
ytd-ad-slot-renderer, ytd-in-feed-ad-layout-renderer, ytd-promoted-sparkles-web-renderer, ytd-promoted-video-renderer,
ytd-display-ad-renderer, ytd-banner-promo-renderer, ytd-statement-banner-renderer, ytd-player-legacy-desktop-watch-ads-renderer,
#masthead-ad, #player-ads, .ytd-companion-slot-renderer, ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-ads"],
ytd-rich-item-renderer:has(ytd-ad-slot-renderer), ytd-rich-section-renderer:has(ytd-statement-banner-renderer),
.ytp-ad-overlay-container, .ytp-ad-message-container
{ display: none !important; }
`;

// Runs in an isolated world on youtube.com: mutes, fast-forwards and skips video ads.
const YT_SKIPPER = `(() => {
  if (window.__tpYtSkipper) return;
  window.__tpYtSkipper = true;
  const SKIP = '.ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button, .ytp-ad-skip-button-slot button, .ytp-ad-overlay-close-button';
  let inAd = false;
  let rate = 1;
  let muted = false;
  const tick = () => {
    const player = document.querySelector('#movie_player, .html5-video-player');
    if (!player) return;
    const video = player.querySelector('video');
    const ad = player.classList.contains('ad-showing') || player.classList.contains('ad-interrupting');
    if (ad && video) {
      if (!inAd) {
        inAd = true;
        rate = video.playbackRate && video.playbackRate !== 16 ? video.playbackRate : 1;
        muted = video.muted;
      }
      video.muted = true;
      if (video.playbackRate !== 16) video.playbackRate = 16;
      if (Number.isFinite(video.duration) && video.duration > 0 && video.currentTime < video.duration - 0.25) {
        video.currentTime = Math.max(0, video.duration - 0.1);
      }
      document.querySelectorAll(SKIP).forEach((b) => b.click());
    } else if (inAd) {
      inAd = false;
      if (video) {
        video.playbackRate = rate;
        video.muted = muted;
      }
    }
  };
  setInterval(tick, 250);
})();`;

module.exports = { DOMAINS, isTrackerHost, shouldBlock, COSMETIC_CSS, YT_SKIPPER };
