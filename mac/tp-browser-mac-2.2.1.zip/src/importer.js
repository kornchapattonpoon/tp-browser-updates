'use strict';
// Finds bookmarks from other Chromium-based browsers on this Mac so you can bring them over.

const fs = require('fs');
const path = require('path');
const { parseChromiumBookmarks } = require('./util');

const BROWSERS = [
  { key: 'chrome', name: 'Google Chrome', dir: 'Google/Chrome' },
  { key: 'brave', name: 'Brave', dir: 'BraveSoftware/Brave-Browser' },
  { key: 'edge', name: 'Microsoft Edge', dir: 'Microsoft Edge' },
  { key: 'arc', name: 'Arc', dir: 'Arc/User Data' },
  { key: 'vivaldi', name: 'Vivaldi', dir: 'Vivaldi' },
  { key: 'opera', name: 'Opera', dir: 'com.operasoftware.Opera' },
  { key: 'chromium', name: 'Chromium', dir: 'Chromium' },
];

function bookmarkFiles(base) {
  const files = [];
  try {
    const rootFile = path.join(base, 'Bookmarks');
    if (fs.existsSync(rootFile)) files.push(rootFile);
    for (const name of fs.readdirSync(base)) {
      if (name === 'Default' || /^Profile \d+$/.test(name)) {
        const f = path.join(base, name, 'Bookmarks');
        if (fs.existsSync(f)) files.push(f);
      }
    }
  } catch {
    // Browser not installed.
  }
  return files;
}

function readBrowser(appSupportDir, key) {
  const b = BROWSERS.find((x) => x.key === key);
  if (!b) return [];
  const seen = new Set();
  const out = [];
  for (const file of bookmarkFiles(path.join(appSupportDir, b.dir))) {
    let list = [];
    try {
      list = parseChromiumBookmarks(fs.readFileSync(file, 'utf8'));
    } catch {
      list = [];
    }
    for (const item of list) {
      if (seen.has(item.url)) continue;
      seen.add(item.url);
      out.push(item);
    }
  }
  return out;
}

/** Browsers that have at least one bookmark to import. */
function detect(appSupportDir) {
  return BROWSERS.map((b) => ({ key: b.key, name: b.name, count: readBrowser(appSupportDir, b.key).length })).filter(
    (b) => b.count > 0
  );
}

module.exports = { BROWSERS, detect, readBrowser };
