'use strict';
/*
 * In-app updates for TP Browser on the Mac. Reads mac/latest.json from TP's update repository,
 * downloads the new TP Browser code (a zip), checks its SHA-256, unpacks it into
 * ~/Library/Application Support/TP Browser/app-updates/<version>/ and asks you to restart.
 * boot.js runs the newest version on the next start. Your tabs, settings and data are untouched.
 */
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { execFile } = require('child_process');

const KEEP_FROM_APP = ['src/ui/build.js'];

function versionCode(v) {
  const p = String(v || '').split('.').map((n) => parseInt(n, 10) || 0);
  return (p[0] || 0) * 10000 + (p[1] || 0) * 100 + (p[2] || 0);
}

function allowedUrl(url) {
  try {
    const u = new URL(url);
    return u.protocol === 'https:' && (u.hostname === 'raw.githubusercontent.com' || u.hostname === 'github.com' || u.hostname.endsWith('.githubusercontent.com'));
  } catch {
    return false;
  }
}

function sha256File(file) {
  return new Promise((resolve, reject) => {
    const h = crypto.createHash('sha256');
    fs.createReadStream(file)
      .on('data', (d) => h.update(d))
      .on('error', reject)
      .on('end', () => resolve(h.digest('hex')));
  });
}

function unzip(zip, dest) {
  return new Promise((resolve, reject) => {
    execFile('/usr/bin/ditto', ['-x', '-k', zip, dest], (err) => (err ? reject(err) : resolve()));
  });
}

/**
 * opts: { feedUrl, userData, codeVersion, electronVersion, builtInDir, fetch(url) -> Response, onChange(state) }
 * state: { state: 'idle'|'checking'|'downloading'|'ready'|'uptodate'|'failed'|'rebuild', version, notes, p, message, checkedAt }
 */
function createUpdater(opts) {
  const dir = path.join(opts.userData, 'app-updates');
  let state = { state: 'idle', checkedAt: 0 };
  let busy = false;

  const set = (patch) => {
    state = Object.assign({}, state, patch);
    if (opts.onChange) opts.onChange(state);
  };

  async function readFeed() {
    const url = opts.feedUrl + (opts.feedUrl.includes('?') ? '&' : '?') + 't=' + Math.floor(Date.now() / 60000);
    const res = await opts.fetch(url);
    // No Mac updates published yet: nothing newer to get.
    if (res.status === 404) return null;
    if (!res.ok) throw new Error('feed ' + res.status);
    const info = JSON.parse(await res.text());
    if (!info || !info.version || !info.zip || !info.sha256) throw new Error('bad feed');
    return info;
  }

  async function download(info) {
    if (!allowedUrl(info.zip)) throw new Error('Updates only come from TP Browser’s GitHub');
    fs.mkdirSync(dir, { recursive: true });
    const zip = path.join(dir, 'download.zip');
    const res = await opts.fetch(info.zip);
    if (!res.ok || !res.body) throw new Error('Download failed (' + res.status + ')');
    const total = Number(res.headers.get('content-length')) || 0;
    const out = fs.createWriteStream(zip);
    let got = 0;
    let lastPct = -1;
    const reader = res.body.getReader();
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      got += value.length;
      if (got > 150 * 1024 * 1024) throw new Error('Update is too large');
      if (!out.write(Buffer.from(value))) await new Promise((r) => out.once('drain', r));
      const pct = total ? Math.floor((got * 100) / total) : -1;
      if (pct !== lastPct && pct % 10 === 0) {
        lastPct = pct;
        set({ p: pct });
      }
    }
    await new Promise((resolve, reject) => out.end((err) => (err ? reject(err) : resolve())));
    const sum = await sha256File(zip);
    if (sum.toLowerCase() !== String(info.sha256).toLowerCase()) {
      fs.rmSync(zip, { force: true });
      throw new Error('The download was damaged. It will try again later.');
    }
    const version = String(info.version).replace(/[^0-9.]/g, '');
    const tmp = path.join(dir, 'unpacking');
    fs.rmSync(tmp, { recursive: true, force: true });
    fs.mkdirSync(tmp, { recursive: true });
    await (opts.unzip || unzip)(zip, tmp);
    fs.rmSync(zip, { force: true });
    // The zip holds package.json and src/ (possibly inside one top folder).
    let root = tmp;
    if (!fs.existsSync(path.join(root, 'package.json'))) {
      const inner = fs.readdirSync(tmp).find((n) => fs.existsSync(path.join(tmp, n, 'package.json')));
      if (inner) root = path.join(tmp, inner);
    }
    const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
    if (pkg.version !== info.version || !fs.existsSync(path.join(root, 'src', 'main.js'))) throw new Error('That isn’t a TP Browser update');
    // Files that only exist in the installed app (TP AI's built-in key) are carried over.
    if (opts.builtInDir) {
      for (const rel of KEEP_FROM_APP) {
        const from = path.join(opts.builtInDir, rel);
        const to = path.join(root, rel);
        if (!fs.existsSync(to) && fs.existsSync(from)) fs.copyFileSync(from, to);
      }
    }
    const final = path.join(dir, version);
    fs.rmSync(final, { recursive: true, force: true });
    fs.renameSync(root, final);
    fs.rmSync(tmp, { recursive: true, force: true });
    fs.writeFileSync(path.join(dir, 'current.json'), JSON.stringify({ version: info.version, installedAt: Date.now() }));
    // Keep only the new version and the one running now.
    for (const name of fs.readdirSync(dir)) {
      if (/^\d+\.\d+\.\d+$/.test(name) && name !== version && name !== opts.codeVersion) fs.rmSync(path.join(dir, name), { recursive: true, force: true });
    }
  }

  async function check({ manual = false, autoDownload = true } = {}) {
    if (busy) return state;
    busy = true;
    try {
      set({ state: 'checking', message: '' });
      const info = await readFeed();
      const checkedAt = Date.now();
      if (!info || versionCode(info.version) <= versionCode(opts.codeVersion)) {
        set({ state: 'uptodate', checkedAt, version: info ? info.version : opts.codeVersion });
        return state;
      }
      const needs = Number(info.minElectron) || 0;
      const have = parseInt(String(opts.electronVersion || '0'), 10) || 0;
      if (needs && have < needs) {
        set({ state: 'rebuild', checkedAt, version: info.version, notes: info.notes || [], message: 'This update needs a newer engine. Run “Update TP Browser” on this Mac.' });
        return state;
      }
      const current = (() => {
        try {
          return JSON.parse(fs.readFileSync(path.join(dir, 'current.json'), 'utf8'));
        } catch {
          return null;
        }
      })();
      if (current && current.version === info.version && fs.existsSync(path.join(dir, info.version, 'src', 'main.js'))) {
        set({ state: 'ready', checkedAt, version: info.version, notes: info.notes || [] });
        return state;
      }
      if (!autoDownload && !manual) {
        set({ state: 'available', checkedAt, version: info.version, notes: info.notes || [] });
        return state;
      }
      set({ state: 'downloading', checkedAt, version: info.version, notes: info.notes || [], p: 0 });
      await download(info);
      set({ state: 'ready', p: 100 });
    } catch (err) {
      set({ state: 'failed', message: String((err && err.message) || err).slice(0, 200), checkedAt: Date.now() });
    } finally {
      busy = false;
    }
    return state;
  }

  /** Called once TP Browser has shown its window: the version that's running works. */
  function startedOk() {
    try {
      fs.rmSync(path.join(dir, 'booting.json'), { force: true });
    } catch {
      // fine
    }
  }

  return { check, startedOk, getState: () => state, versionCode };
}

module.exports = { createUpdater, versionCode, allowedUrl };
