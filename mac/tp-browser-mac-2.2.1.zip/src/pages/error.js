'use strict';
(function () {
  const $ = (s) => document.querySelector(s);
  const params = new URLSearchParams(location.search);
  const code = params.get('code') || '';
  const desc = params.get('desc') || '';
  const rawUrl = params.get('url') || '';

  // Only ever link back to normal web pages or local files.
  const safeUrl = /^(https?|file):/i.test(rawUrl) ? rawUrl : '';
  let host = '';
  try {
    host = new URL(safeUrl).host;
  } catch {
    host = '';
  }

  const ICONS = {
    offline:
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M2 8.8a15 15 0 0 1 4.2-2.6"/><path d="M10.6 5.1A15 15 0 0 1 22 8.8"/><path d="M5 12.5a10 10 0 0 1 5.2-2.4"/><path d="M15.5 10.7A10 10 0 0 1 19 12.5"/><path d="M8.5 16a5 5 0 0 1 7 0"/><path d="M12 20h.01"/><path d="M3 3l18 18"/></svg>',
    lock:
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="10.5" width="14" height="10" rx="2.5"/><path d="M8.5 10.5V7.5a3.5 3.5 0 0 1 7 0v3"/><path d="M12 14.5v2"/></svg>',
    crash:
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M8.5 15.5c1.8-1.6 5.2-1.6 7 0"/><path d="M8 9.5l2 1.5M16 9.5l-2 1.5"/></svg>',
    search:
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/><path d="M9 9l4 4M13 9l-4 4"/></svg>',
  };

  const n = Number(code);
  let view = {
    icon: 'search',
    title: 'This page couldn’t load',
    message: host ? `Something went wrong loading <strong></strong>.` : 'Something went wrong loading this page.',
    tips: ['Check your internet connection', 'Try again in a moment'],
  };

  if (code === 'crashed') {
    view = {
      icon: 'crash',
      title: 'Aw, this tab crashed',
      message: 'The page stopped working. Reloading usually fixes it.',
      tips: ['If it keeps happening, close some other tabs to free up memory'],
    };
  } else if (n === -106) {
    view = {
      icon: 'offline',
      title: 'You’re offline',
      message: 'Your Mac isn’t connected to the internet.',
      tips: ['Check your Wi-Fi or network cable', 'Turn Wi-Fi off and on again'],
    };
  } else if (n === -105 || n === -137) {
    view = {
      icon: 'search',
      title: 'This site can’t be found',
      message: host ? 'TP Browser couldn’t find <strong></strong>.' : 'TP Browser couldn’t find that address.',
      tips: ['Check the address for typos', 'Check your internet connection'],
    };
  } else if (n === -102 || n === -118 || n === -109 || n === -7 || n === -100 || n === -101) {
    view = {
      icon: 'search',
      title: 'This site can’t be reached',
      message: host ? '<strong></strong> took too long to respond or refused to connect.' : 'The site took too long to respond.',
      tips: ['Try again in a moment', 'Check your internet connection'],
    };
  } else if (n <= -200 && n > -300) {
    view = {
      icon: 'lock',
      title: 'Your connection isn’t private',
      message: host
        ? 'The security certificate for <strong></strong> isn’t valid, so TP Browser stopped loading it to protect your information.'
        : 'This site’s security certificate isn’t valid.',
      tips: ['Check that your Mac’s date and time are correct', 'If you’re on public Wi-Fi, try signing in to the network first'],
    };
  }

  document.title = view.title;
  $('#icon').innerHTML = ICONS[view.icon];
  $('#title').textContent = view.title;

  // Build the message without ever injecting the URL as HTML.
  const msg = $('#message');
  const parts = view.message.split('<strong></strong>');
  msg.textContent = parts[0];
  if (parts.length > 1) {
    const strong = document.createElement('strong');
    strong.textContent = host;
    msg.append(strong, document.createTextNode(parts[1]));
  }

  for (const tip of view.tips) {
    const li = document.createElement('li');
    li.textContent = tip;
    $('#tips').append(li);
  }

  $('#code').textContent = [desc, code && code !== 'crashed' ? `(${code})` : ''].filter(Boolean).join(' ');

  const retry = $('#retry');
  if (safeUrl) retry.addEventListener('click', () => location.replace(safeUrl));
  else retry.hidden = true;
})();
