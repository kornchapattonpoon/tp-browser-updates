'use strict';
(function () {
  const api = window.tpInternal;
  const $ = (s) => document.querySelector(s);
  const raw = new URLSearchParams(location.search).get('url') || '';
  const target = /^https?:\/\//i.test(raw) ? raw : '';
  let host = '';
  try {
    host = new URL(target).hostname.replace(/^www\./, '');
  } catch {
    host = 'This site';
  }
  $('#site').textContent = host;
  document.title = `${host} is paused`;
  const LINES = [
    'You’ve got this. Future you will be grateful.',
    'Small steps, done now, add up fast.',
    'Stay with it, the hardest part is starting.',
    'One task at a time. You’re doing great.',
  ];
  const line = LINES[Math.floor(Math.random() * LINES.length)];
  const C = 326.7;

  async function tick() {
    if (!api) return;
    const { focus } = await api.focusStatus();
    if (!focus) {
      document.body.classList.add('done');
      $('#time').textContent = '🎉';
      $('#bar').style.strokeDashoffset = '0';
      $('#title').textContent = 'Focus session complete!';
      $('#msg').textContent = 'Nice work. Take a break, you earned it.';
      $('#end').hidden = true;
      $('#go').hidden = !target;
      $('#go').textContent = `Continue to ${host}`;
      return;
    }
    const left = Math.max(0, focus.endsAt - Date.now());
    const total = focus.endsAt - focus.startedAt;
    $('#time').textContent = `${Math.floor(left / 60000)}:${String(Math.floor((left % 60000) / 1000)).padStart(2, '0')}`;
    $('#bar').style.strokeDashoffset = String(C * (1 - left / total));
    $('#title').textContent = 'Stay focused';
    if (!$('#msg').dataset.set) {
      $('#msg').dataset.set = '1';
      $('#msg').textContent = '';
      const b = document.createElement('span');
      b.className = 'site';
      b.textContent = host;
      $('#msg').append(b, document.createTextNode(` is paused until your session ends. ${line}`));
    }
    setTimeout(tick, 1000);
  }

  $('#end').addEventListener('click', async () => {
    if (!confirm('End your focus session early?')) return;
    await api.endFocus();
    tick();
  });
  $('#go').addEventListener('click', () => {
    if (target) location.replace(target);
  });
  tick();
})();
