'use strict';
(function () {
  const api = window.tpInternal;
  const $ = (s) => document.querySelector(s);

  const hostOf = (url) => {
    try {
      return new URL(url).host.replace(/^www\./, '');
    } catch {
      return url;
    }
  };
  const colorFor = (text) => {
    let h = 0;
    for (const ch of text) h = (h * 31 + ch.charCodeAt(0)) % 360;
    return `hsl(${h} 55% 52%)`;
  };

  function dayLabel(ts) {
    const d = new Date(ts);
    const today = new Date();
    const startOf = (x) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
    const diff = Math.round((startOf(today) - startOf(d)) / 86400000);
    const full = d.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
    if (diff === 0) return `Today — ${full}`;
    if (diff === 1) return `Yesterday — ${full}`;
    return full;
  }

  async function render() {
    const list = $('#list');
    if (!api) return;
    const entries = await api.getHistory($('#filter').value);
    list.replaceChildren();
    if (!entries.length) {
      const p = document.createElement('p');
      p.className = 'empty';
      p.textContent = $('#filter').value ? 'No history matches your search.' : 'Pages you visit will show up here.';
      list.append(p);
      return;
    }

    let currentDay = '';
    let group = null;
    for (const h of entries) {
      const label = dayLabel(h.time);
      if (label !== currentDay) {
        currentDay = label;
        const heading = document.createElement('div');
        heading.className = 'day';
        heading.textContent = label;
        group = document.createElement('div');
        group.className = 'group';
        list.append(heading, group);
      }

      const a = document.createElement('a');
      a.className = 'item';
      a.href = h.url;
      a.title = h.url;

      const time = document.createElement('time');
      time.textContent = new Date(h.time).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });

      const host = hostOf(h.url);
      const letter = document.createElement('span');
      letter.className = 'letter';
      letter.textContent = host.charAt(0).toUpperCase();
      letter.style.background = colorFor(host);

      const text = document.createElement('span');
      text.className = 'text';
      const title = document.createElement('span');
      title.className = 'title';
      title.textContent = h.title || host;
      const hostEl = document.createElement('span');
      hostEl.className = 'host';
      hostEl.textContent = host;
      text.append(title, hostEl);

      const del = document.createElement('button');
      del.className = 'del';
      del.title = 'Remove from history';
      del.textContent = '×';
      del.addEventListener('click', async (e) => {
        e.preventDefault();
        e.stopPropagation();
        await api.deleteHistory(h.id);
        a.remove();
      });

      a.addEventListener('click', (e) => {
        e.preventDefault();
        api.open({ kind: 'history', url: h.url }, { newTab: e.metaKey || e.ctrlKey });
      });

      a.append(time, letter, text, del);
      group.append(a);
    }
  }

  let timer;
  $('#filter').addEventListener('input', () => {
    clearTimeout(timer);
    timer = setTimeout(render, 150);
  });

  $('#clear').addEventListener('click', async () => {
    if (!confirm('Clear all browsing history?')) return;
    await api.clearHistory();
    render();
  });

  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) render();
  });

  render();
})();
