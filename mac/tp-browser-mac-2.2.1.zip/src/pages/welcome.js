'use strict';
(function () {
  const api = window.tpInternal;
  const $ = (s) => document.querySelector(s);
  const steps = [...document.querySelectorAll('.step')];
  let step = 0;
  let s = null;

  function setAccent(colors) {
    document.documentElement.style.setProperty('--c1', colors[0]);
    document.documentElement.style.setProperty('--c2', colors[1]);
  }

  function show(i) {
    step = Math.max(0, Math.min(steps.length - 1, i));
    steps.forEach((el, j) => (el.hidden = j !== step));
    $('#dots').replaceChildren(
      ...steps.map((_, j) => {
        const d = document.createElement('i');
        if (j === step) d.className = 'on';
        return d;
      })
    );
    const input = steps[step].querySelector('input');
    if (input) setTimeout(() => input.focus(), 50);
    if (step === 2) loadBrowsers();
    if (step === 4) $('#done-title').textContent = s && s.name ? `You’re all set, ${s.name}!` : 'You’re all set!';
  }

  async function saveName() {
    const name = $('#name').value.trim();
    if (name && api) s = { ...s, ...(await api.set('name', name)) };
  }

  document.querySelectorAll('.next').forEach((b) =>
    b.addEventListener('click', async () => {
      if (step === 0) await saveName();
      show(step + 1);
    })
  );
  document.querySelectorAll('.back').forEach((b) => b.addEventListener('click', () => show(step - 1)));
  $('#name').addEventListener('keydown', async (e) => {
    if (e.key === 'Enter') {
      await saveName();
      show(1);
    }
  });

  function renderColors() {
    const personal = s.spaces[0];
    setAccent(personal.colors);
    $('#colors').replaceChildren(
      ...Object.entries(s.spaceColors).map(([key, [c1, c2]]) => {
        const b = document.createElement('button');
        b.title = key;
        b.className = personal.color === key ? 'on' : '';
        b.style.background = `linear-gradient(135deg, ${c1}, ${c2})`;
        b.onclick = async () => {
          s = { ...s, ...(await api.updateSpace(personal.id, { color: key })) };
          renderColors();
        };
        return b;
      })
    );
    document.querySelectorAll('#appearance button').forEach((b) => {
      b.classList.toggle('on', b.dataset.v === s.appearance);
      b.onclick = async () => {
        s = { ...s, ...(await api.set('appearance', b.dataset.v)) };
        renderColors();
      };
    });
  }

  let browsersLoaded = false;
  async function loadBrowsers() {
    if (browsersLoaded || !api) return;
    browsersLoaded = true;
    const list = await api.detectBrowsers();
    const box = $('#browsers');
    box.replaceChildren();
    if (!list.length) {
      const m = document.createElement('div');
      m.className = 'muted';
      m.textContent = 'No other browsers with bookmarks found. You can import later in Settings.';
      box.append(m);
      return;
    }
    for (const b of list) {
      const row = document.createElement('div');
      row.className = 'browser';
      const info = document.createElement('div');
      const name = document.createElement('b');
      name.textContent = b.name;
      const sm = document.createElement('small');
      sm.textContent = `${b.count} bookmark${b.count === 1 ? '' : 's'}`;
      info.append(name, sm);
      const btn = document.createElement('button');
      btn.className = 'btn';
      btn.textContent = 'Import';
      btn.onclick = async () => {
        btn.disabled = true;
        btn.textContent = 'Importing…';
        const r = await api.importFrom(b.key);
        sm.textContent = r.added ? `✅ Imported ${r.added} bookmark${r.added === 1 ? '' : 's'}` : '✅ Already imported';
        btn.textContent = 'Done';
      };
      row.append(info, btn);
      box.append(row);
    }
  }

  $('#make-default').addEventListener('click', async () => {
    await api.makeDefault();
    $('#default-note').textContent = 'If macOS asks, choose “Use TP Browser”.';
    setTimeout(async () => {
      if (await api.isDefault()) show(4);
    }, 2500);
  });

  $('#finish').addEventListener('click', () => api && api.finishOnboarding());

  async function load() {
    s = await api.getSettings();
    $('#name').value = s.name || '';
    renderColors();
    if (s.isDefault) {
      $('#make-default').textContent = '✅ Already your default';
      $('#make-default').disabled = true;
    }
    show(0);
  }
  if (api) load();
  else show(0);
})();
