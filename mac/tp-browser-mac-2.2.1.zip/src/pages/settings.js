'use strict';
(function () {
  const api = window.tpInternal;
  const $ = (s) => document.querySelector(s);
  let s = null;

  const WALLPAPERS = [
    ['space', 'Space colors'],
    ['aurora', 'Aurora'],
    ['sunset', 'Sunset'],
    ['ocean', 'Ocean'],
    ['forest', 'Forest'],
    ['midnight', 'Midnight'],
    ['custom', 'Your photo'],
  ];

  let toastTimer;
  function toast(text) {
    const t = $('#toast');
    t.textContent = text;
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (t.hidden = true), 2600);
  }

  async function set(key, value) {
    s = { ...s, ...(await api.set(key, value)) };
    render();
  }

  function applyAccent() {
    const first = s.spaces && s.spaces[0];
    if (!first) return;
    document.documentElement.style.setProperty('--c1', first.colors[0]);
    document.documentElement.style.setProperty('--c2', first.colors[1]);
  }

  function renderSeg(id, value, onPick) {
    const seg = $(id);
    seg.querySelectorAll('button').forEach((b) => {
      b.classList.toggle('on', b.dataset.v === value);
      b.onclick = () => onPick(b.dataset.v);
    });
  }

  function renderWallpapers() {
    const box = $('#wallpapers');
    box.replaceChildren(
      ...WALLPAPERS.map(([key, label]) => {
        const b = document.createElement('button');
        b.className = 'swatch' + (s.wallpaper === key ? ' on' : '');
        const prev = document.createElement('span');
        prev.className = 'prev ' + key;
        if (key === 'custom') {
          if (s.hasCustomWallpaper) prev.style.backgroundImage = `url("tp://newtab/wallpaper?v=${s.wallpaperVersion}")`;
          else prev.textContent = '＋';
        }
        const l = document.createElement('span');
        l.textContent = key === 'custom' && s.hasCustomWallpaper ? 'Your photo (change…)' : label;
        b.append(prev, l);
        b.onclick = async () => {
          if (key === 'custom' && (!s.hasCustomWallpaper || s.wallpaper === 'custom')) {
            s = { ...s, ...(await api.chooseWallpaper()) };
            render();
          } else set('wallpaper', key);
        };
        return b;
      })
    );
  }

  function renderSpaces() {
    const list = $('#space-list');
    list.replaceChildren(
      ...s.spaces.map((sp) => {
        const row = document.createElement('div');
        row.className = 'space-row';
        const icon = document.createElement('select');
        icon.className = 'icon';
        for (const e of new Set([sp.icon, ...s.spaceIcons])) {
          const o = document.createElement('option');
          o.value = o.textContent = e;
          o.selected = e === sp.icon;
          icon.append(o);
        }
        icon.onchange = async () => {
          s = { ...s, ...(await api.updateSpace(sp.id, { icon: icon.value })) };
          render();
        };
        const name = document.createElement('input');
        name.type = 'text';
        name.value = sp.name;
        name.maxLength = 24;
        name.onchange = async () => {
          if (!name.value.trim()) return;
          s = { ...s, ...(await api.updateSpace(sp.id, { name: name.value })) };
          render();
        };
        const colors = document.createElement('div');
        colors.className = 'colors';
        for (const [key, [c1, c2]] of Object.entries(s.spaceColors)) {
          const c = document.createElement('button');
          c.className = 'color' + (sp.color === key ? ' on' : '');
          c.title = key;
          c.style.background = `linear-gradient(135deg, ${c1}, ${c2})`;
          c.onclick = async () => {
            s = { ...s, ...(await api.updateSpace(sp.id, { color: key })) };
            render();
          };
          colors.append(c);
        }
        const del = document.createElement('button');
        del.className = 'del';
        del.textContent = '×';
        del.title = 'Delete space';
        del.disabled = s.spaces.length <= 1;
        del.onclick = async () => {
          s = { ...s, ...(await api.deleteSpace(sp.id)) };
          render();
        };
        row.append(icon, name, colors, del);
        return row;
      })
    );
  }

  function renderAllowList() {
    const box = $('#allow-list');
    box.replaceChildren();
    if (!s.shieldAllow.length) {
      const e = document.createElement('span');
      e.className = 'empty';
      e.textContent = 'None. Shield is on everywhere.';
      box.append(e);
      return;
    }
    for (const host of s.shieldAllow) {
      const chip = document.createElement('span');
      chip.className = 'chip';
      chip.textContent = host;
      const x = document.createElement('button');
      x.textContent = '×';
      x.title = `Turn Shield back on for ${host}`;
      x.onclick = () => set('shieldAllow', s.shieldAllow.filter((h) => h !== host));
      chip.append(x);
      box.append(chip);
    }
  }

  function render() {
    applyAccent();
    if (document.activeElement !== $('#name')) $('#name').value = s.name || '';
    const se = $('#searchEngine');
    se.replaceChildren(
      ...s.searchEngines.map((e) => {
        const o = document.createElement('option');
        o.value = e.key;
        o.textContent = e.name;
        o.selected = e.key === s.searchEngine;
        return o;
      })
    );
    document.querySelectorAll('.switch[data-key]').forEach((sw) => {
      sw.checked = !!s[sw.dataset.key];
    });
    $('#aiControl').checked = !(s.ai && s.ai.control === false);
    $('#speechRate').value = String(Number(s.speechRate) || 1);
    renderDarkExcept();
    renderUpdate(s.update);
    renderSeg('#appearance', s.appearance, (v) => set('appearance', v));
    renderSeg('#tempUnit', s.tempUnit, (v) => set('tempUnit', v));
    renderWallpapers();
    renderSpaces();
    renderAllowList();
    $('#focusMinutes').value = String(s.focusMinutes);
    if (document.activeElement !== $('#focusSites')) $('#focusSites').value = (s.focusSites || []).join('\n');
    $('#sleepAfter').value = String(s.sleepAfter);
    $('#city-current').textContent = s.city ? `${s.city.name}${s.city.region && s.city.region !== s.city.name ? ', ' + s.city.region : ''}${s.city.country ? ', ' + s.city.country : ''}` : 'Not set';
    if (s.stats) $('#blocked-week').textContent = s.stats.blockedWeek.toLocaleString('en');
    if (s.shieldCount) $('#shield-count').textContent = `Blocks ${s.shieldCount} known ad networks and trackers so pages load faster and follow you less.`;
    if (s.version) {
      $('#version').textContent = s.version;
      $('#engine').textContent = `Chromium ${s.chromium} · Electron ${s.electron}`;
    }
    $('#default-status').textContent = s.isDefault ? '✅ TP Browser is your default browser.' : 'Open links from other apps in TP Browser.';
    $('#make-default').hidden = !!s.isDefault;
  }

  // ---------- Controls ----------
  $('#name').addEventListener('change', (e) => set('name', e.target.value));
  $('#searchEngine').addEventListener('change', (e) => set('searchEngine', e.target.value));
  document.querySelectorAll('.switch[data-key]').forEach((sw) => sw.addEventListener('change', () => set(sw.dataset.key, sw.checked)));
  $('#speechRate').addEventListener('change', (e) => set('speechRate', Number(e.target.value)));
  $('#aiControl').addEventListener('change', async (e) => {
    await api.setAiControl(e.target.checked);
    s.ai = { control: e.target.checked };
    toast(e.target.checked ? 'TP AI can control the browser' : 'TP AI will only chat and read pages');
  });
  $('#clear-ai').addEventListener('click', async () => {
    await api.clearAiChat();
    toast('TP AI chat cleared');
  });

  // ---------- Updates ----------
  function ago(t) {
    if (!t) return '';
    const m = Math.round((Date.now() - t) / 60000);
    if (m < 1) return 'just now';
    if (m < 60) return m + ' min ago';
    const h = Math.round(m / 60);
    return h < 24 ? h + ' hr ago' : Math.round(h / 24) + ' days ago';
  }

  let updPoll = null;
  function renderUpdate(u) {
    if (!u) return;
    $('#upd-title').textContent = 'TP Browser ' + (u.current || s.version || '');
    const st = u.state;
    const msg = {
      checking: 'Checking for updates…',
      downloading: 'Downloading ' + (u.version || 'the update') + '…' + (u.p > 0 ? ' ' + u.p + '%' : ''),
      ready: '✨ Version ' + u.version + ' is ready. Restart to finish (your tabs come back).',
      uptodate: '✅ You have the latest version' + (u.checkedAt ? ' · checked ' + ago(u.checkedAt) : ''),
      failed: 'Couldn’t check: ' + (u.message || 'no connection') + '. It will try again later.',
      rebuild: u.message || 'This update needs a fresh install.',
      available: 'Version ' + u.version + ' is available.',
    }[st] || (u.lastCheck ? 'Last checked ' + ago(u.lastCheck) : 'TP Browser checks for updates every few hours.');
    $('#upd-status').textContent = msg;
    $('#upd-restart').hidden = st !== 'ready';
    $('#upd-check').hidden = st === 'ready';
    $('#upd-check').disabled = st === 'checking' || st === 'downloading';
    const bar = $('#upd-bar');
    bar.hidden = st !== 'downloading';
    bar.firstElementChild.style.transform = 'scaleX(' + Math.max(0.04, (u.p || 0) / 100) + ')';
    const notes = $('#upd-notes');
    const list = (st === 'ready' || st === 'available' || st === 'downloading' || st === 'rebuild') && Array.isArray(u.notes) ? u.notes : [];
    notes.replaceChildren(...list.slice(0, 10).map((n) => Object.assign(document.createElement('li'), { textContent: String(n) })));
    notes.hidden = !list.length;
    clearTimeout(updPoll);
    if (st === 'checking' || st === 'downloading') {
      updPoll = setTimeout(async () => {
        s.update = await api.updateState();
        renderUpdate(s.update);
      }, 700);
    }
  }
  $('#upd-check').addEventListener('click', async () => {
    renderUpdate({ ...(s.update || {}), state: 'checking' });
    s.update = await api.checkUpdates();
    renderUpdate(s.update);
  });
  $('#upd-restart').addEventListener('click', () => api.restartToUpdate());

  // ---------- Sites kept light ----------
  function renderDarkExcept() {
    const box = $('#dark-except');
    box.replaceChildren();
    const list = s.darkExcept || [];
    if (!list.length) {
      const e = document.createElement('span');
      e.className = 'empty';
      e.textContent = s.darkPages ? 'None. Dark mode is on for every site.' : 'Turn on dark mode to use this.';
      box.append(e);
      return;
    }
    for (const host of list) {
      const chip = document.createElement('span');
      chip.className = 'chip';
      chip.textContent = host;
      const x = document.createElement('button');
      x.textContent = '×';
      x.title = `Make ${host} dark too`;
      x.onclick = () => set('darkExcept', list.filter((h) => h !== host));
      chip.append(x);
      box.append(chip);
    }
  }
  $('#focusMinutes').addEventListener('change', (e) => set('focusMinutes', Number(e.target.value)));
  $('#sleepAfter').addEventListener('change', (e) => set('sleepAfter', Number(e.target.value)));
  $('#save-sites').addEventListener('click', async () => {
    const lines = $('#focusSites').value.split(/[\n,]+/).map((x) => x.trim()).filter(Boolean);
    await set('focusSites', lines);
    $('#focusSites').value = s.focusSites.join('\n');
    $('#sites-saved').textContent = `Saved ${s.focusSites.length} site${s.focusSites.length === 1 ? '' : 's'}`;
    setTimeout(() => ($('#sites-saved').textContent = ''), 2500);
  });
  $('#add-space').addEventListener('click', async () => {
    s = { ...s, ...(await api.addSpace()) };
    render();
  });
  $('#make-default').addEventListener('click', async () => {
    await api.makeDefault();
    setTimeout(async () => {
      s.isDefault = await api.isDefault();
      render();
    }, 2500);
  });
  $('#clear-data').addEventListener('click', async () => {
    if (await api.clearData()) toast('Browsing data cleared');
  });

  // City search
  let cityTimer;
  $('#city-search').addEventListener('input', (e) => {
    clearTimeout(cityTimer);
    const q = e.target.value;
    cityTimer = setTimeout(async () => {
      const results = q.trim().length >= 2 ? await api.searchCity(q) : [];
      const box = $('#city-results');
      box.replaceChildren(
        ...results.map((c) => {
          const b = document.createElement('button');
          b.className = 'city';
          b.textContent = c.name;
          const sm = document.createElement('small');
          sm.textContent = [c.region, c.country].filter(Boolean).join(', ');
          b.append(sm);
          b.onclick = async () => {
            await set('city', c);
            box.replaceChildren();
            $('#city-search').value = '';
            toast(`Weather set to ${c.name}`);
          };
          return b;
        })
      );
      if (!results.length && q.trim().length >= 2) {
        const n = document.createElement('small');
        n.textContent = 'No cities found (or you’re offline).';
        box.append(n);
      }
    }, 300);
  });

  // Import
  async function renderBrowsers() {
    const box = $('#browsers');
    const list = await api.detectBrowsers();
    box.replaceChildren();
    if (!list.length) {
      const d = document.createElement('div');
      d.className = 'item';
      d.innerHTML = '<div><b>No other browsers found</b><small>Chrome, Brave, Edge, Arc, Vivaldi and Opera bookmarks can be imported when they’re installed on this Mac.</small></div>';
      box.append(d);
      return;
    }
    for (const b of list) {
      const row = document.createElement('div');
      row.className = 'item';
      const info = document.createElement('div');
      const name = document.createElement('b');
      name.textContent = b.name;
      const sm = document.createElement('small');
      sm.textContent = `${b.count} bookmark${b.count === 1 ? '' : 's'}`;
      info.append(name, sm);
      const btn = document.createElement('button');
      btn.className = 'btn';
      btn.textContent = 'Import';
      btn.onclick = async () => {
        btn.disabled = true;
        btn.textContent = 'Importing…';
        const r = await api.importFrom(b.key);
        sm.textContent = r.added ? `✅ Imported ${r.added} new bookmark${r.added === 1 ? '' : 's'}` : '✅ Already up to date';
        btn.textContent = 'Done';
      };
      row.append(info, btn);
      box.append(row);
    }
  }

  // Highlight the section in view
  const links = [...document.querySelectorAll('nav a')];
  const observer = new IntersectionObserver(
    (entries) => {
      for (const e of entries) {
        if (e.isIntersecting) links.forEach((a) => a.classList.toggle('on', a.getAttribute('href') === '#' + e.target.id));
      }
    },
    { rootMargin: '-20% 0px -70% 0px' }
  );
  document.querySelectorAll('section').forEach((sec) => observer.observe(sec));

  function goToHash() {
    const id = location.hash.slice(1);
    const target = id && document.getElementById(id);
    if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  window.addEventListener('hashchange', goToHash);

  async function load() {
    s = await api.getSettings();
    render();
    renderBrowsers();
    setTimeout(goToHash, 50);
  }
  document.addEventListener('visibilitychange', async () => {
    if (!document.hidden && s) {
      s = { ...s, ...(await api.getSettings()) };
      render();
    }
  });
  if (api) load();
})();
