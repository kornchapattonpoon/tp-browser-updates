'use strict';
/* TP Home: greeting, search, weather, air quality, focus, shield stats, favorites, quick note. */
(function () {
  const api = window.tpInternal;
  const $ = (s) => document.querySelector(s);

  const DEFAULT_SHORTCUTS = [
    { title: 'Google', url: 'https://www.google.com/' },
    { title: 'YouTube', url: 'https://www.youtube.com/' },
    { title: 'Wikipedia', url: 'https://www.wikipedia.org/' },
    { title: 'GitHub', url: 'https://github.com/' },
    { title: 'Gmail', url: 'https://mail.google.com/' },
    { title: 'Maps', url: 'https://www.google.com/maps' },
  ];

  let home = null;
  let suggestions = [];
  let sel = 0;
  let seq = 0;

  const hostOf = (url) => {
    try {
      return new URL(url).hostname.replace(/^www\./, '');
    } catch {
      return '';
    }
  };
  const colorFor = (text) => {
    let h = 0;
    for (const ch of String(text)) h = (h * 31 + ch.charCodeAt(0)) % 360;
    return `hsl(${h} 58% 52%)`;
  };
  const letter = (name) => {
    const s = document.createElement('span');
    s.className = 'letter';
    s.textContent = (name || '?').charAt(0).toUpperCase();
    s.style.background = colorFor(name || '?');
    return s;
  };
  const fmtMinutes = (m) => (m >= 60 ? `${Math.floor(m / 60)}h ${m % 60 ? (m % 60) + 'm' : ''}`.trim() : `${m} min`);

  // ---------- Clock & greeting ----------
  const hourCycle = new Intl.DateTimeFormat(undefined, { hour: 'numeric' }).resolvedOptions().hourCycle || 'h23';
  const timeFmt = new Intl.DateTimeFormat('en', { hour: 'numeric', minute: '2-digit', hourCycle });
  function tick() {
    const now = new Date();
    const parts = timeFmt.formatToParts(now);
    const main = parts.filter((x) => x.type !== 'dayPeriod').map((x) => x.value).join('').trim();
    const period = (parts.find((x) => x.type === 'dayPeriod') || {}).value || '';
    const clock = $('#clock');
    clock.textContent = main;
    if (period) {
      const small = document.createElement('span');
      small.className = 'ampm';
      small.textContent = period.toLowerCase();
      clock.append(small);
    }
    $('#date').textContent = now.toLocaleDateString('en', { weekday: 'long', month: 'long', day: 'numeric' });
    const h = now.getHours();
    const part = h < 5 ? 'Up late' : h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : h < 21 ? 'Good evening' : 'Good night';
    const name = home && home.name ? `, ${home.name}` : '';
    $('#greeting').textContent = `${part}${name}`;
  }

  // ---------- Theme / wallpaper ----------
  function applyLook() {
    const s = home.settings;
    const [c1, c2] = home.space.colors;
    document.documentElement.style.setProperty('--c1', c1);
    document.documentElement.style.setProperty('--c2', c2);
    const wp = s.wallpaper === 'custom' && !s.hasCustomWallpaper ? 'space' : s.wallpaper || 'space';
    document.body.className = '';
    document.body.classList.add('wp-' + wp);
    if (wp !== 'space') document.body.classList.add('vivid');
    const wall = $('#wall');
    wall.style.backgroundImage = wp === 'custom' ? `url("tp://newtab/wallpaper?v=${s.wallpaperVersion}")` : '';
    $('#q').placeholder = `Search ${s.searchEngineName} or type a URL`;
    $('#made').textContent = `${home.space.icon} ${home.space.name} space · TP Browser`;
  }

  // ---------- Weather & air quality ----------
  const WX = {
    0: ['☀️', 'Clear sky', '🌙'],
    1: ['🌤️', 'Mostly clear', '🌙'],
    2: ['⛅', 'Partly cloudy'],
    3: ['☁️', 'Cloudy'],
    45: ['🌫️', 'Foggy'],
    48: ['🌫️', 'Foggy'],
    51: ['🌦️', 'Light drizzle'],
    53: ['🌦️', 'Drizzle'],
    55: ['🌧️', 'Heavy drizzle'],
    56: ['🌧️', 'Freezing drizzle'],
    57: ['🌧️', 'Freezing drizzle'],
    61: ['🌦️', 'Light rain'],
    63: ['🌧️', 'Rain'],
    65: ['🌧️', 'Heavy rain'],
    66: ['🌧️', 'Freezing rain'],
    67: ['🌧️', 'Freezing rain'],
    71: ['🌨️', 'Light snow'],
    73: ['🌨️', 'Snow'],
    75: ['❄️', 'Heavy snow'],
    77: ['🌨️', 'Snow grains'],
    80: ['🌦️', 'Showers'],
    81: ['🌧️', 'Rain showers'],
    82: ['⛈️', 'Heavy showers'],
    85: ['🌨️', 'Snow showers'],
    86: ['🌨️', 'Snow showers'],
    95: ['⛈️', 'Thunderstorm'],
    96: ['⛈️', 'Thunderstorm, hail'],
    99: ['⛈️', 'Thunderstorm, hail'],
  };

  const AQI = [
    [50, 'Good', '#16a34a', 'Great air today. Enjoy being outside!'],
    [100, 'Moderate', '#ca8a04', 'Fine for most people. Sensitive groups take it easy outdoors.'],
    [150, 'Unhealthy for some', '#ea580c', 'Sensitive groups should limit long outdoor activity.'],
    [200, 'Unhealthy', '#dc2626', 'Wear a mask outside and keep outdoor time short.'],
    [300, 'Very unhealthy', '#9333ea', 'Avoid going outside if you can and close windows.'],
    [Infinity, 'Hazardous', '#7f1d1d', 'Stay indoors with windows closed.'],
  ];

  async function loadWeather() {
    const s = home.settings;
    $('#aq-city').textContent = s.city ? `· ${s.city.name}` : '';
    const data = api ? await api.weather() : null;
    if (!data) {
      $('#wx-desc').textContent = 'Weather unavailable';
      $('#wx-more').textContent = 'Check your connection';
      $('#aq-badge').textContent = 'Offline';
      return;
    }
    const unit = data.unit === 'F' ? '°F' : '°';
    if (data.weather) {
      const w = data.weather;
      const [emoji, label, night] = WX[w.code] || ['🌡️', 'Weather'];
      $('#wx-emoji').textContent = !w.isDay && night ? night : emoji;
      $('#wx-temp').textContent = `${Math.round(w.temp)}${unit}`;
      $('#wx-desc').textContent = `${label} · ${data.city.name}`;
      const parts = [];
      if (w.feels != null) parts.push(`Feels ${Math.round(w.feels)}°`);
      if (w.high != null && w.low != null) parts.push(`H ${Math.round(w.high)}° L ${Math.round(w.low)}°`);
      if (w.rain != null) parts.push(`☔ ${w.rain}%`);
      $('#wx-more').textContent = parts.join(' · ');
    }
    if (data.air && data.air.aqi != null) {
      const a = data.air;
      const level = AQI.find(([max]) => a.aqi <= max);
      $('#aq-num').textContent = Math.round(a.aqi);
      const badge = $('#aq-badge');
      badge.textContent = level[1];
      badge.style.background = level[2];
      $('#aq-pm').textContent = a.pm25 != null ? `PM2.5 ${Math.round(a.pm25)} µg/m³${a.pm10 != null ? ` · PM10 ${Math.round(a.pm10)}` : ''}` : '';
      $('#aq-tip').textContent = level[3];
    } else {
      $('#aq-badge').textContent = 'No data';
    }
  }

  // ---------- Focus ----------
  let focusTimer = null;
  function renderFocus() {
    const f = home.focus;
    clearInterval(focusTimer);
    $('#focus-idle').hidden = !!f;
    $('#focus-live').hidden = !f;
    $('#focus-today').textContent = fmtMinutes(home.stats.focusToday);
    const streak = Number(home.stats.focusStreak) || 0;
    $('#focus-week').textContent = streak >= 2
      ? `🔥 ${streak}-day streak · ${fmtMinutes(home.stats.focusWeek)} this week`
      : home.stats.focusWeek ? `${fmtMinutes(home.stats.focusWeek)} this week` : 'Block distractions and get stuff done';
    const len = $('#focus-len');
    if (!len.dataset.touched) len.value = String(home.settings.focusMinutes);
    if (![...len.options].some((o) => o.value === len.value)) {
      const o = document.createElement('option');
      o.value = o.textContent = String(home.settings.focusMinutes);
      len.append(o);
      len.value = o.value;
    }
    $('#focus-start').textContent = `Start ${len.value} min`;
    if (!f) return;
    const update = () => {
      const left = Math.max(0, f.endsAt - Date.now());
      $('#focus-left').textContent = `${Math.floor(left / 60000)}:${String(Math.floor((left % 60000) / 1000)).padStart(2, '0')}`;
      const total = f.endsAt - f.startedAt;
      $('#focus-bar').style.width = `${Math.min(100, ((total - left) / total) * 100)}%`;
      if (left <= 0) {
        clearInterval(focusTimer);
        setTimeout(load, 1500);
      }
    };
    update();
    focusTimer = setInterval(update, 1000);
  }
  $('#focus-len').addEventListener('change', (e) => {
    e.target.dataset.touched = '1';
    $('#focus-start').textContent = `Start ${e.target.value} min`;
  });
  $('#focus-start').addEventListener('click', async () => {
    if (!api) return;
    await api.startFocus(Number($('#focus-len').value));
    load();
  });

  // ---------- Shield ----------
  function renderShield() {
    $('#sh-week').textContent = home.stats.blockedWeek.toLocaleString('en');
    $('#sh-today').textContent = home.settings.shield
      ? `${home.stats.blockedToday.toLocaleString('en')} today · pages load faster`
      : 'Shield is off. Turn it on in Settings.';
  }

  // ---------- Favorites ----------
  function renderTiles() {
    const tiles = $('#tiles');
    tiles.replaceChildren();
    const usingFavs = home.favorites && home.favorites.length > 0;
    $('#fav-title').textContent = usingFavs ? 'Favorites' : 'Shortcuts';
    const list = usingFavs ? home.favorites : DEFAULT_SHORTCUTS;
    for (const item of list) {
      const a = document.createElement('a');
      a.className = 'tile';
      a.href = item.url;
      a.title = `${item.title}\n${item.url}`;
      const ic = document.createElement('span');
      ic.className = 'ic';
      const host = hostOf(item.url);
      if (item.favicon) {
        const img = new Image();
        img.alt = '';
        img.src = item.favicon;
        img.onerror = () => img.replaceWith(letter(host || item.title));
        ic.append(img);
      } else ic.append(letter(host || item.title));
      const label = document.createElement('span');
      label.className = 'label2';
      label.textContent = item.title || host;
      a.append(ic, label);
      a.addEventListener('click', (e) => {
        if (!api) return;
        e.preventDefault();
        api.open({ kind: 'bookmark', url: item.url }, { newTab: e.metaKey });
      });
      tiles.append(a);
    }
  }

  // ---------- Search with suggestions ----------
  const box = $('#suggest');
  function renderSuggest() {
    box.replaceChildren();
    box.hidden = !suggestions.length || !$('#q').value.trim();
    suggestions.forEach((s, i) => {
      const row = document.createElement('div');
      row.className = 'sg' + (i === sel ? ' sel' : '');
      const ic = document.createElement('span');
      ic.className = 'ic';
      if (s.icon) {
        const img = new Image();
        img.src = s.icon;
        img.alt = '';
        img.onerror = () => {
          ic.textContent = '🌐';
        };
        ic.append(img);
      } else ic.textContent = s.kind === 'search' || s.kind === 'suggest' ? '🔍' : s.kind === 'tab' ? '🗂️' : '🌐';
      const t = document.createElement('span');
      t.className = 't';
      t.textContent = s.title;
      const sub = document.createElement('span');
      sub.className = 's';
      sub.textContent = s.kind === 'tab' ? 'Switch to tab' : s.subtitle || '';
      row.append(ic, t, sub);
      row.addEventListener('mousedown', (e) => {
        e.preventDefault();
        go(i, e.metaKey);
      });
      row.addEventListener('mousemove', () => {
        if (sel !== i) {
          sel = i;
          box.querySelectorAll('.sg').forEach((r, j) => r.classList.toggle('sel', j === sel));
        }
      });
      box.append(row);
    });
  }

  async function updateSuggest() {
    const text = $('#q').value;
    const my = ++seq;
    if (!api || !text.trim()) {
      suggestions = [];
      renderSuggest();
      return;
    }
    const local = await api.suggest(text);
    if (my !== seq) return;
    suggestions = (local || []).slice(0, 7);
    sel = 0;
    renderSuggest();
    const remote = await api.remoteSuggest(text);
    if (my !== seq || !remote || !remote.length) return;
    const seen = new Set(suggestions.map((s) => s.url));
    suggestions = [...suggestions.slice(0, 2), ...remote.filter((r) => !seen.has(r.url)), ...suggestions.slice(2)].slice(0, 8);
    renderSuggest();
  }

  async function go(i, newTab) {
    if (!api) return;
    let item = suggestions[i];
    if (!item) {
      const text = $('#q').value.trim();
      if (!text) return;
      const list = (await api.suggest(text)) || [];
      item = list.find((x) => x.kind === 'url' || x.kind === 'search') || list[0];
    }
    if (item) api.open(item, { newTab });
  }

  $('#q').addEventListener('input', updateSuggest);
  $('#q').addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (suggestions.length) sel = (sel + 1) % suggestions.length;
      renderSuggest();
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (suggestions.length) sel = (sel - 1 + suggestions.length) % suggestions.length;
      renderSuggest();
    } else if (e.key === 'Escape') {
      suggestions = [];
      renderSuggest();
    }
  });
  $('#q').addEventListener('blur', () => setTimeout(() => (box.hidden = true), 150));
  $('#q').addEventListener('focus', () => {
    if (suggestions.length && $('#q').value.trim()) box.hidden = false;
  });
  $('#search').addEventListener('submit', async (e) => {
    e.preventDefault();
    const text = $('#q').value.trim();
    if (!text || !api) return;
    if (!suggestions.length) suggestions = await api.suggest(text);
    go(sel, false);
  });

  // ---------- Quick note ----------
  let noteTimer = null;
  $('#note').addEventListener('input', (e) => {
    clearTimeout(noteTimer);
    const text = e.target.value;
    noteTimer = setTimeout(() => api && api.set('note', text), 400);
  });

  // ---------- Load ----------
  async function load() {
    if (!api) return;
    home = await api.home();
    applyLook();
    tick();
    renderFocus();
    renderShield();
    renderTiles();
    if (document.activeElement !== $('#note')) $('#note').value = home.note || '';
  }

  tick();
  setInterval(tick, 10000);
  load().then(loadWeather);
  setInterval(() => home && loadWeather(), 15 * 60 * 1000);

  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) load();
  });
  window.addEventListener('focus', () => {
    if (document.activeElement === document.body) $('#q').focus();
  });
  $('#q').focus();
})();
