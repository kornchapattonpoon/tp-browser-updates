'use strict';
/*
 * TP Browser starts here. It runs the newest TP Browser code you have: the version built into
 * the app, or a newer one that TP Browser downloaded by itself (Settings → Updates). The
 * Chromium engine stays the same; only TP's own code (sidebar, pages, TP AI…) is updated.
 *
 * If a downloaded version ever fails to start, TP Browser goes back to the built-in one.
 */
const path = require('path');
const fs = require('fs');
const { app } = require('electron');

const BUILT_IN_DIR = path.join(__dirname, '..');

function versionCode(v) {
  const p = String(v || '').split('.').map((n) => parseInt(n, 10) || 0);
  return (p[0] || 0) * 10000 + (p[1] || 0) * 100 + (p[2] || 0);
}

function readJson(file) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return null;
  }
}

function userDataDir() {
  if (process.env.TP_USER_DATA) return path.resolve(process.env.TP_USER_DATA);
  return path.join(app.getPath('appData'), 'TP Browser');
}

/** The folder whose src/main.js should run, plus a note for main.js about how it was picked. */
function pickCode() {
  const builtIn = readJson(path.join(BUILT_IN_DIR, 'package.json')) || {};
  const result = { dir: BUILT_IN_DIR, builtInDir: BUILT_IN_DIR, version: builtIn.version || app.getVersion(), builtInVersion: builtIn.version || '', fromUpdate: false };
  if (process.env.TP_IGNORE_UPDATES || process.env.TP_SMOKE_TEST) return result;
  const updates = path.join(userDataDir(), 'app-updates');
  const current = readJson(path.join(updates, 'current.json'));
  if (!current || !current.version || versionCode(current.version) <= versionCode(result.version)) return result;
  const dir = path.join(updates, String(current.version).replace(/[^0-9.]/g, ''));
  const pkg = readJson(path.join(dir, 'package.json'));
  if (!pkg || pkg.version !== current.version || !fs.existsSync(path.join(dir, 'src', 'main.js'))) return result;
  // Last start of this version never got as far as showing a window: don't try it again.
  const booting = readJson(path.join(updates, 'booting.json'));
  if (booting && booting.version === current.version && booting.tries >= 2) {
    try {
      fs.renameSync(path.join(updates, 'current.json'), path.join(updates, 'bad-' + current.version + '.json'));
    } catch {
      // nothing else to do
    }
    return result;
  }
  try {
    fs.writeFileSync(path.join(updates, 'booting.json'), JSON.stringify({ version: current.version, tries: (booting && booting.version === current.version ? booting.tries : 0) + 1 }));
  } catch {
    // read-only disk: still fine to run
  }
  return { dir, builtInDir: BUILT_IN_DIR, version: current.version, builtInVersion: result.version, fromUpdate: true };
}

const code = pickCode();
global.TP_CODE = code;
try {
  require(path.join(code.dir, 'src', 'main.js'));
} catch (err) {
  if (!code.fromUpdate) throw err;
  // The downloaded version is broken: run the built-in one instead.
  console.error('TP Browser update failed to load, using the built-in version:', err);
  global.TP_CODE = { dir: BUILT_IN_DIR, builtInDir: BUILT_IN_DIR, version: code.builtInVersion, builtInVersion: code.builtInVersion, fromUpdate: false, failed: code.version };
  require(path.join(BUILT_IN_DIR, 'src', 'main.js'));
}
