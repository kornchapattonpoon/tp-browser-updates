'use strict';
// Weather and air quality for the home page, from Open-Meteo (free, no account or key needed).

const TTL = 15 * 60 * 1000;
const cache = new Map();

async function getJson(fetchFn, url) {
  const res = await fetchFn(url);
  if (!res.ok) throw new Error('HTTP ' + res.status);
  return res.json();
}

function cached(key, make) {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.time < TTL) return hit.promise;
  const promise = make().catch((err) => {
    cache.delete(key);
    throw err;
  });
  cache.set(key, { time: Date.now(), promise });
  return promise;
}

function current(fetchFn, city, unit = 'C') {
  const lat = Number(city.lat).toFixed(3);
  const lon = Number(city.lon).toFixed(3);
  return cached(`${lat},${lon},${unit}`, async () => {
    const tu = unit === 'F' ? '&temperature_unit=fahrenheit' : '';
    const [w, a] = await Promise.allSettled([
      getJson(
        fetchFn,
        `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}` +
          '&current=temperature_2m,apparent_temperature,weather_code,is_day,relative_humidity_2m' +
          `&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&forecast_days=1&timezone=auto${tu}`
      ),
      getJson(
        fetchFn,
        `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${lat}&longitude=${lon}&current=us_aqi,pm2_5,pm10&timezone=auto`
      ),
    ]);
    const out = { city, unit, updated: Date.now(), weather: null, air: null };
    if (w.status === 'fulfilled' && w.value && w.value.current) {
      const c = w.value.current;
      const d = w.value.daily || {};
      const first = (arr) => (Array.isArray(arr) ? arr[0] : null);
      out.weather = {
        temp: c.temperature_2m,
        feels: c.apparent_temperature,
        code: c.weather_code,
        isDay: c.is_day === 1,
        humidity: c.relative_humidity_2m,
        high: first(d.temperature_2m_max),
        low: first(d.temperature_2m_min),
        rain: first(d.precipitation_probability_max),
      };
    }
    if (a.status === 'fulfilled' && a.value && a.value.current) {
      const c = a.value.current;
      out.air = { aqi: c.us_aqi, pm25: c.pm2_5, pm10: c.pm10 };
    }
    if (!out.weather && !out.air) throw new Error('offline');
    return out;
  });
}

async function searchCity(fetchFn, query) {
  const q = String(query || '').trim();
  if (q.length < 2) return [];
  const data = await getJson(
    fetchFn,
    `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=6&language=en&format=json`
  );
  return (data.results || []).map((r) => ({
    name: r.name,
    region: r.admin1 || '',
    country: r.country || '',
    lat: r.latitude,
    lon: r.longitude,
  }));
}

module.exports = { current, searchCity };
