'use strict';
// Bridge for the command bar (⌘K / ⌘L).
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('tpBar', {
  suggest: (text, mode) => ipcRenderer.invoke('overlay:suggest', text, mode),
  remote: (text) => ipcRenderer.invoke('overlay:remote', text),
  choose: (item, opts) => ipcRenderer.send('overlay:choose', item, opts || {}),
  close: () => ipcRenderer.send('overlay:close'),
  onOpen: (fn) => ipcRenderer.on('overlay:open', (_e, payload) => fn(payload)),
});
