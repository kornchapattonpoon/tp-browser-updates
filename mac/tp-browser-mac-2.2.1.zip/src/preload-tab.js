'use strict';
// Runs in every tab. TP Browser's own tp:// pages get a small API; websites get nothing
// extra except the standard `window.chrome` object every Chromium browser has.
const { contextBridge, ipcRenderer, webFrame } = require('electron');

// Electron leaves out the `window.chrome` object (chrome.app, chrome.csi, chrome.loadTimes)
// that Chrome, Brave, Edge and other Chromium browsers give every page. Some sites, including
// Google's sign-in, treat a Chrome browser without it as an "embedded, insecure" browser.
function addChromeObject() {
  if (window.chrome && window.chrome.app && window.chrome.csi) return;
  const nativeToString = Function.prototype.toString;
  const nativeText = new WeakMap();
  const asNative = (fn, name) => {
    nativeText.set(fn, `function ${name}() { [native code] }`);
    return fn;
  };
  const toString = function toString() {
    return nativeText.has(this) ? nativeText.get(this) : nativeToString.call(this);
  };
  nativeText.set(toString, 'function toString() { [native code] }');
  Object.defineProperty(Function.prototype, 'toString', { value: toString, writable: true, configurable: true, enumerable: false });

  const origin = performance.timeOrigin || Date.now();
  const navEntry = () => performance.getEntriesByType('navigation')[0] || {};
  const seconds = (ms) => (origin + (ms || 0)) / 1000;

  const app = {
    isInstalled: false,
    InstallState: { DISABLED: 'disabled', INSTALLED: 'installed', NOT_INSTALLED: 'not_installed' },
    RunningState: { CANNOT_RUN: 'cannot_run', READY_TO_RUN: 'ready_to_run', RUNNING: 'running' },
    getDetails: asNative(function getDetails() {
      return null;
    }, 'getDetails'),
    getIsInstalled: asNative(function getIsInstalled() {
      return false;
    }, 'getIsInstalled'),
    installState: asNative(function installState(callback) {
      if (typeof callback === 'function') setTimeout(() => callback('not_installed'), 0);
    }, 'installState'),
    runningState: asNative(function runningState() {
      return 'cannot_run';
    }, 'runningState'),
  };
  const csi = asNative(function csi() {
    const n = navEntry();
    return {
      onloadT: Math.round(origin + (n.domContentLoadedEventEnd || performance.now())),
      pageT: performance.now(),
      startE: Math.round(origin),
      tran: 15,
    };
  }, 'csi');
  const loadTimes = asNative(function loadTimes() {
    const n = navEntry();
    const proto = n.nextHopProtocol || 'h2';
    return {
      commitLoadTime: seconds(n.responseStart),
      connectionInfo: proto,
      finishDocumentLoadTime: seconds(n.domContentLoadedEventEnd),
      finishLoadTime: seconds(n.loadEventEnd),
      firstPaintAfterLoadTime: 0,
      firstPaintTime: seconds(n.responseEnd),
      navigationType: 'Other',
      npnNegotiatedProtocol: proto,
      requestTime: seconds(n.startTime),
      startLoadTime: seconds(n.startTime),
      wasAlternateProtocolAvailable: false,
      wasFetchedViaSpdy: /^h2|^h3/.test(proto),
      wasNpnNegotiated: /^h2|^h3/.test(proto),
    };
  }, 'loadTimes');

  const chrome = window.chrome || {};
  if (!chrome.app) chrome.app = app;
  if (!chrome.csi) chrome.csi = csi;
  if (!chrome.loadTimes) chrome.loadTimes = loadTimes;
  if (!window.chrome) {
    Object.defineProperty(window, 'chrome', { value: chrome, writable: true, configurable: true, enumerable: true });
  }
}

if (location.protocol === 'http:' || location.protocol === 'https:') {
  try {
    if (contextBridge.executeInMainWorld) contextBridge.executeInMainWorld({ func: addChromeObject });
    else webFrame.executeJavaScript(`(${addChromeObject.toString()})()`);
  } catch {
    // Never break a page over this.
  }
  // Dark mode for websites: style the page before it draws, so bright sites never flash white.
  if (window.top === window) {
    try {
      const dark = ipcRenderer.sendSync('tab:dark-code');
      if (dark) webFrame.executeJavaScriptInIsolatedWorld(1002, [{ code: dark }]);
    } catch {
      // Never break a page over this.
    }
  }
}

if (location.protocol === 'tp:') {
  const call = (channel) => (...args) => ipcRenderer.invoke(channel, ...args);
  contextBridge.exposeInMainWorld('tpInternal', {
    home: call('internal:home'),
    weather: call('internal:weather'),
    searchCity: call('internal:searchCity'),
    suggest: call('internal:suggest'),
    remoteSuggest: call('internal:remoteSuggest'),
    open: call('internal:open'),
    getSettings: call('internal:getSettings'),
    set: call('internal:set'),
    chooseWallpaper: call('internal:chooseWallpaper'),
    detectBrowsers: call('internal:detectBrowsers'),
    importFrom: call('internal:import'),
    makeDefault: call('internal:makeDefault'),
    isDefault: call('internal:isDefault'),
    clearData: call('internal:clearData'),
    updateSpace: call('internal:updateSpace'),
    addSpace: call('internal:addSpace'),
    deleteSpace: call('internal:deleteSpace'),
    getHistory: call('internal:getHistory'),
    deleteHistory: call('internal:deleteHistory'),
    clearHistory: call('internal:clearHistory'),
    getBookmarks: call('internal:getBookmarks'),
    removeBookmark: call('internal:removeBookmark'),
    setPinned: call('internal:setPinned'),
    startFocus: call('internal:startFocus'),
    endFocus: call('internal:endFocus'),
    focusStatus: call('internal:focusStatus'),
    finishOnboarding: call('internal:finishOnboarding'),
    checkUpdates: call('internal:checkUpdates'),
    updateState: call('internal:updateState'),
    restartToUpdate: call('internal:restartToUpdate'),
    setAiControl: call('internal:setAiControl'),
    clearAiChat: call('internal:clearAiChat'),
  });
}
