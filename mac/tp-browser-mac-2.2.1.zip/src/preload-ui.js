'use strict';
// Bridge for the sidebar UI. Only this page gets these controls.
const { contextBridge, ipcRenderer } = require('electron');

const listen = (channel) => (fn) => {
  const handler = (_e, payload) => fn(payload);
  ipcRenderer.on(channel, handler);
  return () => ipcRenderer.removeListener(channel, handler);
};
const send = (channel) => (...args) => ipcRenderer.send(channel, ...args);

contextBridge.exposeInMainWorld('tp', {
  // Tabs
  newTab: send('tab:new'),
  closeTab: send('tab:close'),
  activateTab: send('tab:activate'),
  tabMenu: send('tab:menu'),
  toggleMute: send('tab:mute'),
  moveTab: send('tab:move'),
  moveTabToSpace: send('tab:to-space'),
  exitSplit: send('split:exit'),

  // Navigation
  back: send('nav:back'),
  forward: send('nav:forward'),
  reload: send('nav:reload'),
  stop: send('nav:stop'),
  focusPage: send('page:focus'),
  resetZoom: send('zoom:reset'),
  copyUrl: send('url:copy'),
  openOverlay: send('ui:overlay'),

  // Spaces & favorites
  switchSpace: send('space:switch'),
  addSpace: send('space:add'),
  spaceMenu: send('space:menu'),
  renameSpace: send('space:rename'),
  openFavorite: send('fav:open'),
  favoriteMenu: send('fav:menu'),
  toggleBookmark: send('bookmark:toggle'),

  // Shield & focus
  shieldMenu: send('shield:menu'),
  focusMenu: send('focus:menu'),

  // Find in page
  find: send('find:query'),
  stopFind: send('find:stop'),

  // Downloads
  downloadAction: send('download:action'),
  clearDownloads: send('downloads:clear'),
  openDownloadsFolder: send('downloads:folder'),

  // Window
  layout: send('ui:layout'),
  setSidebarWidth: send('ui:sidebar-width'),
  toggleSidebar: send('ui:toggle-sidebar'),
  showMenu: send('ui:menu'),
  toastAction: send('ui:toast-action'),

  // Events from the main process
  onInit: listen('init'),
  onState: listen('state'),
  onFavorites: listen('favorites'),
  onSettings: listen('settings'),
  onDownloads: listen('downloads'),
  onFullscreen: listen('fullscreen'),
  onFindResult: listen('find:result'),
  onFindClose: listen('find:close'),
  onCommand: listen('command'),
  onToast: listen('toast'),

  // New in 2.2: page cover (reader view, sheets), small files, TP AI, voice, updates
  cover: (on, opts) => ipcRenderer.invoke('ui:cover', !!on, opts || {}),
  storeLoad: (key) => ipcRenderer.invoke('ui:store-load', key),
  storeSave: send('ui:store-save'),
  copy: send('ui:copy'),
  openInternal: send('ui:open-internal'),
  screenshot: send('ui:screenshot'),
  pip: send('ui:pip'),
  translate: send('ui:translate'),
  darkSite: send('ui:dark-site'),
  set: send('ui:set'),
  share: send('ui:share'),
  dictate: send('ui:dictate'),
  updateCheck: send('ui:update-check'),
  updateRestart: send('ui:update-restart'),
  ai: {
    request: send('ai:request'),
    abort: send('ai:abort'),
    eval: (tabId, script) => ipcRenderer.invoke('ai:eval', tabId, script),
    loadAndRead: (url, script) => ipcRenderer.invoke('ai:load-and-read', url, script),
    open: (url, opts) => ipcRenderer.invoke('ai:open', url, opts || {}),
    navigate: (url) => ipcRenderer.invoke('ai:navigate', url),
    wake: send('ai:wake'),
    activate: send('ai:activate'),
    close: send('ai:close'),
    nav: send('ai:nav'),
    find: send('ai:find'),
    focus: send('ai:focus'),
    favorite: send('ai:favorite'),
  },
  onAiChunk: listen('ai:chunk'),
  onAiDone: listen('ai:done'),
  onAiConfig: listen('ai:config'),
  onAiClear: listen('ai:clear'),
  onUpdate: listen('update'),
  onWhatsNew: listen('whatsnew'),
});
