'use strict';
// Pure helpers for TP Browser's Android interface. No DOM access, so Node can test them.
(function (global) {
  const SEARCH_ENGINES = {
    google: {
      name: 'Google',
      url: 'https://www.google.com/search?q=',
      suggest: 'https://suggestqueries.google.com/complete/search?client=firefox&ie=utf-8&oe=utf-8&q=',
    },
    duckduckgo: { name: 'DuckDuckGo', url: 'https://duckduckgo.com/?q=', suggest: 'https://duckduckgo.com/ac/?type=list&q=' },
    bing: { name: 'Bing', url: 'https://www.bing.com/search?q=', suggest: 'https://api.bing.com/osjson.aspx?query=' },
    brave: { name: 'Brave Search', url: 'https://search.brave.com/search?q=', suggest: 'https://search.brave.com/api/suggest?q=' },
  };

  const ASSET_PAGES = 'file:///android_asset/pages/';

  function engine(key) {
    return SEARCH_ENGINES[key] || SEARCH_ENGINES.google;
  }

  function searchUrl(query, engineKey) {
    return engine(engineKey).url + encodeURIComponent(query);
  }

  function suggestUrl(query, engineKey) {
    return engine(engineKey).suggest + encodeURIComponent(query);
  }

  /** All four engines answer in the OpenSearch shape: [query, [suggestion, ...]]. */
  function parseSuggest(body) {
    try {
      const data = JSON.parse(body);
      if (Array.isArray(data) && Array.isArray(data[1])) {
        return data[1].map((s) => (typeof s === 'string' ? s : s && s.phrase)).filter(Boolean);
      }
    } catch (e) {
      // Not JSON (offline page, captive portal): no suggestions.
    }
    return [];
  }

  /** True when the text looks like an address rather than a search. */
  function looksLikeUrl(input) {
    const text = String(input || '').trim();
    if (!text || /\s/.test(text)) return false;
    if (/^(https?|file):/i.test(text) || /^about:blank$/i.test(text)) return true;
    if (/^localhost(:\d+)?([/?#].*)?$/i.test(text)) return true;
    if (/^(\d{1,3}\.){3}\d{1,3}(:\d+)?([/?#].*)?$/.test(text)) return true;
    return /^[^\s/?#:@]+\.[a-z¡-￿]{2,}(:\d+)?([/?#].*)?$/i.test(text);
  }

  /** "example.com" -> https://example.com, "how tall is everest" -> a web search. */
  function resolveInput(input, engineKey) {
    const text = String(input || '').trim();
    if (!text) return null;
    if (/^https?:/i.test(text)) return text;
    if (/^about:blank$/i.test(text)) return 'about:blank';
    if (/^(javascript|file|data|intent):/i.test(text)) return searchUrl(text, engineKey);
    if (/^localhost(:\d+)?([/?#].*)?$/i.test(text)) return 'http://' + text;
    if (/^(\d{1,3}\.){3}\d{1,3}(:\d+)?([/?#].*)?$/.test(text)) return 'http://' + text;
    if (looksLikeUrl(text)) return 'https://' + text;
    return searchUrl(text, engineKey);
  }

  /** TP's own error and focus pages carry the real address in ?u=. */
  function realUrl(url) {
    const s = String(url || '');
    if (s.indexOf(ASSET_PAGES) === 0) {
      const m = /[?&]u=([^&#]*)/.exec(s);
      if (m) {
        try {
          return decodeURIComponent(m[1]);
        } catch (e) {
          return '';
        }
      }
      return '';
    }
    return s;
  }

  function isTpPage(url) {
    return String(url || '').indexOf(ASSET_PAGES) === 0;
  }

  function parseUrl(url) {
    try {
      return new URL(url);
    } catch (e) {
      return null;
    }
  }

  /** Hostname without "www.", lower case. */
  function hostOf(url) {
    const u = parseUrl(realUrl(url));
    if (!u || !u.hostname) return '';
    return u.hostname.toLowerCase().replace(/^www\./, '');
  }

  const SECOND_LEVEL = new Set(['co', 'com', 'net', 'org', 'ac', 'go', 'or', 'gov', 'edu', 'in', 'mi', 'ne', 'gr']);

  function rootDomain(host) {
    const h = String(host || '').toLowerCase().replace(/\.$/, '');
    if (!h || /^[\d.]+$/.test(h) || h.indexOf(':') >= 0) return h;
    const p = h.split('.');
    if (p.length <= 2) return h;
    const tld = p[p.length - 1];
    const sld = p[p.length - 2];
    if (tld.length === 2 && SECOND_LEVEL.has(sld)) return p.slice(-3).join('.');
    return p.slice(-2).join('.');
  }

  /** What the address bar shows: just the site, like Chrome on phones. */
  function displayUrl(url) {
    const real = realUrl(url);
    const u = parseUrl(real);
    if (!u) return { text: real, host: '', secure: false, search: null };
    const host = u.hostname.replace(/^www\./, '');
    let search = null;
    for (const key of Object.keys(SEARCH_ENGINES)) {
      const base = parseUrl(SEARCH_ENGINES[key].url);
      if (base && u.hostname === base.hostname && u.pathname === base.pathname) {
        search = u.searchParams.get('q') || null;
      }
    }
    return { text: host || real, host, secure: u.protocol === 'https:', search };
  }

  /** "youtube.com/watch?v=..." or "https://m.youtube.com" -> "youtube.com". */
  function normalizeSite(input) {
    let s = String(input || '').trim().toLowerCase();
    if (!s) return '';
    if (!/^[a-z]+:\/\//.test(s)) s = 'https://' + s;
    const u = parseUrl(s);
    if (!u || !u.hostname || u.hostname.indexOf('.') < 0) return '';
    return u.hostname.replace(/^(www|m|mobile)\./, '');
  }

  function hostInList(host, list) {
    const h = String(host || '').toLowerCase().replace(/^www\./, '');
    return (list || []).some((d) => h === d || h.endsWith('.' + d));
  }

  function pad(n) {
    return n < 10 ? '0' + n : String(n);
  }

  function dayKey(ts) {
    const d = new Date(ts == null ? Date.now() : ts);
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }

  function sumLastDays(map, days, now) {
    let total = 0;
    const base = now == null ? Date.now() : now;
    for (let i = 0; i < days; i++) total += Number((map || {})[dayKey(base - i * 86400000)]) || 0;
    return total;
  }

  function pruneDays(map, keep, now) {
    const out = {};
    const base = now == null ? Date.now() : now;
    for (let i = 0; i < keep; i++) {
      const k = dayKey(base - i * 86400000);
      if (map && map[k]) out[k] = map[k];
    }
    return out;
  }

  function fmtCount(n) {
    n = Number(n) || 0;
    if (n >= 1e6) return (n / 1e6).toFixed(n >= 1e7 ? 0 : 1).replace(/\.0$/, '') + 'M';
    if (n >= 1e3) return (n / 1e3).toFixed(n >= 1e4 ? 0 : 1).replace(/\.0$/, '') + 'k';
    return String(n);
  }

  function clockText(ms) {
    const s = Math.max(0, Math.ceil(ms / 1000));
    return Math.floor(s / 60) + ':' + pad(s % 60);
  }

  function greeting(hour) {
    if (hour < 5) return 'Good night';
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    if (hour < 22) return 'Good evening';
    return 'Good night';
  }

  function minutesText(min) {
    min = Math.round(min);
    if (min < 60) return min + ' min';
    const h = Math.floor(min / 60);
    const m = min % 60;
    return m ? h + ' h ' + m + ' min' : h + ' h';
  }

  /** Autocomplete: rank history and favorites against what's been typed. */
  function rankEntries(entries, query, limit) {
    const q = String(query || '').trim().toLowerCase();
    if (!q) return [];
    const words = q.split(/\s+/);
    const seen = new Set();
    const scored = [];
    for (const e of entries) {
      if (!e || !e.url || seen.has(e.url)) continue;
      const url = e.url.toLowerCase().replace(/^https?:\/\/(www\.)?/, '');
      const title = String(e.title || '').toLowerCase();
      let score = 0;
      if (url.indexOf(q) === 0) score += 100;
      else if (url.indexOf(q) >= 0) score += 40;
      let allWords = true;
      for (const w of words) {
        if (title.indexOf(w) >= 0) score += 15;
        else if (url.indexOf(w) < 0) allWords = false;
      }
      if (!allWords || score === 0) continue;
      score += Math.min(30, (e.visits || 1) * 3) + (e.fav ? 25 : 0);
      if (e.ts) score += Math.max(0, 20 - (Date.now() - e.ts) / 86400000);
      seen.add(e.url);
      scored.push({ e, score });
    }
    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, limit || 5).map((x) => x.e);
  }

  /** The text to complete inline in the address bar ("yout" -> "youtube.com"). */
  function inlineCompletion(entries, typed) {
    const t = String(typed || '').toLowerCase();
    if (!t || /\s/.test(t)) return '';
    for (const e of entries) {
      const host = hostOf(e.url);
      if (host && host.indexOf(t) === 0 && host !== t) return host;
    }
    return '';
  }

  function groupByDay(items, now) {
    const today = dayKey(now);
    const yesterday = dayKey((now == null ? Date.now() : now) - 86400000);
    const groups = [];
    let current = null;
    for (const it of items) {
      const k = dayKey(it.ts);
      if (!current || current.key !== k) {
        let label;
        if (k === today) label = 'Today';
        else if (k === yesterday) label = 'Yesterday';
        else label = new Date(it.ts).toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' });
        current = { key: k, label, items: [] };
        groups.push(current);
      }
      current.items.push(it);
    }
    return groups;
  }

  const WX = {
    0: ['☀️', 'Clear sky', '🌙'], 1: ['🌤️', 'Mostly clear', '🌙'], 2: ['⛅', 'Partly cloudy'], 3: ['☁️', 'Cloudy'],
    45: ['🌫️', 'Foggy'], 48: ['🌫️', 'Foggy'], 51: ['🌦️', 'Light drizzle'], 53: ['🌦️', 'Drizzle'], 55: ['🌧️', 'Heavy drizzle'],
    56: ['🌧️', 'Freezing drizzle'], 57: ['🌧️', 'Freezing drizzle'], 61: ['🌦️', 'Light rain'], 63: ['🌧️', 'Rain'],
    65: ['🌧️', 'Heavy rain'], 66: ['🌧️', 'Freezing rain'], 67: ['🌧️', 'Freezing rain'], 71: ['🌨️', 'Light snow'],
    73: ['🌨️', 'Snow'], 75: ['❄️', 'Heavy snow'], 77: ['🌨️', 'Snow grains'], 80: ['🌦️', 'Showers'], 81: ['🌧️', 'Rain showers'],
    82: ['⛈️', 'Heavy showers'], 85: ['🌨️', 'Snow showers'], 86: ['🌨️', 'Snow showers'], 95: ['⛈️', 'Thunderstorm'],
    96: ['⛈️', 'Thunderstorm, hail'], 99: ['⛈️', 'Thunderstorm, hail'],
  };

  function weatherInfo(code, isDay) {
    const w = WX[code] || ['🌡️', 'Weather'];
    return { emoji: !isDay && w[2] ? w[2] : w[0], label: w[1] };
  }

  const AQI = [
    [50, 'Good', '#16a34a', 'Great air today. Enjoy being outside!'],
    [100, 'Moderate', '#ca8a04', 'Fine for most people. Sensitive groups take it easy outdoors.'],
    [150, 'Unhealthy for some', '#ea580c', 'Sensitive groups should limit long outdoor activity.'],
    [200, 'Unhealthy', '#dc2626', 'Wear a mask outside and keep outdoor time short.'],
    [300, 'Very unhealthy', '#9333ea', 'Avoid going outside if you can and close windows.'],
    [Infinity, 'Hazardous', '#7f1d1d', 'Stay indoors with windows closed.'],
  ];

  function aqiLevel(aqi) {
    const l = AQI.find((x) => aqi <= x[0]) || AQI[AQI.length - 1];
    return { label: l[1], color: l[2], tip: l[3] };
  }

  function weatherUrl(city) {
    return 'https://api.open-meteo.com/v1/forecast?latitude=' + city.lat + '&longitude=' + city.lon +
      '&current=temperature_2m,apparent_temperature,weather_code,is_day,relative_humidity_2m' +
      '&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&forecast_days=1&timezone=auto';
  }

  function airUrl(city) {
    return 'https://air-quality-api.open-meteo.com/v1/air-quality?latitude=' + city.lat + '&longitude=' + city.lon +
      '&current=us_aqi,pm2_5,pm10&timezone=auto';
  }

  function geocodeUrl(name) {
    return 'https://geocoding-api.open-meteo.com/v1/search?name=' + encodeURIComponent(name) + '&count=6&language=en&format=json';
  }

  function parseWeather(body) {
    try {
      const d = JSON.parse(body);
      if (!d.current) return null;
      return {
        temp: d.current.temperature_2m,
        feels: d.current.apparent_temperature,
        code: d.current.weather_code,
        isDay: !!d.current.is_day,
        humidity: d.current.relative_humidity_2m,
        max: d.daily && d.daily.temperature_2m_max ? d.daily.temperature_2m_max[0] : null,
        min: d.daily && d.daily.temperature_2m_min ? d.daily.temperature_2m_min[0] : null,
        rain: d.daily && d.daily.precipitation_probability_max ? d.daily.precipitation_probability_max[0] : null,
      };
    } catch (e) {
      return null;
    }
  }

  function parseAir(body) {
    try {
      const d = JSON.parse(body);
      if (!d.current || d.current.us_aqi == null) return null;
      return { aqi: d.current.us_aqi, pm25: d.current.pm2_5, pm10: d.current.pm10 };
    } catch (e) {
      return null;
    }
  }

  function toF(c) {
    return c * 9 / 5 + 32;
  }

  const SPACE_COLORS = {
    violet: ['#7c5cff', '#4f8bff'],
    blue: ['#2f7bf6', '#06b6d4'],
    teal: ['#0ea5a4', '#22c55e'],
    green: ['#22c55e', '#a3e635'],
    orange: ['#f97316', '#facc15'],
    pink: ['#ec4899', '#a855f7'],
    red: ['#ef4444', '#f97316'],
    slate: ['#64748b', '#a1a1aa'],
  };

  // ------------------------------------------------------------------------------------------
  // Address-bar calculator: "12*7", "(3+4)/2", "2^10", "15%", "3 x 4", "10 ÷ 4"
  // ------------------------------------------------------------------------------------------

  /** The answer, or null when the text isn't a sum (dates and phone numbers aren't sums). */
  function calc(input) {
    let s = String(input == null ? '' : input).trim();
    if (!s || s.length > 100) return null;
    s = s.replace(/^=\s*/, '').replace(/[×xX]/g, '*').replace(/÷/g, '/').replace(/[−–]/g, '-').replace(/\*\*/g, '^').replace(/(\d),(?=\d{3}\b)/g, '$1');
    if (!/^[\d\s.+\-*/^%()]+$/.test(s) || !/\d/.test(s)) return null;
    if (!/\d\s*[+\-*/^%]/.test(s) && !/\)\s*[+\-*/^]/.test(s)) return null;
    if (/^\d+(-\d+){2,}$/.test(s.replace(/\s/g, '')) || /^\d{1,2}\/\d{1,2}\/\d{2,4}$/.test(s)) return null;
    let i = 0;
    const peek = () => {
      while (s[i] === ' ') i++;
      return s[i];
    };
    const fail = () => {
      throw new Error('bad');
    };
    function primary() {
      const c = peek();
      if (c === '(') {
        i++;
        const v = expr();
        if (peek() !== ')') fail();
        i++;
        return v;
      }
      const m = /^(\d+\.?\d*|\.\d+)/.exec(s.slice(i));
      if (!m) fail();
      i += m[0].length;
      return parseFloat(m[0]);
    }
    function postfix() {
      let v = primary();
      while (peek() === '%') {
        i++;
        v /= 100;
      }
      return v;
    }
    function unary() {
      const c = peek();
      if (c === '-') {
        i++;
        return -unary();
      }
      if (c === '+') {
        i++;
        return unary();
      }
      return power();
    }
    function power() {
      const base = postfix();
      if (peek() === '^') {
        i++;
        return Math.pow(base, unary());
      }
      return base;
    }
    function term() {
      let v = unary();
      for (;;) {
        const c = peek();
        if (c === '*') {
          i++;
          v *= unary();
        } else if (c === '/') {
          i++;
          v /= unary();
        } else return v;
      }
    }
    function expr() {
      let v = term();
      for (;;) {
        const c = peek();
        if (c === '+') {
          i++;
          v += term();
        } else if (c === '-') {
          i++;
          v -= term();
        } else return v;
      }
    }
    try {
      const v = expr();
      if (peek() !== undefined) return null;
      if (!isFinite(v)) return null;
      return Number(v.toPrecision(12));
    } catch (e) {
      return null;
    }
  }

  function fmtNumber(n) {
    if (Math.abs(n) >= 1e15 || (n !== 0 && Math.abs(n) < 1e-6)) return n.toExponential(6).replace(/\.?0+e/, 'e');
    return n.toLocaleString('en-US', { maximumFractionDigits: 10 });
  }

  /** Days in a row with some focus time. Today only breaks the streak once it's over. */
  function focusStreak(map, now) {
    const d = new Date(now == null ? Date.now() : now);
    const has = () => Number((map || {})[dayKey(d.getTime())]) > 0;
    if (!has()) d.setDate(d.getDate() - 1);
    let n = 0;
    while (has() && n < 1000) {
      n++;
      d.setDate(d.getDate() - 1);
    }
    return n;
  }

  // ------------------------------------------------------------------------------------------
  // Translate pages (Google Translate's page proxy) and read-aloud helpers
  // ------------------------------------------------------------------------------------------

  function translateUrl(url, lang) {
    const original = untranslateUrl(url) || url;
    return 'https://translate.google.com/translate?sl=auto&tl=' + encodeURIComponent(lang) + '&hl=' + encodeURIComponent(lang) + '&u=' + encodeURIComponent(original);
  }

  /** "https://www-bbc-com.translate.goog/news?_x_tr_sl=auto" -> "https://www.bbc.com/news". Null if not translated. */
  function untranslateUrl(url) {
    const u = parseUrl(url);
    if (!u) return null;
    const m = /^(.+)\.translate\.goog$/i.exec(u.hostname);
    if (!m) return null;
    const host = m[1].split('--').map((p) => p.replace(/-/g, '.')).join('-');
    const params = new URLSearchParams(u.search);
    Array.from(params.keys()).filter((k) => /^_x_tr_/.test(k)).forEach((k) => params.delete(k));
    const q = params.toString();
    return 'https://' + host + u.pathname + (q ? '?' + q : '') + u.hash;
  }

  /** "th" for Thai text, else the page's language, else "". */
  function speechLang(text, pageLang) {
    const t = String(text || '');
    const thai = (t.match(/[฀-๿]/g) || []).length;
    const letters = (t.match(/[A-Za-zÀ-ɏ฀-๿]/g) || []).length;
    if (thai && thai / Math.max(1, letters) > 0.3) return 'th';
    const p = String(pageLang || '').toLowerCase().split(/[-_]/)[0];
    if (p === 'th' && !thai) return 'en';
    // Plain English letters with no language given: an English voice, even on a phone set to Thai.
    const latin = (t.match(/[A-Za-z]/g) || []).length;
    if (!p && latin && latin / Math.max(1, letters) > 0.8) return 'en';
    return p;
  }

  /** Splits long text at sentence ends (or spaces) so each piece can be read aloud. */
  function splitSpeech(text, max) {
    max = max || 1200;
    const out = [];
    let rest = String(text || '').replace(/\s+/g, ' ').trim();
    while (rest.length > max) {
      const head = rest.slice(0, max);
      let cut = -1;
      const re = /[.!?。！？](?=\s)|\s{1}/g;
      let m;
      let lastSentence = -1;
      let lastSpace = -1;
      while ((m = re.exec(head))) {
        if (m[0] === ' ') lastSpace = m.index;
        else lastSentence = m.index + 1;
      }
      cut = lastSentence > max * 0.4 ? lastSentence : lastSpace > 0 ? lastSpace : max;
      out.push(rest.slice(0, cut).trim());
      rest = rest.slice(cut).trim();
    }
    if (rest) out.push(rest);
    return out;
  }

  /** Rough minutes to read: Thai has no spaces, so it counts characters instead of words. */
  function readingMinutes(text) {
    const t = String(text || '');
    const thai = (t.match(/[฀-๿]/g) || []).length;
    const words = (t.replace(/[฀-๿]/g, ' ').match(/\S+/g) || []).length;
    return Math.max(1, Math.round((words + thai / 6) / 220));
  }

  /** Markdown answer -> plain text for reading aloud. */
  function plainText(md) {
    return String(md || '')
      .replace(/\[([^\]]+)\]\((https?:[^)\s]+)\)/g, '$1')
      .replace(/https?:\/\/\S+/g, '')
      .replace(/[*_`#>]+/g, '')
      .replace(/^\s*([-•]|\d+[.)])\s+/gm, '')
      .replace(/\n{2,}/g, '\n')
      .trim();
  }

  const api = {
    SEARCH_ENGINES, SPACE_COLORS, engine, searchUrl, suggestUrl, parseSuggest, looksLikeUrl, resolveInput, realUrl, isTpPage,
    hostOf, rootDomain, displayUrl, normalizeSite, hostInList, dayKey, sumLastDays, pruneDays, fmtCount, clockText, greeting,
    minutesText, rankEntries, inlineCompletion, groupByDay, weatherInfo, aqiLevel, weatherUrl, airUrl, geocodeUrl, parseWeather,
    parseAir, toF, calc, fmtNumber, focusStreak, translateUrl, untranslateUrl, speechLang, splitSpeech, readingMinutes, plainText,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else global.TPCore = api;
})(typeof window !== 'undefined' ? window : globalThis);
