'use strict';
/* TP Browser sidebar: spaces, favorites, vertical tabs, address pill, find bar, downloads. */

(function () {
  const tp = window.tp;
  const I = window.ICONS;
  const $ = (sel) => document.querySelector(sel);

  const el = {
    sidebar: $('#sidebar'),
    favorites: $('#favorites'),
    spaceHead: $('#space-head'),
    spaceIcon: $('#space-head .space-icon'),
    spaceName: $('#space-head .space-name'),
    tabsScroll: $('#tabs-scroll'),
    tablist: $('#tablist'),
    spaces: $('#spaces'),
    focusChip: $('#focus-chip'),
    downloadsBtn: $('#downloads-btn'),
    dlPanel: $('#downloads-panel'),
    dlList: $('#dl-list'),
    slot: $('#page-slot'),
    findbar: $('#findbar'),
    findInput: $('#find-input'),
    findCount: $('#find-count'),
    toast: $('#toast'),
    cSpace: $('#c-space'),
  };

  let state = { tabs: [], activeId: null, spaceId: null, spaces: [], split: null, shield: {}, focus: null };
  let settings = { searchEngineName: 'Google', sidebarWidth: 264 };
  let favorites = [];
  let downloads = [];
  const seenDownloads = new Set();
  let dlOpen = false;
  const tabEls = new Map();

  // ---------- Static icons ----------
  const setIcon = (sel, name) => {
    const node = typeof sel === 'string' ? $(sel) : sel;
    if (node) node.innerHTML = I[name];
  };
  setIcon('#collapse', 'sidebar');
  setIcon('#expand', 'sidebar');
  setIcon('#back', 'back');
  setIcon('#forward', 'forward');
  setIcon('#reload', 'reload');
  setIcon('#c-back', 'back');
  setIcon('#c-forward', 'forward');
  setIcon('#c-reload', 'reload');
  setIcon('#menu-btn', 'more');
  setIcon('#c-menu', 'more');
  setIcon('#add-space', 'plus');
  setIcon('#space-head .space-more', 'more');
  setIcon('#new-tab-row .plus', 'plus');
  setIcon('#find-icon', 'search');
  setIcon('#find-prev', 'up');
  setIcon('#find-next', 'down');
  setIcon('#find-close', 'close');

  // ---------- Helpers ----------
  const activeTab = () => state.tabs.find((t) => t.id === state.activeId) || null;
  const activeSpace = () => state.spaces.find((s) => s.id === state.spaceId) || state.spaces[0] || null;

  function hostOf(url) {
    try {
      return new URL(url).host.replace(/^www\./, '');
    } catch {
      return '';
    }
  }

  function colorFor(text) {
    let h = 0;
    for (const ch of String(text)) h = (h * 31 + ch.charCodeAt(0)) % 360;
    return `hsl(${h} 58% 52%)`;
  }

  function letterIcon(name, cls = 'letter') {
    const s = document.createElement('span');
    s.className = cls;
    const n = (name || '?').trim();
    s.textContent = n.charAt(0).toUpperCase();
    s.style.background = colorFor(n);
    return s;
  }

  function fmtBytes(n) {
    if (!n || n < 0) return '0 B';
    const u = ['B', 'KB', 'MB', 'GB', 'TB'];
    let i = 0;
    while (n >= 1024 && i < u.length - 1) {
      n /= 1024;
      i += 1;
    }
    return `${n >= 100 || i === 0 ? Math.round(n) : n.toFixed(1)} ${u[i]}`;
  }

  // ---------- Layout reporting ----------
  let lastRect = '';
  function reportLayout() {
    const r = el.slot.getBoundingClientRect();
    const rect = { x: Math.round(r.left), y: Math.round(r.top), width: Math.round(r.width), height: Math.round(r.height) };
    const key = JSON.stringify(rect);
    if (key !== lastRect) {
      lastRect = key;
      tp.layout(rect);
    }
  }
  new ResizeObserver(reportLayout).observe(el.slot);
  window.addEventListener('resize', reportLayout);

  // ---------- Address pill (sidebar + compact bar share one renderer) ----------
  function makeUrlbar(container) {
    container.innerHTML = `
      <div class="urlbar" role="button" tabindex="0" title="Search or enter address (⌘L)">
        <span class="u-icon"></span>
        <span class="u-text"></span>
        <button class="u-btn u-zoom" hidden title="Reset zoom"></button>
        <button class="u-btn u-shield" hidden></button>
        <button class="u-btn u-star" hidden></button>
        <button class="u-btn u-copy" title="Copy link (⇧⌘C)">${I.copy}</button>
        <span class="loadbar"></span>
      </div>`;
    const root = container.firstElementChild;
    const refs = {
      root,
      icon: root.querySelector('.u-icon'),
      text: root.querySelector('.u-text'),
      zoom: root.querySelector('.u-zoom'),
      shield: root.querySelector('.u-shield'),
      star: root.querySelector('.u-star'),
      copy: root.querySelector('.u-copy'),
    };
    root.addEventListener('click', (e) => {
      if (e.target.closest('.u-btn')) return;
      tp.openOverlay('current');
    });
    root.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        tp.openOverlay('current');
      }
    });
    refs.zoom.addEventListener('click', () => tp.resetZoom());
    refs.shield.addEventListener('click', () => tp.shieldMenu());
    refs.star.addEventListener('click', () => tp.toggleBookmark());
    refs.copy.addEventListener('click', () => tp.copyUrl());
    return refs;
  }
  const urlbars = [makeUrlbar($('#sb-url')), makeUrlbar($('#c-url'))];

  const INTERNAL_NAMES = {
    'tp://settings': 'Settings',
    'tp://history': 'History',
    'tp://welcome': 'Welcome to TP Browser',
  };

  function renderUrlbars() {
    const t = activeTab();
    const url = t ? t.url : '';
    let text = '';
    let icon = 'search';
    let tip = '';
    if (!url) {
      text = '';
    } else if (url.startsWith('tp://')) {
      const key = Object.keys(INTERNAL_NAMES).find((k) => url.startsWith(k));
      text = key ? INTERNAL_NAMES[key] : 'TP Browser';
    } else if (/^https?:/.test(url)) {
      text = hostOf(url) || url;
      icon = url.startsWith('https:') ? 'lock' : 'info';
      tip = url.startsWith('https:') ? 'Secure connection' : 'Not secure: this site does not use HTTPS';
    } else if (url.startsWith('file:')) {
      text = decodeURIComponent(url.split('/').pop() || url);
      icon = 'file';
    } else {
      text = url;
    }
    if (t && t.paused) icon = 'target';

    const sh = state.shield || {};
    for (const u of urlbars) {
      u.root.classList.toggle('loading', !!(t && t.loading));
      u.root.title = url ? `${url}\n\nClick to search or edit (⌘L)` : 'Search or enter address (⌘L)';
      if (u.icon.dataset.icon !== icon) {
        u.icon.dataset.icon = icon;
        u.icon.innerHTML = I[icon];
      }
      u.icon.classList.toggle('secure', icon === 'lock');
      u.icon.title = tip;
      u.text.textContent = text || `Search ${settings.searchEngineName || 'the web'} or type a URL`;
      u.text.classList.toggle('placeholder', !text);

      const zoom = t ? t.zoom : 100;
      u.zoom.hidden = !t || zoom === 100;
      u.zoom.textContent = `${zoom}%`;

      u.shield.hidden = !sh.applicable;
      if (sh.applicable) {
        const on = sh.on && !sh.allowed;
        u.shield.className = `u-btn u-shield ${on ? 'on' : 'off'}`;
        u.shield.innerHTML = (on ? I.shield : I.shieldOff) + (on && sh.blocked ? `<span>${sh.blocked > 999 ? '999+' : sh.blocked}</span>` : '');
        u.shield.title = on ? `TP Shield blocked ${sh.blocked || 0} ads & trackers on this page` : 'TP Shield is off for this site';
      }

      const canStar = !!url && /^(https?|file):/.test(url);
      u.star.hidden = !canStar;
      const on = !!(t && t.bookmarked);
      u.star.classList.toggle('on', on);
      u.star.innerHTML = on ? I.starFilled : I.star;
      u.star.title = on ? 'Remove bookmark (⌘D)' : 'Bookmark this page (⌘D)';

      u.copy.classList.toggle('has-url', !!url && !url.startsWith('tp:'));
    }
  }

  // ---------- Toolbar buttons ----------
  function renderNav() {
    const t = activeTab();
    for (const prefix of ['#', '#c-']) {
      $(prefix + 'back').disabled = !t || !t.canGoBack;
      $(prefix + 'forward').disabled = !t || !t.canGoForward;
      const r = $(prefix + 'reload');
      const icon = t && t.loading ? 'stop' : 'reload';
      if (r.dataset.icon !== icon) {
        r.dataset.icon = icon;
        r.innerHTML = I[icon];
        r.title = icon === 'stop' ? 'Stop loading (⌘.)' : 'Reload (⌘R)';
      }
    }
  }

  for (const prefix of ['#', '#c-']) {
    $(prefix + 'back').addEventListener('click', () => tp.back());
    $(prefix + 'forward').addEventListener('click', () => tp.forward());
    $(prefix + 'reload').addEventListener('click', (e) => (e.currentTarget.dataset.icon === 'stop' ? tp.stop() : tp.reload()));
  }
  $('#collapse').addEventListener('click', () => tp.toggleSidebar());
  $('#expand').addEventListener('click', () => tp.toggleSidebar());
  el.cSpace.addEventListener('click', () => tp.toggleSidebar());
  for (const id of ['#menu-btn', '#c-menu']) {
    $(id).addEventListener('click', (e) => {
      const r = e.currentTarget.getBoundingClientRect();
      tp.showMenu({ x: r.left, y: id === '#c-menu' ? r.bottom + 4 : r.top - 4 });
    });
  }

  // ---------- Space theme ----------
  function applySpaceTheme() {
    const s = activeSpace();
    if (!s) return;
    const [c1, c2] = s.colors || ['#7c5cff', '#4f8bff'];
    document.documentElement.style.setProperty('--c1', c1);
    document.documentElement.style.setProperty('--c2', c2);
    if (el.spaceName.getAttribute('contenteditable') !== 'true') el.spaceName.textContent = s.name;
    el.spaceIcon.textContent = s.icon;
    el.cSpace.textContent = s.icon;
    el.cSpace.title = `${s.name} space`;
  }

  // ---------- Favorites ----------
  function renderFavorites() {
    const t = activeTab();
    const currentHost = t ? hostOf(t.url) : '';
    el.favorites.replaceChildren(
      ...favorites.map((f) => {
        const b = document.createElement('button');
        b.className = 'fav' + (currentHost && hostOf(f.url) === currentHost ? ' current' : '');
        b.title = `${f.title}\n${f.url}`;
        const name = hostOf(f.url) || f.title;
        if (f.favicon) {
          const img = new Image();
          img.alt = '';
          img.src = f.favicon;
          img.onerror = () => img.replaceWith(letterIcon(name));
          b.append(img);
        } else b.append(letterIcon(name));
        b.addEventListener('click', (e) => tp.openFavorite(f.id, { newTab: e.metaKey }));
        b.addEventListener('auxclick', (e) => {
          if (e.button === 1) tp.openFavorite(f.id, { newTab: true });
        });
        b.addEventListener('contextmenu', (e) => {
          e.preventDefault();
          tp.favoriteMenu(f.id);
        });
        return b;
      })
    );
  }

  // ---------- Tabs ----------
  function makeTabEl(id) {
    const node = document.createElement('div');
    node.className = 'tab';
    node.draggable = true;
    node.dataset.id = id;
    node.setAttribute('role', 'tab');
    node.innerHTML =
      '<span class="t-icon"></span><span class="t-title"></span>' +
      `<button class="t-badge" hidden title="Exit split view">${I.split}</button>` +
      '<button class="t-audio" hidden></button>' +
      `<button class="t-close" title="Close tab (⌘W)">${I.close}</button>`;

    node.addEventListener('mousedown', (e) => {
      if (e.button === 0 && !e.target.closest('button')) tp.activateTab(id);
    });
    node.addEventListener('auxclick', (e) => {
      if (e.button === 1) tp.closeTab(id);
    });
    node.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      tp.tabMenu(id);
    });
    node.querySelector('.t-close').addEventListener('click', (e) => {
      e.stopPropagation();
      tp.closeTab(id);
    });
    node.querySelector('.t-audio').addEventListener('click', (e) => {
      e.stopPropagation();
      tp.toggleMute(id);
    });
    node.querySelector('.t-badge').addEventListener('click', (e) => {
      e.stopPropagation();
      tp.exitSplit();
    });

    node.addEventListener('dragstart', (e) => {
      e.dataTransfer.setData('application/x-tp-tab', String(id));
      e.dataTransfer.effectAllowed = 'move';
      node.classList.add('dragging');
    });
    node.addEventListener('dragend', () => {
      node.classList.remove('dragging');
      clearDropMarks();
    });
    node.addEventListener('dragover', (e) => {
      if (!e.dataTransfer.types.includes('application/x-tp-tab')) return;
      e.preventDefault();
      clearDropMarks();
      const r = node.getBoundingClientRect();
      node.classList.add(e.clientY < r.top + r.height / 2 ? 'drop-before' : 'drop-after');
    });
    node.addEventListener('drop', (e) => {
      const from = Number(e.dataTransfer.getData('application/x-tp-tab'));
      if (!from) return;
      e.preventDefault();
      const after = node.classList.contains('drop-after');
      clearDropMarks();
      if (from !== id) tp.moveTab(from, id, after);
    });
    return node;
  }

  function clearDropMarks() {
    document.querySelectorAll('.drop-before, .drop-after, .space-dot.drop').forEach((n) => n.classList.remove('drop-before', 'drop-after', 'drop'));
  }

  function renderTabIcon(box, t) {
    let key;
    if (t.loading) key = 'loading';
    else if (t.paused) key = 'paused';
    else if (t.internal) key = 'tp';
    else if (t.favicon) key = 'fav:' + t.favicon;
    else key = 'globe';
    if (box.dataset.key === key) return;
    box.dataset.key = key;
    if (key === 'loading') box.innerHTML = '<span class="spinner"></span>';
    else if (key === 'paused') box.innerHTML = '<span class="emoji">🎯</span>';
    else if (key === 'tp') box.innerHTML = '<span class="tp-mark">TP</span>';
    else if (key === 'globe') box.innerHTML = I.globe;
    else {
      const img = new Image();
      img.alt = '';
      img.onerror = () => {
        box.innerHTML = I.globe;
      };
      img.src = t.favicon;
      box.replaceChildren(img);
    }
  }

  let tabsRendered = false;
  let spaceJustChanged = false;

  function renderTabs() {
    const visible = state.tabs.filter((t) => t.spaceId === state.spaceId);
    const ids = new Set(visible.map((t) => t.id));
    for (const [id, node] of tabEls) {
      if (!ids.has(id)) {
        node.remove();
        tabEls.delete(id);
      }
    }
    const split = state.split || [];
    visible.forEach((t, i) => {
      let node = tabEls.get(t.id);
      if (!node) {
        node = makeTabEl(t.id);
        tabEls.set(t.id, node);
        // New tabs slide in (not the ones already there when the window opens or a space switches).
        if (tabsRendered && !spaceJustChanged) {
          node.classList.add('enter');
          setTimeout(() => node.classList.remove('enter'), 500);
        }
      }
      if (el.tablist.children[i] !== node) el.tablist.insertBefore(node, el.tablist.children[i] || null);
      const isActive = t.id === state.activeId;
      node.classList.toggle('active', isActive);
      node.classList.toggle('sleeping', !!t.sleeping);
      node.classList.toggle('split', split.includes(t.id));
      node.setAttribute('aria-selected', String(isActive));
      node.title = t.sleeping ? `${t.title}\n💤 Sleeping to save memory` : t.url ? `${t.title}\n${t.url}` : t.title;
      const titleEl = node.querySelector('.t-title');
      if (titleEl.textContent !== t.title) titleEl.textContent = t.title;
      renderTabIcon(node.querySelector('.t-icon'), t);
      node.querySelector('.t-badge').hidden = !split.includes(t.id);

      const audio = node.querySelector('.t-audio');
      const showAudio = t.audible || t.muted;
      audio.hidden = !showAudio;
      if (showAudio) {
        const icon = t.muted ? 'muted' : 'speaker';
        if (audio.dataset.icon !== icon) {
          audio.dataset.icon = icon;
          audio.innerHTML = I[icon];
          audio.title = t.muted ? 'Unmute tab' : 'Mute tab';
        }
      }
    });
    tabsRendered = true;
    const activeNode = tabEls.get(state.activeId);
    if (activeNode && activeNode.dataset.scrolledFor !== String(state.activeId)) {
      activeNode.dataset.scrolledFor = String(state.activeId);
      activeNode.scrollIntoView({ block: 'nearest' });
    }
  }

  $('#new-tab-row').addEventListener('click', () => tp.newTab());
  el.tabsScroll.addEventListener('dblclick', (e) => {
    if (e.target === el.tabsScroll || e.target === el.tablist) tp.newTab();
  });

  // ---------- Spaces ----------
  function renderSpaces() {
    el.spaces.replaceChildren(
      ...state.spaces.map((s, i) => {
        const b = document.createElement('button');
        b.className = 'space-dot' + (s.id === state.spaceId ? ' active' : '');
        b.textContent = s.icon;
        b.title = `${s.name} (⌃${i + 1})${s.count ? ` · ${s.count} tab${s.count === 1 ? '' : 's'}` : ''}`;
        b.setAttribute('role', 'tab');
        b.setAttribute('aria-selected', String(s.id === state.spaceId));
        b.addEventListener('click', () => tp.switchSpace(s.id));
        b.addEventListener('contextmenu', (e) => {
          e.preventDefault();
          tp.spaceMenu(s.id);
        });
        b.addEventListener('dragover', (e) => {
          if (!e.dataTransfer.types.includes('application/x-tp-tab') || s.id === state.spaceId) return;
          e.preventDefault();
          clearDropMarks();
          b.classList.add('drop');
        });
        b.addEventListener('dragleave', () => b.classList.remove('drop'));
        b.addEventListener('drop', (e) => {
          const from = Number(e.dataTransfer.getData('application/x-tp-tab'));
          clearDropMarks();
          if (from && s.id !== state.spaceId) {
            e.preventDefault();
            tp.moveTabToSpace(from, s.id);
          }
        });
        return b;
      })
    );
  }

  $('#add-space').addEventListener('click', () => tp.addSpace());
  $('#space-head .space-more').addEventListener('click', () => state.spaceId && tp.spaceMenu(state.spaceId));
  el.spaceHead.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    if (state.spaceId) tp.spaceMenu(state.spaceId);
  });
  el.spaceName.addEventListener('dblclick', () => startRename(state.spaceId));

  function startRename(id) {
    if (!id || id !== state.spaceId) return;
    const n = el.spaceName;
    n.setAttribute('contenteditable', 'true');
    n.focus();
    const range = document.createRange();
    range.selectNodeContents(n);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
    const finish = (save) => {
      n.removeEventListener('keydown', onKey);
      n.removeEventListener('blur', onBlur);
      n.setAttribute('contenteditable', 'false');
      const name = n.textContent.replace(/\s+/g, ' ').trim();
      if (save && name) tp.renameSpace(id, name);
      applySpaceTheme();
      tp.focusPage();
    };
    const onKey = (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        finish(true);
      } else if (e.key === 'Escape') {
        e.preventDefault();
        finish(false);
      }
    };
    const onBlur = () => finish(true);
    n.addEventListener('keydown', onKey);
    n.addEventListener('blur', onBlur);
  }

  // ---------- Focus chip ----------
  let focusTick = null;
  function renderFocus() {
    const f = state.focus;
    clearInterval(focusTick);
    el.focusChip.hidden = !f;
    if (!f) return;
    const update = () => {
      const left = Math.max(0, f.endsAt - Date.now());
      const m = Math.floor(left / 60000);
      const s = Math.floor((left % 60000) / 1000);
      el.focusChip.querySelector('.fc-time').textContent = `${m}:${String(s).padStart(2, '0')}`;
      const total = f.endsAt - f.startedAt;
      el.focusChip.querySelector('.fc-bar i').style.width = `${Math.min(100, ((total - left) / total) * 100)}%`;
    };
    update();
    focusTick = setInterval(update, 1000);
  }
  el.focusChip.addEventListener('click', () => tp.focusMenu());

  // ---------- Find in page ----------
  let findText = '';
  function openFind() {
    el.findbar.hidden = false;
    el.findInput.focus();
    el.findInput.select();
    if (el.findInput.value) search(true, true);
  }
  function closeFind(notifyMain = true) {
    if (el.findbar.hidden) return;
    el.findbar.hidden = true;
    el.findCount.textContent = '';
    el.findInput.classList.remove('none');
    findText = '';
    if (notifyMain) tp.stopFind();
  }
  function search(newSearch, forward = true) {
    const text = el.findInput.value;
    if (!text) {
      el.findCount.textContent = '';
      el.findInput.classList.remove('none');
      tp.find({ text: '' });
      findText = '';
      return;
    }
    const isNew = newSearch || text !== findText;
    findText = text;
    tp.find({ text, forward, newSearch: isNew });
  }
  el.findInput.addEventListener('input', () => search(true));
  el.findInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      search(false, !e.shiftKey);
    } else if (e.key === 'Escape') {
      e.preventDefault();
      closeFind();
    }
  });
  $('#find-next').addEventListener('click', () => search(false, true));
  $('#find-prev').addEventListener('click', () => search(false, false));
  $('#find-close').addEventListener('click', () => closeFind());

  // ---------- Downloads ----------
  const RING = 2 * Math.PI * 11;

  function renderDownloadsButton() {
    el.downloadsBtn.hidden = false;
    const active = downloads.filter((d) => d.state === 'progressing');
    const total = active.reduce((s, d) => s + (d.total || 0), 0);
    const got = active.reduce((s, d) => s + (d.received || 0), 0);
    const frac = active.length ? (total ? got / total : 0.15) : 1;
    el.downloadsBtn.classList.toggle('done', downloads.length > 0 && !active.length);
    el.downloadsBtn.title = active.length ? `Downloading ${active.length} file${active.length > 1 ? 's' : ''}` : 'Downloads';
    el.downloadsBtn.innerHTML =
      I.download +
      (active.length
        ? `<svg class="ring" viewBox="0 0 26 26"><circle class="track" cx="13" cy="13" r="11"/><circle class="bar" cx="13" cy="13" r="11" stroke-dasharray="${RING}" stroke-dashoffset="${RING * (1 - frac)}"/></svg>`
        : '');
  }

  function downloadStatus(d) {
    if (d.state === 'completed') return `${fmtBytes(d.received)} • Done`;
    if (d.state === 'cancelled') return 'Canceled';
    if (d.state === 'interrupted') return 'Failed';
    if (d.paused) return `Paused • ${fmtBytes(d.received)}`;
    return d.total ? `${fmtBytes(d.received)} of ${fmtBytes(d.total)}` : fmtBytes(d.received);
  }

  function renderDownloadsPanel() {
    el.dlPanel.hidden = !dlOpen;
    if (!dlOpen) return;
    el.dlList.replaceChildren();
    if (!downloads.length) {
      const p = document.createElement('div');
      p.className = 'dl';
      p.innerHTML = '<div class="meta"><div class="sub">Files you download will show up here.</div></div>';
      el.dlList.append(p);
      return;
    }
    for (const d of downloads.slice(0, 20)) {
      const item = document.createElement('div');
      const failed = d.state === 'cancelled' || d.state === 'interrupted';
      item.className = 'dl' + (d.state === 'completed' ? ' clickable' : '') + (failed ? ' failed' : '');
      item.title = d.state === 'completed' ? `Open ${d.filename}` : d.filename;
      const icon = document.createElement('span');
      icon.className = 'ficon';
      icon.innerHTML = I.file;
      const meta = document.createElement('div');
      meta.className = 'meta';
      const name = document.createElement('div');
      name.className = 'name';
      name.textContent = d.filename;
      const sub = document.createElement('div');
      sub.className = 'sub';
      sub.textContent = downloadStatus(d);
      meta.append(name, sub);
      if (d.state === 'progressing' && d.total) {
        const bar = document.createElement('div');
        bar.className = 'bar';
        bar.innerHTML = `<i style="width:${Math.min(100, (d.received / d.total) * 100).toFixed(1)}%"></i>`;
        meta.append(bar);
      }
      const action = document.createElement('button');
      action.className = 'icon-btn small';
      if (d.state === 'progressing') {
        action.innerHTML = I.stop;
        action.title = 'Cancel download';
        action.addEventListener('click', (e) => {
          e.stopPropagation();
          tp.downloadAction(d.id, 'cancel');
        });
      } else {
        action.innerHTML = I.folder;
        action.title = 'Show in Finder';
        action.addEventListener('click', (e) => {
          e.stopPropagation();
          tp.downloadAction(d.id, 'show');
        });
      }
      item.append(icon, meta, action);
      if (d.state === 'completed') item.addEventListener('click', () => tp.downloadAction(d.id, 'open'));
      el.dlList.append(item);
    }
  }

  el.downloadsBtn.addEventListener('click', () => {
    dlOpen = !dlOpen;
    renderDownloadsPanel();
  });
  $('#dl-clear').addEventListener('click', () => tp.clearDownloads());
  $('#dl-folder').addEventListener('click', () => tp.openDownloadsFolder());

  function setDownloads(list) {
    downloads = Array.isArray(list) ? list : [];
    for (const d of downloads) {
      if (!seenDownloads.has(d.id)) {
        seenDownloads.add(d.id);
        dlOpen = true; // a new download opens the panel
      }
    }
    renderDownloadsButton();
    renderDownloadsPanel();
  }

  // ---------- Toasts ----------
  let toastTimer = null;
  function showToast({ text, actionLabel, actionId }) {
    clearTimeout(toastTimer);
    el.toast.hidden = false;
    el.toast.style.animation = 'none';
    void el.toast.offsetWidth;
    el.toast.style.animation = '';
    el.toast.querySelector('.t-text').textContent = text;
    const btn = el.toast.querySelector('.t-action');
    btn.textContent = actionLabel || '';
    btn.onclick = actionId
      ? () => {
          tp.toastAction(actionId);
          el.toast.hidden = true;
        }
      : null;
    toastTimer = setTimeout(() => {
      el.toast.hidden = true;
    }, actionLabel ? 6000 : 3500);
  }

  // ---------- Sidebar resizing ----------
  function setSidebarWidth(w) {
    const width = Math.max(200, Math.min(420, Math.round(w)));
    document.documentElement.style.setProperty('--sbw', `${width}px`);
    return width;
  }
  $('#resizer').addEventListener('mousedown', (e) => {
    e.preventDefault();
    const startX = e.clientX;
    const startW = el.sidebar.getBoundingClientRect().width;
    let w = startW;
    const move = (ev) => {
      w = setSidebarWidth(startW + ev.clientX - startX);
    };
    const up = () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
      tp.setSidebarWidth(w);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  });

  // ---------- Drop links onto the sidebar to open them ----------
  document.addEventListener('dragover', (e) => {
    if (e.dataTransfer.types.includes('application/x-tp-tab')) return;
    if (e.dataTransfer.types.includes('text/uri-list') || e.dataTransfer.types.includes('text/plain')) e.preventDefault();
  });
  document.addEventListener('drop', (e) => {
    if (e.dataTransfer.types.includes('application/x-tp-tab')) return;
    e.preventDefault();
    const raw = e.dataTransfer.getData('text/uri-list') || e.dataTransfer.getData('text/plain');
    const url = (raw || '').split('\n').find((l) => l && !l.startsWith('#'));
    if (url) tp.newTab(url.trim());
  });

  // ---------- Render all ----------
  function render() {
    document.body.classList.toggle('collapsed', !!state.collapsed);
    document.body.classList.toggle('split', !!state.split);
    applySpaceTheme();
    renderSpaces();
    renderTabs();
    renderFavorites();
    renderUrlbars();
    renderNav();
    renderFocus();
    requestAnimationFrame(reportLayout);
  }

  // ---------- Events from the main process ----------
  tp.onInit((data) => {
    document.body.classList.toggle('mac', data.platform === 'darwin');
    document.body.classList.toggle('fullscreen', !!data.fullscreen);
    settings = data.settings || settings;
    setSidebarWidth(settings.sidebarWidth || 264);
    favorites = data.favorites || [];
    setDownloads(data.downloads || []);
    dlOpen = false;
    renderDownloadsPanel();
    render();
  });

  tp.onState((s) => {
    const spaceChanged = s.spaceId !== state.spaceId;
    const from = state.spaces.findIndex((x) => x.id === state.spaceId);
    const to = s.spaces.findIndex((x) => x.id === s.spaceId);
    state = s;
    if (spaceChanged) closeFind(false);
    spaceJustChanged = spaceChanged && from !== -1;
    render();
    spaceJustChanged = false;
    // Switching spaces: the tab list glides in from the side of the new space.
    if (spaceChanged && from !== -1 && to !== -1 && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
      const list = el.tabsScroll;
      list.classList.remove('slide-l', 'slide-r');
      void list.offsetWidth;
      list.classList.add(to > from ? 'slide-r' : 'slide-l');
      setTimeout(() => list.classList.remove('slide-l', 'slide-r'), 450);
    }
  });

  tp.onFavorites((list) => {
    favorites = list || [];
    renderFavorites();
  });

  tp.onSettings((s) => {
    settings = s;
    render();
  });

  tp.onDownloads(setDownloads);
  tp.onToast(showToast);
  tp.onFullscreen((on) => {
    document.body.classList.toggle('fullscreen', !!on);
    requestAnimationFrame(reportLayout);
  });

  tp.onFindResult(({ active, total }) => {
    if (!el.findInput.value) return;
    el.findCount.textContent = total ? `${active} of ${total}` : 'No matches';
    el.findInput.classList.toggle('none', !total);
  });
  tp.onFindClose(() => closeFind(false));

  tp.onCommand((cmd) => {
    const name = typeof cmd === 'string' ? cmd : cmd && cmd.name;
    if (name === 'find-open') openFind();
    else if (name === 'find-next' || name === 'find-prev') {
      if (el.findbar.hidden) openFind();
      else search(false, name === 'find-next');
    } else if (name === 'rename-space') {
      if (state.collapsed) tp.toggleSidebar();
      setTimeout(() => startRename(cmd.id), 60);
    }
  });

  // For extras.js (TP AI, reader view, sheets).
  window.TPSidebar = { toast: (text) => showToast({ text }), reportLayout, state: () => state, settings: () => settings };

  reportLayout();
})();
