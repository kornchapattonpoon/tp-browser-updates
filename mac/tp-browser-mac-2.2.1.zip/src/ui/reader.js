'use strict';
/* TP Browser reader view: finds the article on a page (title, text, pictures) and leaves out menus,
 * ads, comments and "related" boxes. extract() runs inside the website's tab, so it must not use
 * anything from outside its own body. */
(function (global) {
  function extract() {
    try {
      var BAD = /(^|[\s_-])(comments?|share|sharing|social|related|promo|advert\w*|ads?|sponsor\w*|footer|nav|navbar|menu|subscribe|newsletter|cookie\w*|banner|popup|modal|sidebar|widget|breadcrumbs?|toolbar|signup|login|recommend\w*|outbrain|taboola|disqus|paywall|masthead)([\s_-]|$)/i;
      var GOOD = /article|content|main|post|story|entry|body|text/i;
      var SKIP = { NAV: 1, ASIDE: 1, FOOTER: 1, FORM: 1, BUTTON: 1, SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, SVG: 1, IFRAME: 1, SELECT: 1, INPUT: 1, TEXTAREA: 1, DIALOG: 1, TEMPLATE: 1, CANVAS: 1, VIDEO: 1, AUDIO: 1 };
      var INLINE = /^(A|B|I|EM|STRONG|SPAN|BR|SMALL|SUP|SUB|CODE|MARK|U|ABBR|TIME|Q|S|CITE|FONT|WBR|DFN|KBD|VAR|DEL|INS)$/;

      var text = function (el) {
        return (el.innerText || el.textContent || '').replace(/[ \t ]+/g, ' ').replace(/\s*\n\s*/g, '\n').trim();
      };
      var oneLine = function (s) {
        return s.replace(/\s+/g, ' ').trim();
      };
      var hidden = function (el) {
        if (!el.getClientRects().length) return true;
        var cs = getComputedStyle(el);
        return cs.visibility === 'hidden' || cs.display === 'none' || cs.opacity === '0';
      };
      var bad = function (el) {
        var name = (el.id || '') + ' ' + (typeof el.className === 'string' ? el.className : '') + ' ' + (el.getAttribute('role') || '') + ' ' + (el.getAttribute('aria-label') || '');
        if (/^(navigation|banner|contentinfo|complementary|dialog|alert)$/.test(el.getAttribute('role') || '')) return true;
        return BAD.test(name) && !GOOD.test(el.id || '') && el.tagName !== 'ARTICLE' && el.tagName !== 'MAIN';
      };
      var linkDensity = function (el) {
        var total = text(el).length || 1;
        var links = 0;
        var as = el.querySelectorAll('a');
        for (var i = 0; i < as.length; i++) links += (as[i].innerText || '').length;
        return links / total;
      };

      // 1. The element that holds the most real paragraph text wins.
      var scores = new Map();
      var paras = document.querySelectorAll('p, pre, blockquote, li');
      for (var i = 0; i < paras.length && i < 3000; i++) {
        var p = paras[i];
        var t = p.innerText || '';
        if (t.length < 40) continue;
        var score = 1 + Math.min(3, Math.floor(t.length / 100)) + (t.split(/[,،、，]/).length - 1) * 0.25;
        var parent = p.parentElement;
        var grand = parent && parent.parentElement;
        if (parent) scores.set(parent, (scores.get(parent) || 0) + score);
        if (grand) scores.set(grand, (scores.get(grand) || 0) + score / 2);
      }
      var best = null;
      var bestScore = 0;
      scores.forEach(function (s, el) {
        if (el === document.documentElement) return;
        var adj = s * (1 - Math.min(0.9, linkDensity(el)));
        if (el.tagName === 'ARTICLE' || el.tagName === 'MAIN' || el.getAttribute('itemprop') === 'articleBody') adj *= 1.3;
        if (bad(el)) adj *= 0.3;
        if (adj > bestScore) {
          bestScore = adj;
          best = el;
        }
      });
      if (!best) best = document.querySelector('article') || document.querySelector('main,[role=main]') || document.body;
      // An <article> that contains the winner usually holds its heading and pictures too.
      var art = best.closest ? best.closest('article') : null;
      if (art && text(art).length < text(best).length * 1.6) best = art;

      // 2. Walk the article in order and keep headings, paragraphs, lists, quotes and pictures.
      var blocks = [];
      var seen = {};
      var chars = 0;
      var img = function (im) {
        var src = im.currentSrc || im.src || '';
        // Pictures that load later ("lazy") keep their real address in a data- attribute.
        if (!/^https:/.test(src)) src = im.getAttribute('data-src') || im.getAttribute('data-lazy-src') || im.getAttribute('data-original') || '';
        if (!/^https:/.test(src) || seen[src]) return;
        var w = im.naturalWidth || parseInt(im.getAttribute('width') || '0', 10) || (im.complete ? 0 : im.width) || 0;
        if (w && w < 160) return;
        seen[src] = 1;
        blocks.push({ t: 'img', src: src, alt: oneLine(im.alt || '').slice(0, 200) });
      };
      var onlyInline = function (el) {
        for (var k = el.firstElementChild; k; k = k.nextElementSibling) if (!INLINE.test(k.tagName)) return false;
        return true;
      };
      var addText = function (type, el, extra) {
        var x = type === 'pre' ? text(el) : oneLine(text(el));
        if (!x) return;
        var b = { t: type, x: x.slice(0, 6000) };
        if (extra) for (var key in extra) b[key] = extra[key];
        blocks.push(b);
        chars += x.length;
      };
      var walk = function (el, depth) {
        if (depth > 30) return;
        for (var c = el.firstElementChild; c; c = c.nextElementSibling) {
          var tag = c.tagName;
          if (SKIP[tag] || bad(c) || hidden(c)) continue;
          if (/^H[1-6]$/.test(tag)) {
            var h = oneLine(text(c));
            if (h && h.length < 220) blocks.push({ t: 'h', x: h, l: Number(tag[1]) });
            continue;
          }
          if (tag === 'P') {
            if (linkDensity(c) < 0.6) addText('p', c);
            var ims = c.querySelectorAll('img');
            for (var a = 0; a < ims.length; a++) img(ims[a]);
            continue;
          }
          if (tag === 'BLOCKQUOTE') {
            addText('q', c);
            continue;
          }
          if (tag === 'PRE') {
            addText('pre', c);
            continue;
          }
          if (tag === 'UL' || tag === 'OL') {
            if (linkDensity(c) > 0.5) continue;
            for (var li = c.firstElementChild; li; li = li.nextElementSibling) {
              if (li.tagName === 'LI' && !hidden(li)) addText('li', li, { o: tag === 'OL' });
            }
            continue;
          }
          if (tag === 'IMG') {
            img(c);
            continue;
          }
          if (tag === 'FIGURE' || tag === 'PICTURE') {
            var fi = c.querySelector('img');
            if (fi) img(fi);
            var cap = c.querySelector('figcaption');
            if (cap && text(cap)) blocks.push({ t: 'cap', x: oneLine(text(cap)).slice(0, 400) });
            continue;
          }
          if (tag === 'TABLE' || tag === 'HEADER') continue;
          if (!c.firstElementChild || onlyInline(c)) {
            var x2 = oneLine(text(c));
            if (x2.length > 60 && linkDensity(c) < 0.5) addText('p', c);
            continue;
          }
          walk(c, depth + 1);
        }
      };
      walk(best, 0);

      // Not much found: take every real paragraph on the page instead.
      if (chars < 300) {
        blocks = [];
        chars = 0;
        var ps = document.querySelectorAll('p');
        for (var j = 0; j < ps.length; j++) {
          if (!hidden(ps[j]) && (ps[j].innerText || '').length > 50 && linkDensity(ps[j]) < 0.5) addText('p', ps[j]);
        }
      }

      var meta = function (n) {
        var m = document.querySelector('meta[property="' + n + '"],meta[name="' + n + '"]');
        return m ? oneLine(m.getAttribute('content') || '') : '';
      };
      var h1 = document.querySelector('article h1') || document.querySelector('h1');
      var title = (h1 && oneLine(text(h1))) || meta('og:title') || document.title || '';
      var same = function (a, b) {
        return oneLine(a).toLowerCase() === oneLine(b).toLowerCase();
      };
      for (var k2 = 0; k2 < blocks.length && k2 < 4; k2++) {
        if (blocks[k2].t === 'h' && same(blocks[k2].x, title)) {
          blocks.splice(k2, 1);
          break;
        }
      }
      var by = document.querySelector('[rel=author], [itemprop=author], .byline, .author-name, .author');
      var byline = meta('author') || (by ? oneLine(text(by)) : '');
      if (byline.length > 80 || /^https?:/.test(byline)) byline = '';
      // "By Jane Doe · 12 May" at the top is already shown under the title.
      for (var k3 = 0; k3 < blocks.length && k3 < 4; k3++) {
        var bx = blocks[k3].x || '';
        if (blocks[k3].t === 'p' && bx.length < 140 && /^(by|written by|words by|โดย)\s/i.test(bx) && (!byline || bx.indexOf(byline) >= 0)) {
          blocks.splice(k3, 1);
          break;
        }
      }
      return JSON.stringify({
        ok: chars >= 250,
        title: title.slice(0, 300),
        byline: byline,
        site: meta('og:site_name') || location.hostname.replace(/^www\./, ''),
        lang: document.documentElement.lang || '',
        dir: getComputedStyle(document.body || document.documentElement).direction === 'rtl' ? 'rtl' : 'ltr',
        url: location.href,
        blocks: blocks.slice(0, 700),
        chars: chars,
      });
    } catch (e) {
      return JSON.stringify({ error: String(e && e.message ? e.message : e) });
    }
  }

  global.TPReader = {
    extract: extract,
    script: function () {
      return '(' + extract.toString() + ')()';
    },
  };
})(typeof window !== 'undefined' ? window : globalThis);
