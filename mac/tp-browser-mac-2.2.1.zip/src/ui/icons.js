'use strict';
// Small stroke icons (24x24, currentColor).
(function () {
  const svg = (body, extra = '') =>
    `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" ${extra}>${body}</svg>`;

  window.ICONS = {
    back: svg('<path d="M19 12H5"/><path d="M11 18l-6-6 6-6"/>'),
    forward: svg('<path d="M5 12h14"/><path d="M13 6l6 6-6 6"/>'),
    reload: svg('<path d="M20.5 12a8.5 8.5 0 1 1-2.6-6.1"/><path d="M20.5 3.5v5h-5"/>'),
    stop: svg('<path d="M17 7L7 17"/><path d="M7 7l10 10"/>'),
    sidebar: svg('<rect x="3.5" y="4.5" width="17" height="15" rx="3"/><path d="M9.5 4.5v15"/>'),
    plus: svg('<path d="M12 5v14"/><path d="M5 12h14"/>'),
    close: svg('<path d="M16.5 7.5l-9 9"/><path d="M7.5 7.5l9 9"/>', 'stroke-width="2.1"'),
    star: svg('<path d="M12 3.6l2.55 5.2 5.75.84-4.15 4.05.98 5.72L12 16.7l-5.13 2.7.98-5.72L3.7 9.64l5.75-.84z"/>'),
    starFilled: svg('<path d="M12 3.6l2.55 5.2 5.75.84-4.15 4.05.98 5.72L12 16.7l-5.13 2.7.98-5.72L3.7 9.64l5.75-.84z" fill="currentColor"/>'),
    lock: svg('<rect x="5" y="10.5" width="14" height="10" rx="2.5"/><path d="M8.5 10.5V7.5a3.5 3.5 0 0 1 7 0v3"/>'),
    info: svg('<circle cx="12" cy="12" r="8.5"/><path d="M12 16v-4.5"/><path d="M12 8h.01"/>'),
    search: svg('<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/>'),
    file: svg('<path d="M14 3.5H7.5a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h9a2 2 0 0 0 2-2V8z"/><path d="M14 3.5V8h4.5"/>'),
    globe: svg('<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17"/><path d="M12 3.5c2.3 2.4 3.4 5.2 3.4 8.5s-1.1 6.1-3.4 8.5c-2.3-2.4-3.4-5.2-3.4-8.5s1.1-6.1 3.4-8.5z"/>'),
    download: svg('<path d="M12 4v11"/><path d="M7 10.5l5 5 5-5"/><path d="M5 20h14"/>'),
    more: svg('<circle cx="5.5" cy="12" r="1.3" fill="currentColor"/><circle cx="12" cy="12" r="1.3" fill="currentColor"/><circle cx="18.5" cy="12" r="1.3" fill="currentColor"/>'),
    speaker: svg('<path d="M11 5.5L6.5 9H3.5v6h3l4.5 3.5z"/><path d="M15.5 9a4.5 4.5 0 0 1 0 6"/><path d="M18.5 6.5a8 8 0 0 1 0 11"/>'),
    muted: svg('<path d="M11 5.5L6.5 9H3.5v6h3l4.5 3.5z"/><path d="M21 9.5l-5 5"/><path d="M16 9.5l5 5"/>'),
    folder: svg('<path d="M3.5 7.5a2 2 0 0 1 2-2h3.8l2 2h7.2a2 2 0 0 1 2 2v7.5a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2z"/>'),
    up: svg('<path d="M6 15l6-6 6 6"/>'),
    down: svg('<path d="M6 9l6 6 6-6"/>'),
    copy: svg('<rect x="8.5" y="8.5" width="11" height="11" rx="2.5"/><path d="M15.5 8.5V6.5a2 2 0 0 0-2-2h-7a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h2"/>'),
    shield: svg('<path d="M12 3.5l7 2.8v5.4c0 4.3-2.9 7.6-7 8.8-4.1-1.2-7-4.5-7-8.8V6.3z"/><path d="M9 12l2 2 4-4"/>'),
    shieldOff: svg('<path d="M12 3.5l7 2.8v5.4c0 4.3-2.9 7.6-7 8.8-4.1-1.2-7-4.5-7-8.8V6.3z"/><path d="M4 4l16 16"/>'),
    split: svg('<rect x="3.5" y="4.5" width="17" height="15" rx="3"/><path d="M12 4.5v15"/>'),
    target: svg('<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1" fill="currentColor"/>'),
    moon: svg('<path d="M19.5 14.5A8 8 0 1 1 9.5 4.5a6.5 6.5 0 0 0 10 10z"/>'),
    command: svg('<path d="M9 6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3z"/>'),
    sparkle: svg('<path d="M12 3l1.9 5.6L19.5 10.5l-5.6 1.9L12 18l-1.9-5.6L4.5 10.5l5.6-1.9z"/>'),
    send: svg('<path d="M12 19V5"/><path d="M5.5 11.5L12 5l6.5 6.5"/>', 'stroke-width="2.4"'),
    stopsq: svg('<rect x="7" y="7" width="10" height="10" rx="2" fill="currentColor" stroke="none"/>'),
    newchat: svg('<path d="M20 12.5V18a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.5"/><path d="M17.5 3.5l3 3L13 14h-3v-3z"/>'),
    sliders: svg('<path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/>'),
    mic: svg('<rect x="9" y="3.5" width="6" height="11" rx="3"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0"/><path d="M12 17.5V20.5"/>'),
    reader: svg('<path d="M4 5.5h6.5a2.5 2.5 0 0 1 2.5 2.5v11a2 2 0 0 0-2-2H4z"/><path d="M20 5.5h-6.5A2.5 2.5 0 0 0 11 8"/><path d="M13 19a2 2 0 0 1 2-2h5V5.5"/>'),
    translate: svg('<path d="M4 6h9"/><path d="M8.5 4v2"/><path d="M11 6c-.6 3.6-3 6.6-6.5 8"/><path d="M6.5 9.5c1.2 2 3 3.6 5 4.5"/><path d="M12.5 20l4-9 4 9"/><path d="M14 17h5"/>'),
    qr: svg('<rect x="4" y="4" width="6" height="6" rx="1.2"/><rect x="14" y="4" width="6" height="6" rx="1.2"/><rect x="4" y="14" width="6" height="6" rx="1.2"/><path d="M14 14h2.5v2.5H14z" fill="currentColor"/><path d="M17.5 17.5H20V20h-2.5z" fill="currentColor"/>'),
    play: svg('<path d="M8 5.5v13l10.5-6.5z" fill="currentColor"/>', 'stroke-width="1.6"'),
    pause: svg('<rect x="6.5" y="5" width="3.6" height="14" rx="1.2" fill="currentColor" stroke="none"/><rect x="13.9" y="5" width="3.6" height="14" rx="1.2" fill="currentColor" stroke="none"/>'),
    prev: svg('<path d="M18 6l-8 6 8 6z" fill="currentColor"/><path d="M6.5 6v12"/>', 'stroke-width="2"'),
    next: svg('<path d="M6 6l8 6-8 6z" fill="currentColor"/><path d="M17.5 6v12"/>', 'stroke-width="2"'),
    textsize: svg('<path d="M3.5 18l4-10 4 10"/><path d="M5 14.5h5"/><path d="M13 18l3.5-8.5L20 18"/><path d="M14.2 15.2h4.6"/>'),
    check: svg('<path d="M5 12.5l4.5 4.5L19 7.5"/>', 'stroke-width="2.3"'),
    share: svg('<path d="M12 3.5v11"/><path d="M8 7.5l4-4 4 4"/><path d="M5.5 11.5v6.5a2 2 0 0 0 2 2h9a2 2 0 0 0 2-2v-6.5"/>'),
    camera: svg('<path d="M4 8V6a2 2 0 0 1 2-2h2"/><path d="M16 4h2a2 2 0 0 1 2 2v2"/><path d="M20 16v2a2 2 0 0 1-2 2h-2"/><path d="M8 20H6a2 2 0 0 1-2-2v-2"/><circle cx="12" cy="12" r="3"/>'),
  };

  // Elements with data-icon="name" get their icon filled in (used by TP AI's panel).
  window.fillIcons = function (root) {
    (root || document).querySelectorAll('[data-icon]').forEach(function (el) {
      const name = el.getAttribute('data-icon');
      if (window.ICONS[name] && el.getAttribute('data-icon-done') !== name) {
        el.innerHTML = window.ICONS[name];
        el.setAttribute('data-icon-done', name);
      }
    });
  };
})();
