'use strict';
/* TP Browser for Mac, new in 2.2: the TP AI panel, reader view with read-aloud, QR and
 * "what's new" sheets, and the update chip. TP AI itself (ai.js), reader extraction (reader.js),
 * QR codes (qr.js) and the helpers in core.js are shared with TP Browser for Android. */
(function () {
  const tp = window.tp;
  const C = window.TPCore;
  const I = window.ICONS;
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
  // The main process tells the page it's on macOS (Dictation and the share sheet are Mac features).
  const isMac = () => document.body.classList.contains('mac');

  let state = { tabs: [], activeId: null, spaceId: null, spaces: [] };
  let settings = { name: '', searchEngine: 'google', focusSites: [], speechRate: 1 };
  const store = { aichat: null, aicfg: null, uiprefs: null };
  let prefs = { reader: { size: 19, font: 'serif', theme: 'auto' } };
  let ai = null;

  // ------------------------------------------------------------------------------------------
  // Small helpers (same shape as the Android interface, so ai.js works unchanged)
  // ------------------------------------------------------------------------------------------

  function el(tag, props) {
    const e = document.createElement(tag);
    if (props) {
      for (const k of Object.keys(props)) {
        const v = props[k];
        if (v == null || v === false) continue;
        if (k === 'class') e.className = v;
        else if (k === 'text') e.textContent = v;
        else if (k === 'html') e.innerHTML = v;
        else if (k === 'style') e.style.cssText = v;
        else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), v);
        else e.setAttribute(k, v === true ? '' : v);
      }
    }
    for (let i = 2; i < arguments.length; i++) append(e, arguments[i]);
    return e;
  }

  function append(parent, kid) {
    if (kid == null || kid === false) return;
    if (Array.isArray(kid)) kid.forEach((k) => append(parent, k));
    else parent.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }

  function icon(name) {
    const s = document.createElement('span');
    s.className = 'ic';
    s.innerHTML = I[name] || '';
    return s;
  }

  function toast(text) {
    if (window.TPSidebar) window.TPSidebar.toast(text);
  }

  const dark = () => matchMedia('(prefers-color-scheme: dark)').matches;

  // ------------------------------------------------------------------------------------------
  // The page area can be covered by the sidebar page (reader view, sheets)
  // ------------------------------------------------------------------------------------------

  const covers = new Set();

  const frames = (n) => new Promise((r) => {
    const step = () => (--n <= 0 ? r() : requestAnimationFrame(step));
    requestAnimationFrame(step);
  });

  async function coverOn(key, snapshot) {
    const first = covers.size === 0;
    covers.add(key);
    if (!first) return;
    if (snapshot) {
      // A picture of the page goes underneath first, so nothing flickers when the page steps aside.
      const shot = await tp.cover(true, { snapshot: true, captureOnly: true });
      if (!covers.size) return;
      if (shot) {
        const box = $('#snapshot');
        box.style.backgroundImage = 'url("' + shot + '")';
        box.hidden = false;
        await frames(2);
        if (!covers.size) return;
      }
    }
    await tp.cover(true, {});
  }

  function coverOff(key) {
    if (!covers.delete(key) || covers.size) return;
    $('#snapshot').hidden = true;
    $('#snapshot').style.backgroundImage = '';
    tp.cover(false, {});
  }

  // ------------------------------------------------------------------------------------------
  // Sheets (modals)
  // ------------------------------------------------------------------------------------------

  let modalKind = null;
  let modalOnClose = null;

  function openModal(kind, build, opts) {
    opts = opts || {};
    const layer = $('#modal-layer');
    const box = $('#modal');
    const wasOpen = !!modalKind;
    modalKind = kind;
    modalOnClose = opts.onClose || null;
    box.className = 'modal modal-' + kind;
    box.textContent = '';
    build(box);
    window.fillIcons(box);
    if (!wasOpen) {
      // Over a website, a picture of it stays behind the sheet; the reader view is already in place.
      coverOn('modal', $('#reader').hidden);
      layer.hidden = false;
      layer.classList.remove('out');
      if (!reducedMotion) {
        layer.classList.remove('in');
        void layer.offsetWidth;
        layer.classList.add('in');
      }
    }
    // Return presses the main button; focusing it mustn't scroll a long sheet.
    const first = box.querySelector('button.btn:not(.ghost)') || box.querySelector('button');
    if (first) setTimeout(() => first.focus({ preventScroll: true }), 60);
  }

  function closeModal() {
    if (!modalKind) return;
    const done = modalOnClose;
    modalKind = null;
    modalOnClose = null;
    const layer = $('#modal-layer');
    const finish = () => {
      if (modalKind) return;
      layer.hidden = true;
      layer.classList.remove('out', 'in');
      coverOff('modal');
    };
    if (reducedMotion) finish();
    else {
      layer.classList.remove('in');
      layer.classList.add('out');
      setTimeout(finish, 200);
    }
    if (done) done();
  }

  $('#modal-backdrop').addEventListener('click', closeModal);

  function sheetHead(title, sub, iconHtml) {
    return el('div', { class: 'm-head' },
      iconHtml ? el('div', { class: 'm-icon', html: iconHtml }) : null,
      el('h3', { text: title }),
      sub ? el('p', { text: sub }) : null);
  }

  // ------------------------------------------------------------------------------------------
  // Read aloud: the Mac's own voices (Web Speech). Same API as Android's native one.
  // ------------------------------------------------------------------------------------------

  const speech = { seq: 0, items: [], index: -1, playing: false, owner: '' };
  const speechListeners = [];
  let warnedThai = false;

  function speechEmit() {
    speechListeners.forEach((fn) => {
      try {
        fn(speech);
      } catch (e) {
        // keep going
      }
    });
  }

  function voiceFor(lang) {
    if (!window.speechSynthesis) return null;
    const want = lang === 'th' ? 'th' : lang === 'en' ? 'en' : lang;
    if (!want) return null;
    const list = speechSynthesis.getVoices().filter((v) => v.lang && v.lang.toLowerCase().replace('_', '-').indexOf(want.toLowerCase()) === 0);
    if (!list.length) return null;
    const score = (v) => (/premium|enhanced|siri/i.test(v.name) ? 4 : 0) + (v.localService ? 2 : 0) + (/en-us/i.test(v.lang) ? 1 : 0) + (v.default ? 1 : 0);
    return list.sort((a, b) => score(b) - score(a))[0];
  }

  function speechFrom(index) {
    if (!window.speechSynthesis) {
      toast('Read aloud isn’t available here');
      return;
    }
    speech.seq++;
    const seq = speech.seq;
    speechSynthesis.cancel();
    speech.index = index;
    speech.playing = true;
    for (let k = index; k < speech.items.length; k++) {
      const it = speech.items[k];
      const u = new SpeechSynthesisUtterance(it.text);
      const v = voiceFor(it.lang);
      if (v) {
        u.voice = v;
        u.lang = v.lang;
      } else if (it.lang) {
        u.lang = it.lang === 'th' ? 'th-TH' : it.lang === 'en' ? 'en-US' : it.lang;
        if (it.lang === 'th' && !warnedThai) {
          warnedThai = true;
          toast('For Thai, add a Thai voice: System Settings → Accessibility → Spoken Content → System Voice → Manage Voices');
        }
      }
      u.rate = Number(settings.speechRate) || 1;
      u.onstart = () => {
        if (seq !== speech.seq) return;
        speech.index = k;
        speech.playing = true;
        speechEmit();
      };
      const ended = () => {
        if (seq !== speech.seq || k < speech.items.length - 1) return;
        speech.seq++;
        speech.playing = false;
        speech.index = -1;
        speech.items = [];
        speech.owner = '';
        speechEmit();
      };
      u.onend = ended;
      u.onerror = (e) => {
        if (e && (e.error === 'interrupted' || e.error === 'canceled')) return;
        ended();
      };
      speechSynthesis.speak(u);
    }
    speechEmit();
  }

  function speak(items, opts) {
    opts = opts || {};
    speech.items = (items || []).filter((x) => x && x.text && String(x.text).trim());
    speech.owner = opts.owner || '';
    if (!speech.items.length) return stopSpeech();
    speechFrom(Math.max(0, Math.min(opts.start || 0, speech.items.length - 1)));
  }

  function pauseSpeech() {
    if (!speech.playing) return;
    speech.seq++;
    if (window.speechSynthesis) speechSynthesis.cancel();
    speech.playing = false;
    speechEmit();
  }

  function resumeSpeech() {
    if (speech.items.length) speechFrom(Math.max(0, speech.index));
  }

  function stopSpeech() {
    speech.seq++;
    if (window.speechSynthesis) speechSynthesis.cancel();
    speech.playing = false;
    speech.items = [];
    speech.index = -1;
    speech.owner = '';
    speechEmit();
  }

  function speakText(owner, text, lang) {
    if (speech.owner === owner && speech.playing) return stopSpeech();
    const parts = [];
    String(text || '').split(/\n+/).forEach((line) => C.splitSpeech(line, 1000).forEach((p) => parts.push({ text: p, lang: lang || C.speechLang(p, '') })));
    speak(parts, { owner });
  }

  if (window.speechSynthesis) speechSynthesis.onvoiceschanged = () => {};

  // ------------------------------------------------------------------------------------------
  // Voice typing: the Mac's own Dictation
  // ------------------------------------------------------------------------------------------

  let dictatedAt = 0;
  let typedSinceDictation = false;

  function startDictation() {
    if (speech.playing) stopSpeech();
    const q = $('#ai-q');
    q.focus();
    dictatedAt = Date.now();
    typedSinceDictation = false;
    const hint = $('#ai-dictation');
    hint.hidden = false;
    $('#ai-dictation-text').textContent = 'Speak now, then press Return. (No mic? Turn on Dictation in System Settings → Keyboard)';
    clearTimeout(startDictation.timer);
    startDictation.timer = setTimeout(() => {
      hint.hidden = true;
    }, 12000);
    tp.dictate();
  }

  /** Was the question just sent spoken (dictated) rather than typed? */
  function consumeVoice() {
    const spoken = dictatedAt && Date.now() - dictatedAt < 120000 && !typedSinceDictation;
    dictatedAt = 0;
    $('#ai-dictation').hidden = true;
    return !!spoken;
  }

  $('#ai-q').addEventListener('keydown', (e) => {
    if (e.key && e.key.length === 1 && !e.metaKey && !e.ctrlKey) typedSinceDictation = true;
  });

  // ------------------------------------------------------------------------------------------
  // TP AI panel
  // ------------------------------------------------------------------------------------------

  function mapTab(t) {
    if (!t) return null;
    return {
      id: String(t.id),
      space: t.spaceId,
      url: t.internal ? '' : t.url || '',
      title: t.title || '',
      home: !t.url || !!t.internal,
      live: !t.sleeping,
      loading: !!t.loading,
      back: !!t.canGoBack,
      fwd: !!t.canGoForward,
    };
  }

  const tabsNow = () => state.tabs.map(mapTab);
  const activeRaw = () => state.tabs.find((t) => t.id === state.activeId) || null;

  // Waiting for a tab to finish loading (TP AI opens pages and reads them).
  const loadWaiters = [];

  function waitForLoad(id, timeout) {
    return new Promise((resolve) => {
      const w = { id: String(id), resolve, seenLoading: false, at: Date.now(), done: false };
      loadWaiters.push(w);
      const finish = (ok) => {
        if (w.done) return;
        w.done = true;
        loadWaiters.splice(loadWaiters.indexOf(w), 1);
        setTimeout(() => resolve(ok), ok ? 400 : 0);
      };
      w.finish = finish;
      setTimeout(() => finish(false), timeout || 12000);
      setTimeout(() => checkWaiter(w), 1200);
    });
  }

  function checkWaiter(w) {
    if (w.done) return;
    const t = state.tabs.find((x) => String(x.id) === w.id);
    if (!t) return w.finish(false);
    if (t.loading) w.seenLoading = true;
    else if (t.url && (w.seenLoading || Date.now() - w.at >= 1200)) w.finish(true);
  }

  // Requests to the AI service go through the main process, streamed.
  const pendingReq = new Map();
  let reqSeq = 0;

  function aiRequest(url, opts) {
    opts = opts || {};
    const id = 'r' + ++reqSeq + '-' + Date.now().toString(36);
    let resolveFn;
    const promise = new Promise((r) => {
      resolveFn = r;
    });
    const entry = { resolve: resolveFn, onChunk: opts.onChunk };
    entry.timer = setTimeout(() => {
      if (pendingReq.delete(id)) {
        tp.ai.abort(id);
        resolveFn({ status: 0, body: '', error: 'timeout' });
      }
    }, opts.timeout || 60000);
    pendingReq.set(id, entry);
    tp.ai.request(id, url, opts.method || 'GET', opts.headers || {}, opts.body || '', !!opts.stream);
    return {
      promise,
      abort() {
        if (!pendingReq.has(id)) return;
        pendingReq.delete(id);
        clearTimeout(entry.timer);
        tp.ai.abort(id);
        resolveFn({ status: 0, body: '', aborted: true });
      },
    };
  }

  tp.onAiChunk((o) => {
    const e = o && pendingReq.get(o.reqId);
    if (e && e.onChunk) e.onChunk(o.data || '');
  });

  tp.onAiDone((o) => {
    const e = o && pendingReq.get(o.reqId);
    if (!e) return;
    pendingReq.delete(o.reqId);
    clearTimeout(e.timer);
    e.resolve({ status: o.status || 0, body: o.body || '', error: o.error || '', retryAfter: o.retryAfter || '' });
  });

  async function evalInTab(id, script, timeout) {
    const t = await Promise.race([tp.ai.eval(id, script), new Promise((r) => setTimeout(() => r({ error: 'The page took too long to answer' }), timeout || 10000))]);
    return t || { error: 'No answer from the page' };
  }

  const saveTimers = {};

  function aiSettings() {
    const s = { ai: store.aicfg && typeof store.aicfg === 'object' ? store.aicfg : {} };
    Object.defineProperties(s, {
      name: { get: () => settings.name || '', enumerable: true },
      searchEngine: { get: () => settings.searchEngine || 'google', enumerable: true },
      focusSites: { get: () => settings.focusSites || [], enumerable: true },
      city: { get: () => settings.city || null, enumerable: true },
    });
    return s;
  }

  function appApi(s) {
    return {
      N: {
        copy: (text) => tp.copy(text),
        nav: (id, action) => tp.ai.nav(id, action),
        find: (id, text) => tp.ai.find(id, text),
        toast,
      },
      C,
      el,
      icon,
      toast,
      device: 'Mac',
      haptic: () => {},
      settings: s,
      load: (key, fallback) => (store[key] != null ? store[key] : fallback),
      saveSoon: (key, getter, ms) => {
        clearTimeout(saveTimers[key]);
        saveTimers[key] = setTimeout(() => tp.storeSave(key, getter()), ms || 600);
      },
      saveSettings: () => tp.storeSave('aicfg', s.ai),
      tabs: () => tabsNow(),
      tab: (id) => tabsNow().find((t) => t.id === String(id)) || null,
      activeTab: () => mapTab(activeRaw()),
      pageTab: () => {
        const t = mapTab(activeRaw());
        return t && !t.home && t.url ? t : null;
      },
      activeId: () => String(state.activeId),
      spaceById: (id) => state.spaces.find((x) => x.id === id) || null,
      ensureLive: (t) => tp.ai.wake(t.id),
      waitForLoad,
      evalInTab,
      request: aiRequest,
      loadAndRead: (url, script) => tp.ai.loadAndRead(url, script),
      async openTab(url, opts) {
        const st = await tp.ai.open(url, { background: !!(opts && opts.background) });
        return mapTab(st) || { id: '0', url: '', title: '', home: true, live: false, loading: false };
      },
      async navigate(url) {
        await tp.ai.navigate(url);
      },
      activate: (id) => tp.ai.activate(id),
      closeTab: (id) => tp.ai.close(id),
      openScreen: (id) => {
        if (id === 'ai') openAi();
      },
      closeScreen: () => closeAi(),
      openSettings: (section) => tp.openInternal('tp://settings/#' + (section === 'ai' ? 'ai' : section || '')),
      startFocus: (m) => tp.ai.focus(m),
      addFavorite: () => tp.ai.favorite(),
      speakText,
      stopSpeech,
      speech: () => speech,
      onSpeech: (fn) => speechListeners.push(fn),
      canVoice: () => isMac(),
      voice: () => startDictation(),
      consumeVoice,
      openReader,
    };
  }

  let aiOpen = false;

  function openAi() {
    if (aiOpen) {
      setTimeout(() => $('#ai-q').focus(), 30);
      return;
    }
    aiOpen = true;
    const col = $('#ai-col');
    col.hidden = false;
    col.classList.remove('out');
    document.body.classList.add('ai-open');
    if (!reducedMotion) {
      col.classList.remove('in');
      void col.offsetWidth;
      col.classList.add('in');
    }
    $$('.ai-toggle').forEach((b) => b.classList.add('on'));
    requestAnimationFrame(() => window.TPSidebar && window.TPSidebar.reportLayout());
    setTimeout(() => $('#ai-q').focus(), 80);
  }

  function closeAi() {
    if (!aiOpen) return;
    aiOpen = false;
    $('#ai-q').blur();
    $$('.ai-toggle').forEach((b) => b.classList.remove('on'));
    const col = $('#ai-col');
    const finish = () => {
      if (aiOpen) return;
      col.hidden = true;
      col.classList.remove('out');
      document.body.classList.remove('ai-open');
      requestAnimationFrame(() => window.TPSidebar && window.TPSidebar.reportLayout());
      tp.focusPage();
    };
    if (reducedMotion) finish();
    else {
      col.classList.remove('in');
      col.classList.add('out');
      setTimeout(finish, 220);
    }
  }

  function toggleAi() {
    if (aiOpen) closeAi();
    else if (ai) ai.open();
    else openAi();
  }

  $$('.ai-toggle').forEach((b) => b.addEventListener('click', toggleAi));

  async function startAi() {
    const [chat, cfg, ui] = await Promise.all([tp.storeLoad('aichat'), tp.storeLoad('aicfg'), tp.storeLoad('uiprefs')]);
    store.aichat = chat;
    store.aicfg = cfg && typeof cfg === 'object' ? cfg : {};
    store.uiprefs = ui;
    if (ui && typeof ui === 'object') prefs = Object.assign(prefs, ui);
    prefs.reader = Object.assign({ size: 19, font: 'serif', theme: 'auto' }, prefs.reader || {});
    const s = aiSettings();
    ai = window.createTPAI(appApi(s));
    ai.setup();
    window.fillIcons($('#ai'));
  }

  tp.onAiConfig((c) => {
    if (ai && store.aicfg && c && typeof c.control === 'boolean') store.aicfg.control = c.control;
  });
  tp.onAiClear(() => {
    if (ai) ai.newChat();
  });

  // ------------------------------------------------------------------------------------------
  // Reader view
  // ------------------------------------------------------------------------------------------

  const READER_SIZES = [15, 16, 17, 18, 19, 20, 22, 24, 26, 28];
  const READER_THEMES = { light: '#fbfaf7', sepia: '#f4ecd8', dark: '#17161c' };
  let reader = null;

  function savePrefs() {
    tp.storeSave('uiprefs', prefs);
  }

  function readerTheme() {
    const th = prefs.reader.theme;
    return th === 'auto' || !READER_THEMES[th] ? (dark() ? 'dark' : 'light') : th;
  }

  function applyReaderLook() {
    const r = $('#reader');
    ['light', 'sepia', 'dark'].forEach((th) => r.classList.toggle('rt-' + th, readerTheme() === th));
    r.classList.toggle('rf-sans', prefs.reader.font === 'sans');
    r.style.setProperty('--rs', prefs.reader.size + 'px');
  }

  function openReader(listen) {
    const raw = activeRaw();
    const t = mapTab(raw);
    if (!t || t.home || !/^https?:/.test(t.url)) {
      toast('Open an article first, then try reader view');
      return;
    }
    closeModal();
    reader = { tabId: t.id, data: null, items: [] };
    applyReaderLook();
    const r = $('#reader');
    const body = $('#reader-body');
    body.textContent = '';
    body.append(el('div', { class: 'r-skeleton' }, el('i', { class: 'w60' }), el('i', { class: 'w90 tall' }), el('i', { class: 'w40' }), el('i'), el('i'), el('i', { class: 'w80' }), el('i'), el('i', { class: 'w70' })));
    $('#reader-site').textContent = C.hostOf(t.url);
    r.classList.remove('hide-top');
    r.scrollTop = 0;
    const wasOpen = !r.hidden;
    r.hidden = false;
    document.body.classList.add('reading');
    coverOn('reader', false);
    if (!wasOpen && !reducedMotion) {
      r.classList.remove('in');
      void r.offsetWidth;
      r.classList.add('in');
    }
    renderReaderProgress();
    loadReader(t, listen);
  }

  async function loadReader(t, listen) {
    if (!t.live) {
      tp.ai.wake(t.id);
      await waitForLoad(t.id, 15000);
    } else if (t.loading) {
      await waitForLoad(t.id, 8000);
    }
    const res = await evalInTab(t.id, window.TPReader.script(), 9000);
    if (!reader || reader.tabId !== t.id) return;
    let d = null;
    try {
      d = JSON.parse(JSON.parse(res.result || '""') || 'null');
    } catch (e) {
      d = null;
    }
    if (!d || d.error || !Array.isArray(d.blocks) || !d.blocks.some((b) => b.x)) return renderReaderError();
    reader.data = d;
    renderReader(d);
    if (listen) startReaderListen(0);
  }

  function renderReaderError() {
    const body = $('#reader-body');
    body.textContent = '';
    body.append(el('div', { class: 'r-empty' },
      el('div', { class: 'r-empty-icon', html: I.reader }),
      el('h2', { text: 'No article here' }),
      el('p', { text: 'Reader view works best on news, blogs, wikis and stories. This page doesn’t have much text to show.' }),
      el('button', { class: 'btn', text: 'Back to the page', onclick: () => closeReader() })));
  }

  function renderReader(d) {
    const body = $('#reader-body');
    body.textContent = '';
    body.dir = d.dir === 'rtl' ? 'rtl' : 'ltr';
    const words = d.blocks.filter((b) => b.x).map((b) => b.x).join(' ');
    $('#reader-site').textContent = d.site || C.hostOf(d.url);
    const head = el('header', { class: 'r-head' },
      el('div', { class: 'r-kicker', text: d.site || C.hostOf(d.url) }),
      el('h1', { class: 'r-title', text: d.title || '' }),
      el('div', { class: 'r-meta', text: [d.byline, C.readingMinutes(words) + ' min read'].filter(Boolean).join(' · ') }));
    body.append(head);
    reader.items = [];
    if (d.title) reader.items.push({ text: d.title, lang: C.speechLang(d.title, d.lang), ref: head.querySelector('.r-title') });
    let list = null;
    let n = 0;
    d.blocks.forEach((b) => {
      let node = null;
      if (b.t === 'li') {
        const tag = b.o ? 'OL' : 'UL';
        if (!list || list.tagName !== tag) {
          list = el(tag.toLowerCase(), { class: 'r-list' });
          body.append(list);
        }
        node = el('li', { text: b.x });
        list.append(node);
      } else {
        list = null;
        if (b.t === 'h') node = el(b.l <= 2 ? 'h2' : 'h3', { class: 'r-h', text: b.x });
        else if (b.t === 'p') node = el('p', { text: b.x });
        else if (b.t === 'q') node = el('blockquote', { text: b.x });
        else if (b.t === 'pre') node = el('pre', { text: b.x });
        else if (b.t === 'cap') node = el('figcaption', { class: 'r-cap', text: b.x });
        else if (b.t === 'img') {
          const im = el('img', { src: b.src, alt: b.alt || '', loading: 'lazy', decoding: 'async', referrerpolicy: 'no-referrer' });
          node = el('figure', { class: 'r-fig' }, im);
          im.addEventListener('error', () => node.remove());
          im.addEventListener('load', () => node.classList.add('loaded'));
        }
        if (node) body.append(node);
      }
      if (!node) return;
      if (n < 12) node.style.setProperty('--d', String(n));
      n++;
      if (b.x && b.t !== 'cap' && b.t !== 'pre') {
        C.splitSpeech(b.x, 1200).forEach((piece) => reader.items.push({ text: piece, lang: C.speechLang(piece, d.lang), ref: node }));
      }
    });
    body.append(el('div', { class: 'r-end' }, el('div', { class: 'r-end-mark', text: '✦' }), el('button', { class: 'btn ghost', text: 'Back to the full page', onclick: () => closeReader() })));
    if (!reducedMotion) {
      body.classList.add('r-enter');
      setTimeout(() => body.classList.remove('r-enter'), 1100);
    }
    renderReaderProgress();
    updateReaderPlayer();
  }

  function startReaderListen(fromItem) {
    if (!reader || !reader.items.length) return;
    speak(reader.items, { owner: 'reader', start: fromItem || 0 });
  }

  function closeReader() {
    const r = $('#reader');
    if (r.hidden) return;
    if (speech.owner === 'reader') stopSpeech();
    reader = null;
    const finish = () => {
      if (reader) return;
      r.hidden = true;
      r.classList.remove('out', 'in');
      document.body.classList.remove('reading');
      coverOff('reader');
    };
    if (reducedMotion) finish();
    else {
      r.classList.remove('in');
      r.classList.add('out');
      setTimeout(finish, 200);
    }
  }

  function renderReaderProgress() {
    const r = $('#reader');
    const max = r.scrollHeight - r.clientHeight;
    $('#reader-progress').style.transform = 'scaleX(' + (max > 0 ? Math.min(1, r.scrollTop / max) : 0) + ')';
  }

  let readerUserScrollAt = 0;

  function updateReaderPlayer() {
    const mine = speech.owner === 'reader' && !!reader;
    const player = $('#reader-player');
    const show = mine && (speech.playing || speech.index >= 0);
    if (show && player.hidden) {
      player.hidden = false;
      if (!reducedMotion) {
        player.classList.remove('in');
        void player.offsetWidth;
        player.classList.add('in');
      }
    } else if (!show && !player.hidden) player.hidden = true;
    $('#reader').classList.toggle('listening', show);
    player.classList.toggle('playing', mine && speech.playing);
    $('#reader-listen').innerHTML = I[mine && speech.playing ? 'pause' : 'speaker'];
    $$('#reader-body .speaking').forEach((x) => x.classList.remove('speaking'));
    if (!show) return;
    $('#rp-play').innerHTML = I[speech.playing ? 'pause' : 'play'];
    $('#rp-rate').textContent = String(Number(settings.speechRate) || 1) + '×';
    $('#rp-progress').style.transform = 'scaleX(' + (speech.items.length ? (speech.index + 1) / speech.items.length : 0) + ')';
    $('#rp-title').textContent = speech.playing ? 'Listening' : 'Paused';
    const item = speech.items[speech.index];
    if (item && item.ref) {
      item.ref.classList.add('speaking');
      if (speech.playing && Date.now() - readerUserScrollAt > 4000) {
        const rect = item.ref.getBoundingClientRect();
        const box = $('#reader').getBoundingClientRect();
        if (rect.top < box.top + 70 || rect.bottom > box.bottom - 110) item.ref.scrollIntoView({ block: 'center', behavior: reducedMotion ? 'auto' : 'smooth' });
      }
    }
  }

  function readerJump(dir) {
    if (!speech.items.length) return;
    const cur = speech.items[Math.max(0, speech.index)];
    let i = Math.max(0, speech.index);
    if (dir > 0) {
      while (i < speech.items.length && speech.items[i].ref === cur.ref) i++;
      if (i >= speech.items.length) return;
    } else {
      while (i > 0 && speech.items[i - 1].ref === cur.ref) i--;
      if (i > 0) {
        const prevRef = speech.items[i - 1].ref;
        i--;
        while (i > 0 && speech.items[i - 1].ref === prevRef) i--;
      }
    }
    readerUserScrollAt = 0;
    speechFrom(i);
  }

  function openReaderStyle() {
    openModal('reader-style', (box) => {
      const draw = () => {
        box.textContent = '';
        box.append(sheetHead('Text and colours', null, I.textsize));
        const idx = Math.max(0, READER_SIZES.indexOf(prefs.reader.size));
        const change = (d) => {
          const next = READER_SIZES[Math.max(0, Math.min(READER_SIZES.length - 1, idx + d))];
          if (next === prefs.reader.size) return;
          prefs.reader.size = next;
          savePrefs();
          applyReaderLook();
          draw();
        };
        const dots = el('div', { class: 'rs-dots' });
        READER_SIZES.forEach((sz, i) => dots.append(el('i', { class: i <= idx ? 'on' : '' })));
        box.append(el('div', { class: 'rs-size' },
          el('button', { class: 'rs-btn', title: 'Smaller text', onclick: () => change(-1) }, el('span', { style: 'font-size:13px', text: 'A' })),
          dots,
          el('button', { class: 'rs-btn', title: 'Bigger text', onclick: () => change(1) }, el('span', { style: 'font-size:21px', text: 'A' }))));
        const fonts = el('div', { class: 'seg' });
        [['serif', 'Serif'], ['sans', 'Sans']].forEach(([f, label]) => fonts.append(el('button', { class: (prefs.reader.font === f ? 'on ' : '') + 'font-' + f, text: label, onclick: () => {
          prefs.reader.font = f;
          savePrefs();
          applyReaderLook();
          draw();
        } })));
        box.append(fonts);
        const themes = el('div', { class: 'rs-themes' });
        [['auto', 'Auto'], ['light', 'Light'], ['sepia', 'Sepia'], ['dark', 'Dark']].forEach(([th, label]) => themes.append(el('button', { class: 'rs-theme th-' + th + (prefs.reader.theme === th ? ' on' : ''), onclick: () => {
          prefs.reader.theme = th;
          savePrefs();
          applyReaderLook();
          draw();
        } }, el('span', { class: 'rs-swatch', text: 'Aa' }), el('span', { text: label }))));
        box.append(themes);
        box.append(el('div', { class: 'm-actions' }, el('button', { class: 'btn', text: 'Done', onclick: closeModal })));
      };
      draw();
    });
  }

  (function setupReader() {
    const r = $('#reader');
    window.fillIcons(r);
    $('#reader-close').onclick = () => closeReader();
    $('#reader-aa').onclick = () => openReaderStyle();
    $('#reader-listen').onclick = () => {
      if (speech.owner === 'reader' && speech.playing) pauseSpeech();
      else if (speech.owner === 'reader' && speech.items.length) resumeSpeech();
      else startReaderListen(0);
    };
    $('#rp-play').onclick = () => (speech.playing ? pauseSpeech() : resumeSpeech());
    $('#rp-prev').onclick = () => readerJump(-1);
    $('#rp-next').onclick = () => readerJump(1);
    $('#rp-close').onclick = () => stopSpeech();
    $('#rp-rate').onclick = () => {
      const rates = [1, 1.25, 1.5, 1.75, 2, 0.75];
      const i = rates.indexOf(Number(settings.speechRate) || 1);
      settings.speechRate = rates[(i + 1) % rates.length];
      tp.set('speechRate', settings.speechRate);
      if (speech.playing) speechFrom(speech.index);
      else updateReaderPlayer();
    };
    $('#reader-body').addEventListener('click', (e) => {
      if (speech.owner !== 'reader' || !reader) return;
      if (String(window.getSelection ? window.getSelection() : '').trim()) return;
      const i = reader.items.findIndex((it) => it.ref && (it.ref === e.target || it.ref.contains(e.target)));
      if (i >= 0 && i !== speech.index) {
        readerUserScrollAt = 0;
        speechFrom(i);
      }
    });
    let lastTop = 0;
    let ticking = false;
    r.addEventListener('scroll', () => {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        ticking = false;
        const top = r.scrollTop;
        if (top > lastTop + 8 && top > 90) r.classList.add('hide-top');
        else if (top < lastTop - 8 || top < 40) r.classList.remove('hide-top');
        lastTop = top;
        renderReaderProgress();
      });
    }, { passive: true });
    r.addEventListener('wheel', () => {
      readerUserScrollAt = Date.now();
    }, { passive: true });
    speechListeners.push(() => {
      if (!$('#reader').hidden) updateReaderPlayer();
    });
    matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyReaderLook);
  })();

  // ------------------------------------------------------------------------------------------
  // QR code and "what's new" sheets
  // ------------------------------------------------------------------------------------------

  function openQr() {
    const t = mapTab(activeRaw());
    if (!t || t.home || !/^https?:/.test(t.url)) {
      toast('Open a website first');
      return;
    }
    let svg = '';
    try {
      svg = window.TPQR.svg(t.url, { label: 'QR code for ' + C.hostOf(t.url) });
    } catch (e) {
      svg = '';
    }
    openModal('qr', (box) => {
      box.append(sheetHead('Scan to open this page', 'Point a phone’s camera at the code', I.qr));
      const card = el('div', { class: 'qr-card' });
      if (svg) card.innerHTML = svg;
      else card.append(el('p', { text: 'This link is too long for a QR code.' }));
      card.append(el('div', { class: 'qr-title', text: t.title || C.hostOf(t.url) }), el('div', { class: 'qr-url', text: t.url.replace(/^https?:\/\/(www\.)?/, '') }));
      box.append(el('div', { class: 'qr-wrap' }, card));
      box.append(el('div', { class: 'm-actions' },
        el('button', { class: 'btn ghost', text: 'Copy link', onclick: () => { tp.copy(t.url); closeModal(); toast('🔗 Link copied'); } }),
        isMac() ? el('button', { class: 'btn ghost', text: 'Share…', onclick: () => { closeModal(); setTimeout(() => tp.share(), 220); } }) : null,
        el('button', { class: 'btn', text: 'Done', onclick: closeModal })));
    });
  }

  tp.onWhatsNew((p) => {
    if (!p || !Array.isArray(p.notes) || !p.notes.length) return;
    openModal('whatsnew', (box) => {
      box.append(el('div', { class: 'm-head' },
        el('div', { class: 'm-icon done', html: I.check }),
        el('h3', { text: 'Update completed' }),
        el('p', { text: 'TP Browser ' + p.version + (p.from ? ' (was ' + p.from + ')' : '') + '. Your tabs, favorites and settings are just as you left them.' })));
      box.append(el('div', { class: 'whatsnew-title', text: 'What’s new' }));
      const ul = el('ul', { class: 'whatsnew' });
      p.notes.slice(0, 12).forEach((n, i) => {
        const li = el('li', { text: String(n) });
        li.style.setProperty('--i', String(i));
        ul.append(li);
      });
      box.append(ul);
      box.append(el('div', { class: 'm-actions' }, el('button', { class: 'btn', text: 'Nice!', onclick: closeModal })));
    });
  });

  // ------------------------------------------------------------------------------------------
  // Update chip at the bottom of the sidebar
  // ------------------------------------------------------------------------------------------

  tp.onUpdate((u) => {
    const chip = $('#update-chip');
    const ready = u && u.state === 'ready';
    const wasHidden = chip.hidden;
    chip.hidden = !ready;
    if (ready) {
      $('#uc-title').textContent = 'Update ready';
      $('#uc-sub').textContent = 'Version ' + (u.version || '') + ' · your tabs come back';
      if (wasHidden && !reducedMotion) {
        chip.classList.remove('pop');
        void chip.offsetWidth;
        chip.classList.add('pop');
      }
    }
  });
  $('#update-chip').addEventListener('click', () => tp.updateRestart());

  // ------------------------------------------------------------------------------------------
  // From the main process and the keyboard
  // ------------------------------------------------------------------------------------------

  tp.onInit((d) => {
    if (d && d.settings) settings = Object.assign({}, settings, d.settings);
  });
  tp.onSettings((s) => {
    if (s) settings = Object.assign({}, settings, s);
  });
  tp.onState((s) => {
    const prevActive = state.activeId;
    state = s;
    loadWaiters.slice().forEach(checkWaiter);
    // Another tab or space: the reader view and sheets belong to the old page.
    if (prevActive !== null && prevActive !== s.activeId) {
      if (reader) closeReader();
      if (modalKind === 'qr') closeModal();
    }
  });

  tp.onCommand((cmd) => {
    const name = cmd && cmd.name;
    if (name === 'ai-toggle') toggleAi();
    else if (name === 'ai-open') {
      if (ai) ai.open();
      else openAi();
    } else if (name === 'ai-ask' && ai) {
      ai.open(String(cmd.text || ''), { withPage: !!cmd.withPage });
    } else if (name === 'reader') openReader(!!cmd.listen);
    else if (name === 'qr') openQr();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if (modalKind) {
      e.preventDefault();
      closeModal();
    } else if (!$('#reader').hidden) {
      e.preventDefault();
      closeReader();
    } else if (aiOpen && document.activeElement && document.activeElement.closest && document.activeElement.closest('#ai-col')) {
      e.preventDefault();
      closeAi();
    }
  });

  // For the previews and tests.
  window.TPExtras = { openReader, closeReader, openQr, openAi, closeAi, speech: () => speech, openModal, closeModal };

  startAi();
})();
