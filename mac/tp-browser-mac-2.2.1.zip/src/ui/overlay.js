'use strict';
/* Command bar: search the web, open sites, jump to tabs, run commands. */

(function () {
  const bar = window.tpBar;
  const I = window.ICONS;
  const q = document.getElementById('q');
  const results = document.getElementById('results');
  let mode = 'current';
  let items = [];
  let sel = 0;
  let seq = 0;
  let remoteTimer = null;
  let initialText = '';

  const LABELS = {
    url: 'Go to',
    search: 'Search',
    suggest: 'Search',
    tab: 'Open tabs',
    bookmark: 'Bookmarks',
    history: 'History',
    command: 'Commands',
  };

  function colorFor(text) {
    let h = 0;
    for (const ch of String(text)) h = (h * 31 + ch.charCodeAt(0)) % 360;
    return `hsl(${h} 58% 52%)`;
  }

  function hostOf(url) {
    try {
      return new URL(url).hostname.replace(/^www\./, '');
    } catch {
      return '';
    }
  }

  function highlight(node, text, query) {
    node.textContent = '';
    const t = String(text || '');
    const qq = query.trim().toLowerCase();
    const i = qq ? t.toLowerCase().indexOf(qq) : -1;
    if (i === -1) {
      node.textContent = t;
      return;
    }
    node.append(document.createTextNode(t.slice(0, i)));
    const m = document.createElement('mark');
    m.textContent = t.slice(i, i + qq.length);
    node.append(m, document.createTextNode(t.slice(i + qq.length)));
  }

  function iconFor(item) {
    const box = document.createElement('span');
    box.className = 'ic';
    if (item.emoji) box.textContent = item.emoji;
    else if (item.kind === 'search' || item.kind === 'suggest') box.innerHTML = I.search;
    else if (item.icon) {
      const img = new Image();
      img.alt = '';
      img.src = item.icon;
      img.onerror = () => {
        box.innerHTML = I.globe;
      };
      box.append(img);
    } else if (item.url && /^https?:/.test(item.url)) {
      const host = hostOf(item.url);
      const l = document.createElement('span');
      l.className = 'letter';
      l.textContent = (host || '?').charAt(0).toUpperCase();
      l.style.background = colorFor(host);
      box.append(l);
    } else box.innerHTML = I.globe;
    return box;
  }

  function render() {
    results.replaceChildren();
    let lastGroup = null;
    const query = q.value;
    items.forEach((item, i) => {
      // Group headings only for the secondary sections.
      const group = i === 0 ? null : LABELS[item.kind];
      if (group && group !== lastGroup && ['tab', 'bookmark', 'history', 'command'].includes(item.kind) && i > 0) {
        const prevGroup = LABELS[items[i - 1].kind];
        if (prevGroup !== group) {
          const h = document.createElement('div');
          h.className = 'group';
          h.textContent = group;
          results.append(h);
        }
      }
      lastGroup = group;
      const row = document.createElement('div');
      row.className = 'item k-' + item.kind + (i === sel ? ' sel' : '');
      row.setAttribute('role', 'option');
      const txt = document.createElement('span');
      txt.className = 'txt';
      const title = document.createElement('span');
      title.className = 'title';
      highlight(title, item.title, query);
      txt.append(title);
      if (item.subtitle) {
        const sub = document.createElement('span');
        sub.className = 'sub';
        sub.textContent = item.subtitle;
        txt.append(sub);
      }
      const hint = document.createElement('span');
      hint.className = 'hint';
      hint.textContent = item.hint || (item.kind === 'suggest' ? 'Search' : item.kind === 'bookmark' || item.kind === 'history' ? 'Open' : '');
      row.append(iconFor(item), txt, hint);
      row.addEventListener('mousemove', () => {
        if (sel !== i) {
          sel = i;
          paintSelection();
        }
      });
      row.addEventListener('mousedown', (e) => {
        e.preventDefault();
        choose(i, { newTab: e.metaKey });
      });
      results.append(row);
    });
  }

  function paintSelection() {
    const rows = results.querySelectorAll('.item');
    rows.forEach((r, i) => r.classList.toggle('sel', i === sel));
    const r = rows[sel];
    if (r) r.scrollIntoView({ block: 'nearest' });
  }

  async function update() {
    const text = q.value;
    const my = ++seq;
    const local = await bar.suggest(text, mode);
    if (my !== seq) return;
    items = local || [];
    sel = 0;
    render();
    clearTimeout(remoteTimer);
    if (text.trim() && text !== initialText) {
      remoteTimer = setTimeout(async () => {
        const remote = await bar.remote(text);
        if (my !== seq || !remote || !remote.length) return;
        // Put live search suggestions right after the first result or two.
        const firstOther = items.findIndex((it, i) => i > 0 && it.kind !== 'url' && it.kind !== 'search' && it.kind !== 'history');
        const at = firstOther === -1 ? items.length : Math.max(1, Math.min(firstOther, 2));
        const seen = new Set(items.map((it) => it.url));
        const add = remote.filter((r) => !seen.has(r.url));
        const chosen = items[sel];
        items = [...items.slice(0, at), ...add, ...items.slice(at)];
        sel = Math.max(0, items.indexOf(chosen));
        render();
      }, 110);
    }
  }

  function choose(i, opts = {}) {
    const item = items[i];
    if (!item) return;
    const isWeb = ['url', 'search', 'suggest', 'bookmark', 'history'].includes(item.kind);
    const newTab = isWeb && (opts.newTab || mode === 'commands');
    bar.choose(item, { newTab });
  }

  q.addEventListener('input', update);
  q.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown' || (e.key === 'n' && e.ctrlKey) || (e.key === 'Tab' && !e.shiftKey)) {
      e.preventDefault();
      if (items.length) sel = (sel + 1) % items.length;
      paintSelection();
    } else if (e.key === 'ArrowUp' || (e.key === 'p' && e.ctrlKey) || (e.key === 'Tab' && e.shiftKey)) {
      e.preventDefault();
      if (items.length) sel = (sel - 1 + items.length) % items.length;
      paintSelection();
    } else if (e.key === 'Enter') {
      e.preventDefault();
      choose(sel, { newTab: e.metaKey || e.altKey });
    } else if (e.key === 'Escape') {
      e.preventDefault();
      if (q.value && q.value !== initialText && mode === 'commands') {
        q.value = '';
        update();
      } else bar.close();
    }
  });

  document.getElementById('backdrop').addEventListener('mousedown', () => bar.close());
  window.addEventListener('blur', () => {
    // Clicking outside the app closes the bar too.
    setTimeout(() => {
      if (!document.hasFocus()) bar.close();
    }, 120);
  });

  bar.onOpen((p) => {
    mode = p.mode || 'current';
    initialText = p.text || '';
    const [c1, c2] = (p.space && p.space.colors) || ['#7c5cff', '#4f8bff'];
    document.documentElement.style.setProperty('--c1', c1);
    document.documentElement.style.setProperty('--c2', c2);
    document.getElementById('mode-icon').innerHTML = mode === 'commands' ? I.command : I.search;
    q.placeholder = mode === 'commands' ? 'Search tabs, history, or type a command…' : `Search ${p.engine || 'the web'} or type a URL`;
    document.getElementById('space-label').textContent = p.space ? `${p.space.icon} ${p.space.name}` : '';
    document.getElementById('hint-keys').style.display = mode === 'commands' ? 'none' : '';
    q.value = initialText;
    // Restart the entrance animation each time the bar opens.
    const card = document.getElementById('bar');
    card.style.animation = 'none';
    void card.offsetWidth;
    card.style.animation = '';
    q.focus();
    q.select();
    update();
  });
})();
