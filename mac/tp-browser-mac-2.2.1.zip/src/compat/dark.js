/* TP Browser: dark mode for websites that don't have their own. Pages that are already dark are
 * left alone; pictures and videos keep their real colours. */
(function (except) {
  try {
    if (window.top !== window || location.protocol === 'file:') return;
  } catch (e) {
    return;
  }
  var ID = 'tp-dark-css';
  var host = (location.hostname || '').toLowerCase().replace(/^www\./, '');
  for (var i = 0; i < except.length; i++) {
    var d = except[i];
    if (host === d || host.slice(-d.length - 1) === '.' + d) {
      var old = document.getElementById(ID);
      if (old) old.remove();
      return;
    }
  }
  var MEDIA = 'img,video,canvas,svg image,embed,object,[style*="background-image"],[style*="background: url"],[style*="background:url"],' +
    'iframe[src*="youtube"],iframe[src*="vimeo"],iframe[src*="player"],iframe[src*="video"],iframe[src*="maps"]';
  var CSS = 'html{filter:invert(.93) hue-rotate(180deg)!important;background:#fff!important}' +
    MEDIA + '{filter:invert(1) hue-rotate(180deg)!important}' +
    '[style*="background-image"] img,[style*="background-image"] video{filter:none!important}';

  function add() {
    var root = document.documentElement;
    if (!root) {
      // Very early (before the page has an <html> element): add the style as soon as it appears.
      var mo = new MutationObserver(function () {
        if (document.documentElement) {
          mo.disconnect();
          add();
        }
      });
      mo.observe(document, { childList: true });
      return;
    }
    if (document.getElementById(ID) || window.__tpDarkSkip) return;
    var s = document.createElement('style');
    s.id = ID;
    s.textContent = CSS;
    (document.head || root).appendChild(s);
  }

  function rgba(c) {
    var m = /rgba?\(([^)]+)\)/.exec(c || '');
    if (!m) return null;
    var p = m[1].split(/[\s,\/]+/).filter(Boolean).map(parseFloat);
    return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 };
  }

  function lum(c) {
    return (0.2126 * c.r + 0.7152 * c.g + 0.0722 * c.b) / 255;
  }

  // Looks at the page's own colours (with TP's filter switched off for a moment, nothing is drawn).
  function alreadyDark() {
    var s = document.getElementById(ID);
    if (s && s.sheet) s.sheet.disabled = true;
    var dark = false;
    try {
      var root = document.documentElement;
      var body = document.body;
      var bg = null;
      var els = body ? [body, root] : [root];
      for (var i = 0; i < els.length && !bg; i++) {
        var c = rgba(getComputedStyle(els[i]).backgroundColor);
        if (c && c.a > 0.5) bg = c;
      }
      if (bg) {
        dark = lum(bg) < 0.4;
      } else {
        var text = rgba(getComputedStyle(body || root).color);
        var scheme = getComputedStyle(root).colorScheme || '';
        dark = (text && lum(text) > 0.6) || (/dark/.test(scheme) && !/light/.test(scheme));
      }
    } catch (e) {
      dark = false;
    }
    if (s && s.sheet) s.sheet.disabled = false;
    return dark;
  }

  function check() {
    if (!document.body) return;
    if (alreadyDark()) {
      window.__tpDarkSkip = true;
      var s = document.getElementById(ID);
      if (s) s.remove();
    } else {
      window.__tpDarkSkip = false;
      add();
    }
  }

  add();
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', check, { once: true });
  else check();
  window.addEventListener('load', check, { once: true });
})(__TP_EXCEPT__);
