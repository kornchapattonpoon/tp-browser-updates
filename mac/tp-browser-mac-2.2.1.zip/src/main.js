'use strict';
/*
 * TP Browser - main process.
 *
 * Each window is a sidebar UI page (spaces, favorites, tabs) with one Chromium
 * WebContentsView per visible tab laid over it, plus an overlay view for the
 * command bar. Tabs belong to Spaces; background tabs fall asleep to save memory.
 */

const {
  app,
  BrowserWindow,
  WebContentsView,
  Menu,
  ipcMain,
  session,
  protocol,
  shell,
  dialog,
  clipboard,
  nativeTheme,
  screen,
  net,
  Notification,
} = require('electron');
const path = require('path');
const fs = require('fs');
const { pathToFileURL } = require('url');
const util = require('./util');
const shield = require('./shield');
const importer = require('./importer');
const weather = require('./weather');
const updater = require('./updater');
// Shared with TP Browser for Android: calculator, focus streak, translate links, read-aloud helpers.
const core = require('./ui/core.js');

// The TP Browser code that is running (it can be newer than the app itself: see boot.js).
const APP_VERSION = (() => {
  try {
    return require('../package.json').version;
  } catch {
    return app.getVersion();
  }
})();
const UPDATE_FEED = 'https://raw.githubusercontent.com/kornchapattonpoon/tp-browser-updates/main/mac/latest.json';
const DARK_JS = (() => {
  try {
    return fs.readFileSync(path.join(__dirname, 'compat', 'dark.js'), 'utf8');
  } catch {
    return '';
  }
})();
const DARK_OFF_JS = "(function(){var s=document.getElementById('tp-dark-css');if(s)s.remove();window.__tpDarkSkip=false})()";
// Isolated worlds: TP's scripts can read and style pages without pages seeing or changing them.
const WORLD_DARK = 1002;
const WORLD_AI = 1003;
// Where TP AI may send requests (the free AI services it runs on).
const AI_HOSTS = new Set(['api.groq.com', 'generativelanguage.googleapis.com', 'openrouter.ai', 'text.pollinations.ai']);

const { NEW_TAB_URL, SEARCH_ENGINES } = util;
const PAGES_DIR = path.join(__dirname, 'pages');
const UI_DIR = path.join(__dirname, 'ui');
const PRELOAD_UI = path.join(__dirname, 'preload-ui.js');
const PRELOAD_OVERLAY = path.join(__dirname, 'preload-overlay.js');
const PRELOAD_TAB = path.join(__dirname, 'preload-tab.js');
const IS_MAC = process.platform === 'darwin';
const PAGE_RADIUS = 10;
const SPLIT_GAP = 8;
// Set by the build script to check that a freshly built app starts properly.
const SMOKE_TEST = process.env.TP_SMOKE_TEST || '';
const smoke = { internalCalls: 0 };

if (process.env.TP_USER_DATA) app.setPath('userData', path.resolve(process.env.TP_USER_DATA));
app.setName('TP Browser');

// tp:// serves the browser's own pages (home, settings, history, focus, errors).
protocol.registerSchemesAsPrivileged([
  { scheme: 'tp', privileges: { standard: true, secure: true, supportFetchAPI: true } },
]);

// Look exactly like desktop Chrome everywhere (Chrome only reports its major version).
const CHROME_MAJOR = String(process.versions.chrome || '140').split('.')[0];
const CHROME_UA = `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${CHROME_MAJOR}.0.0.0 Safari/537.36`;
app.userAgentFallback = CHROME_UA;

// One consistent Chrome identity for every site (Google's sign-in rejects mixed signals).
function userAgentFor() {
  return CHROME_UA;
}
function applyUserAgent(wc) {
  if (wc && !wc.isDestroyed() && wc.getUserAgent() !== CHROME_UA) wc.setUserAgent(CHROME_UA);
}

// ---------------------------------------------------------------------------
// Defaults
// ---------------------------------------------------------------------------

const SPACE_COLORS = {
  violet: ['#7c5cff', '#4f8bff'],
  blue: ['#2f7bf6', '#06b6d4'],
  teal: ['#0ea5a4', '#22c55e'],
  green: ['#22c55e', '#a3e635'],
  orange: ['#f97316', '#facc15'],
  pink: ['#ec4899', '#a855f7'],
  red: ['#ef4444', '#f97316'],
  slate: ['#64748b', '#a1a1aa'],
};
const SPACE_ICONS = ['🏠', '📚', '🎮', '💼', '🎨', '🎵', '🌏', '🧪', '⚽', '🍜', '🚀', '💡', '🛒', '✈️', '🐱', '🌱', '🎬', '💻'];
const DEFAULT_SPACES = [
  { id: 'personal', name: 'Personal', icon: '🏠', color: 'violet' },
  { id: 'school', name: 'School', icon: '📚', color: 'blue' },
  { id: 'games', name: 'Games', icon: '🎮', color: 'green' },
];
const WALLPAPERS = ['space', 'aurora', 'sunset', 'ocean', 'forest', 'midnight', 'custom'];
const DEFAULT_FOCUS_SITES = [
  'youtube.com', 'tiktok.com', 'instagram.com', 'facebook.com', 'x.com', 'twitter.com',
  'reddit.com', 'netflix.com', 'twitch.tv', 'roblox.com',
];
const DEFAULT_SETTINGS = {
  name: '',
  onboarded: false,
  searchEngine: 'google',
  suggestions: true,
  appearance: 'system',
  restoreTabs: true,
  sidebarCollapsed: false,
  sidebarWidth: 264,
  shield: true,
  ytSkip: true,
  shieldAllow: [],
  sleepAfter: 30,
  focusMinutes: 25,
  focusSites: DEFAULT_FOCUS_SITES,
  focusStartedAt: 0,
  focusEndsAt: 0,
  city: { name: 'Bangkok', region: 'Bangkok', country: 'Thailand', lat: 13.7563, lon: 100.5018 },
  tempUnit: 'C',
  wallpaper: 'space',
  wallpaperFile: '',
  wallpaperVersion: 0,
  note: '',
  spaces: DEFAULT_SPACES,
  darkPages: false,
  darkExcept: [],
  autoUpdate: true,
  lastUpdateCheck: 0,
  lastRunVersion: '',
  speechRate: 1,
  translateTo: '',
};

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------

let settings;
let bookmarks;
let historyStore;
let sessionStore;
let stats;
let favicons;
let startupDone = false;
let quitting = false;
let lastFocused = null;
let nextTabId = 1;
let nextDownloadId = 1;
let nextToastId = 1;
let historyVersion = 0;
let historyPoolCache = null;
let historyPoolVersion = -1;
let focusTimer = null;
let menuTimer = null;
let sessionTimer = null;

const windows = new Map(); // BrowserWindow id -> TPWindow
const tabsByWcId = new Map(); // webContents id -> Tab
const pendingOpen = []; // URLs macOS asked us to open before we were ready
const permissionDecisions = new Map(); // "origin|permission" -> boolean
const downloads = new Map(); // id -> download record
const toastActions = new Map(); // id -> function

const navOf = (wc) => wc.navigationHistory || wc;
const setRadius = (view, r) => {
  if (view && typeof view.setBorderRadius === 'function') view.setBorderRadius(r);
};

function currentWindow() {
  const fw = BrowserWindow.getFocusedWindow();
  if (fw && windows.has(fw.id)) return windows.get(fw.id);
  if (lastFocused && !lastFocused.win.isDestroyed()) return lastFocused;
  for (const w of windows.values()) return w;
  return null;
}

/** A focused window that is not a TP window (e.g. a sign-in popup). */
function focusedPopup() {
  const fw = BrowserWindow.getFocusedWindow();
  return fw && !windows.has(fw.id) ? fw : null;
}

function findTab(id) {
  for (const w of windows.values()) {
    const t = w.tabs.find((x) => x.id === id);
    if (t) return t;
  }
  return null;
}

function engineKey() {
  return SEARCH_ENGINES[settings.data.searchEngine] ? settings.data.searchEngine : 'google';
}

function spaces() {
  const list = Array.isArray(settings.data.spaces) && settings.data.spaces.length ? settings.data.spaces : DEFAULT_SPACES;
  return list;
}

function spaceById(id) {
  return spaces().find((s) => s.id === id) || null;
}

function publicSpaces() {
  return spaces().map((s) => ({ ...s, colors: SPACE_COLORS[s.color] || SPACE_COLORS.violet }));
}

function publicSettings() {
  const s = settings.data;
  return {
    name: s.name,
    onboarded: !!s.onboarded,
    searchEngine: engineKey(),
    searchEngineName: SEARCH_ENGINES[engineKey()].name,
    searchEngines: Object.entries(SEARCH_ENGINES).map(([key, e]) => ({ key, name: e.name })),
    suggestions: !!s.suggestions,
    appearance: s.appearance,
    restoreTabs: !!s.restoreTabs,
    sidebarWidth: s.sidebarWidth,
    shield: !!s.shield,
    ytSkip: !!s.ytSkip,
    shieldAllow: s.shieldAllow,
    sleepAfter: s.sleepAfter,
    focusMinutes: s.focusMinutes,
    focusSites: s.focusSites,
    city: s.city,
    tempUnit: s.tempUnit,
    wallpaper: s.wallpaper,
    wallpaperVersion: s.wallpaperVersion,
    hasCustomWallpaper: !!s.wallpaperFile,
    spaces: publicSpaces(),
    spaceColors: SPACE_COLORS,
    spaceIcons: SPACE_ICONS,
    darkPages: !!s.darkPages,
    darkExcept: Array.isArray(s.darkExcept) ? s.darkExcept : [],
    autoUpdate: s.autoUpdate !== false,
    speechRate: Number(s.speechRate) || 1,
    translateTo: s.translateTo || '',
    version: APP_VERSION,
  };
}

function broadcast(channel, payload) {
  for (const w of windows.values()) w.sendUi(channel, payload);
}

function prettyUrl(url) {
  if (!url) return '';
  try {
    const u = new URL(url);
    if (u.protocol === 'https:' || u.protocol === 'http:') {
      let s = u.host.replace(/^www\./, '') + (u.pathname === '/' ? '' : u.pathname) + u.search;
      try {
        s = decodeURI(s);
      } catch {
        /* keep encoded */
      }
      return s;
    }
  } catch {
    /* not a URL */
  }
  return url;
}

function paramUrl(raw) {
  try {
    const u = new URL(raw).searchParams.get('url') || '';
    return /^(https?|file):/i.test(u) ? u : '';
  } catch {
    return '';
  }
}

// ---------------------------------------------------------------------------
// Favicons we have seen, so home tiles and suggestions get real icons.
// ---------------------------------------------------------------------------

function faviconFor(url) {
  const host = util.hostnameOf(url).replace(/^www\./, '');
  return (host && favicons.data[host]) || null;
}

function rememberFavicon(pageUrl, iconUrl) {
  if (!util.isHttpUrl(pageUrl) || !iconUrl || !/^(https?|data):/i.test(iconUrl) || iconUrl.length > 4000) return;
  const host = util.hostnameOf(pageUrl).replace(/^www\./, '');
  if (!host || favicons.data[host] === iconUrl) return;
  favicons.data[host] = iconUrl;
  const keys = Object.keys(favicons.data);
  if (keys.length > 800) delete favicons.data[keys[0]];
  favicons.saveSoon(3000);
  let changed = false;
  for (const b of bookmarks.data) {
    if (!b.favicon && util.hostnameOf(b.url).replace(/^www\./, '') === host) {
      b.favicon = iconUrl;
      changed = true;
    }
  }
  if (changed) bookmarksChanged({ rebuildMenu: false });
}

// ---------------------------------------------------------------------------
// Stats (shown on the home page)
// ---------------------------------------------------------------------------

let blockedSinceSave = 0;
function countBlocked() {
  const k = util.dayKey();
  stats.data.blocked[k] = (stats.data.blocked[k] || 0) + 1;
  blockedSinceSave += 1;
  if (blockedSinceSave > 25) {
    blockedSinceSave = 0;
    stats.saveSoon(4000);
  } else stats.saveSoon(10000);
}

function addFocusMinutes(minutes, completed) {
  if (minutes <= 0) return;
  const k = util.dayKey();
  stats.data.focus[k] = (stats.data.focus[k] || 0) + minutes;
  if (completed) stats.data.sessions = (stats.data.sessions || 0) + 1;
  util.pruneDays(stats.data.focus, 120);
  util.pruneDays(stats.data.blocked, 120);
  stats.save();
}

function statsSummary() {
  return {
    blockedToday: Number(stats.data.blocked[util.dayKey()] || 0),
    blockedWeek: util.sumLastDays(stats.data.blocked, 7),
    focusToday: Number(stats.data.focus[util.dayKey()] || 0),
    focusWeek: util.sumLastDays(stats.data.focus, 7),
    focusStreak: core.focusStreak(stats.data.focus),
    sessions: stats.data.sessions || 0,
  };
}

// ---------------------------------------------------------------------------
// Focus sessions
// ---------------------------------------------------------------------------

function focusState() {
  const s = settings.data;
  if (s.focusEndsAt && s.focusEndsAt > Date.now()) {
    return { startedAt: s.focusStartedAt, endsAt: s.focusEndsAt };
  }
  return null;
}

function isFocusBlocked(url) {
  if (!focusState() || !util.isHttpUrl(url)) return false;
  return util.hostInList(util.hostnameOf(url), settings.data.focusSites);
}

function focusPageUrl(url) {
  return 'tp://focus/?url=' + encodeURIComponent(url);
}

function broadcastFocus() {
  for (const w of windows.values()) w.pushState();
  buildAppMenuSoon();
}

function scheduleFocusEnd() {
  clearTimeout(focusTimer);
  const st = focusState();
  if (!st) return;
  focusTimer = setTimeout(() => endFocus({ completed: true }), Math.min(st.endsAt - Date.now() + 100, 2 ** 31 - 1));
}

function startFocus(minutes) {
  const m = Math.max(5, Math.min(180, Math.round(Number(minutes) || settings.data.focusMinutes || 25)));
  const now = Date.now();
  settings.data.focusStartedAt = now;
  settings.data.focusEndsAt = now + m * 60000;
  settings.save();
  scheduleFocusEnd();
  // Pause tabs that are already on distracting sites.
  for (const w of windows.values()) {
    for (const t of w.tabs) {
      if (t.alive && isFocusBlocked(t.wc.getURL())) t.load(focusPageUrl(t.wc.getURL()));
      else if (!t.alive && isFocusBlocked(t.url)) t.url = focusPageUrl(t.url);
    }
  }
  broadcastFocus();
  const w = currentWindow();
  if (w) w.toast(`🎯 Focus mode on for ${m} minutes. Distracting sites are paused.`);
}

function endFocus({ completed, notify = completed }) {
  const s = settings.data;
  if (!s.focusStartedAt) return;
  const end = Math.min(Date.now(), s.focusEndsAt || Date.now());
  const minutes = Math.round((end - s.focusStartedAt) / 60000);
  s.focusStartedAt = 0;
  s.focusEndsAt = 0;
  settings.save();
  clearTimeout(focusTimer);
  addFocusMinutes(minutes, completed);
  broadcastFocus();
  if (notify) {
    const body = `Nice work${s.name ? ', ' + s.name : ''}! You stayed focused for ${minutes} minutes.`;
    if (Notification.isSupported()) new Notification({ title: 'Focus session complete 🎉', body }).show();
    for (const w of windows.values()) w.toast(`🎉 ${body}`);
  }
}

function extendFocus(minutes) {
  if (!focusState()) return;
  settings.data.focusEndsAt += minutes * 60000;
  settings.save();
  scheduleFocusEnd();
  broadcastFocus();
}

// ---------------------------------------------------------------------------
// Tab
// ---------------------------------------------------------------------------

class Tab {
  constructor(owner, opts = {}) {
    this.owner = owner;
    this.id = nextTabId++;
    this.spaceId = opts.spaceId || owner.activeSpaceId;
    this.title = opts.title || '';
    this.favicon = opts.favicon || null;
    this.url = opts.url || NEW_TAB_URL;
    this.pendingUrl = null;
    this.loading = false;
    this.audible = false;
    this.mutedPref = false;
    this.blocked = 0;
    this.openerId = opts.openerId || null;
    this.lastActive = Date.now();
    this.lastHistoryEntry = null;
    this.view = null;
    this.wcId = null;
    if (!opts.sleeping) this.load(this.url);
  }

  get wc() {
    return this.view ? this.view.webContents : null;
  }

  get alive() {
    const wc = this.wc;
    return !!wc && !wc.isDestroyed();
  }

  createView() {
    this.view = new WebContentsView({
      webPreferences: {
        preload: PRELOAD_TAB,
        contextIsolation: true,
        sandbox: true,
        nodeIntegration: false,
        plugins: true, // built-in PDF viewer
        spellcheck: true,
        scrollBounce: true,
        safeDialogs: true,
      },
    });
    this.view.setBackgroundColor(nativeTheme.shouldUseDarkColors ? '#1b1b20' : '#ffffff');
    setRadius(this.view, PAGE_RADIUS);
    const wc = this.view.webContents;
    this.wcId = wc.id;
    tabsByWcId.set(wc.id, this);
    try {
      Promise.resolve(wc.setVisualZoomLevelLimits(1, 3)).catch(() => {});
    } catch {
      // Pinch-zoom limits are optional.
    }
    if (this.mutedPref) wc.setAudioMuted(true);
    this.attachEvents(wc);
  }

  load(url) {
    if (!url) return;
    if (isFocusBlocked(url)) url = focusPageUrl(url);
    const wasAsleep = !this.alive;
    if (wasAsleep) this.createView();
    this.pendingUrl = url;
    this.wc.loadURL(url, { userAgent: userAgentFor() }).catch(() => {});
    if (wasAsleep) this.owner.syncViews();
    this.owner.pushState();
  }

  wake() {
    if (!this.alive) this.load(this.url || NEW_TAB_URL);
  }

  sleep() {
    if (!this.alive) return;
    this.url = this.restorableUrl();
    this.mutedPref = this.wc.isAudioMuted();
    this.owner.detachView(this);
    this.destroyContents();
    this.loading = false;
    this.audible = false;
    this.pendingUrl = null;
    this.owner.pushState();
  }

  destroyContents() {
    const wc = this.wc;
    if (this.wcId !== null) tabsByWcId.delete(this.wcId);
    this.view = null;
    this.wcId = null;
    if (wc && !wc.isDestroyed()) {
      if (typeof wc.close === 'function') wc.close();
      else if (typeof wc.destroy === 'function') wc.destroy();
    }
  }

  rawUrl() {
    if (!this.alive) return this.url || '';
    return this.wc.getURL() || this.pendingUrl || this.url || '';
  }

  /** A URL that brings this page back after sleeping or restarting. */
  restorableUrl() {
    const raw = this.rawUrl();
    if (/^tp:\/\/(error|focus)/.test(raw)) return paramUrl(raw) || NEW_TAB_URL;
    return raw || NEW_TAB_URL;
  }

  /** The URL the user should see (no internal tp:// addresses for home/error/focus). */
  displayUrl() {
    const raw = this.alive && this.loading && this.pendingUrl ? this.pendingUrl : this.rawUrl();
    if (!raw || raw.startsWith('tp://newtab')) return '';
    if (/^tp:\/\/(error|focus)/.test(raw)) return paramUrl(raw);
    return raw;
  }

  isHome() {
    return (this.pendingUrl || this.rawUrl() || NEW_TAB_URL).startsWith('tp://newtab');
  }

  displayTitle() {
    if (this.title) return this.title;
    const u = this.displayUrl();
    if (!u) return 'New Tab';
    return util.hostnameOf(u).replace(/^www\./, '') || u;
  }

  state() {
    const alive = this.alive;
    const url = this.displayUrl();
    const raw = this.rawUrl();
    return {
      id: this.id,
      spaceId: this.spaceId,
      title: this.displayTitle(),
      favicon: this.favicon,
      loading: alive && this.loading,
      sleeping: !alive,
      url,
      internal: !url || url.startsWith('tp:'),
      paused: raw.startsWith('tp://focus'),
      secure: url.startsWith('https://'),
      canGoBack: alive && navOf(this.wc).canGoBack(),
      canGoForward: alive && navOf(this.wc).canGoForward(),
      audible: this.audible,
      muted: alive ? this.wc.isAudioMuted() : this.mutedPref,
      bookmarked: isBookmarked(url),
      zoom: alive ? Math.round(Math.pow(1.2, this.wc.getZoomLevel()) * 100) : 100,
      blocked: this.blocked,
    };
  }

  attachEvents(wc) {
    // Ignore events from a webContents this tab no longer owns (after sleeping).
    const on = (event, fn) =>
      wc.on(event, (...args) => {
        if (this.wc !== wc || wc.isDestroyed()) return;
        fn(...args);
      });
    const push = () => this.owner.pushState();

    on('did-start-loading', () => {
      this.loading = true;
      push();
    });
    on('did-stop-loading', () => {
      this.loading = false;
      this.pendingUrl = null;
      push();
      saveSessionSoon();
    });
    on('did-navigate', (_e, url) => {
      this.url = url;
      this.pendingUrl = null;
      this.favicon = null;
      this.blocked = 0;
      this.recordHistory(url);
      if (isFocusBlocked(url)) setImmediate(() => this.load(focusPageUrl(url)));
      push();
    });
    on('did-navigate-in-page', (_e, url, isMainFrame) => {
      if (isMainFrame === false) return;
      this.url = url;
      this.recordHistory(url);
      push();
    });
    on('page-title-updated', (_e, title) => {
      this.title = title;
      if (this.lastHistoryEntry && this.lastHistoryEntry.url === wc.getURL()) {
        this.lastHistoryEntry.title = title;
        historyVersion += 1;
        historyStore.saveSoon();
      }
      push();
    });
    on('page-favicon-updated', (_e, list) => {
      this.favicon = list && list.length ? list[0] : null;
      if (this.favicon) rememberFavicon(wc.getURL(), this.favicon);
      push();
    });
    on('did-fail-load', (_e, code, description, validatedURL, isMainFrame) => {
      // -3 is ERR_ABORTED (stop button, a new navigation started, downloads).
      if (!isMainFrame || code === -3 || String(validatedURL).startsWith('tp://')) return;
      const params = new URLSearchParams({ code: String(code), desc: description, url: validatedURL });
      this.load('tp://error/?' + params.toString());
    });
    on('render-process-gone', (_e, details) => {
      if (details.reason === 'clean-exit' || this.owner.win.isDestroyed()) return;
      const params = new URLSearchParams({ code: 'crashed', desc: details.reason, url: this.displayUrl() });
      setTimeout(() => this.load('tp://error/?' + params.toString()), 50);
    });
    on('audio-state-changed', (e) => {
      this.audible = !!(e && e.audible);
      push();
    });
    const refreshAudio = () => {
      this.audible = wc.isCurrentlyAudible();
      push();
    };
    on('media-started-playing', refreshAudio);
    on('media-paused', refreshAudio);

    on('found-in-page', (_e, result) => {
      if (this.owner.activeTab === this) {
        this.owner.sendUi('find:result', { active: result.activeMatchOrdinal, total: result.matches });
      }
    });

    on('enter-html-full-screen', () => {
      const w = this.owner;
      w.htmlFullscreen = this;
      if (!w.win.isFullScreen()) {
        w.fullscreenForVideo = true;
        w.win.setFullScreen(true);
      }
      w.syncViews();
    });
    on('leave-html-full-screen', () => {
      const w = this.owner;
      w.htmlFullscreen = null;
      if (w.fullscreenForVideo && !w.win.isDestroyed()) {
        w.fullscreenForVideo = false;
        w.win.setFullScreen(false);
      }
      w.syncViews();
    });

    on('dom-ready', () => applyShieldToPage(this));
    on('focus', () => this.owner.onTabFocused(this));

    on('will-navigate', (e, urlArg) => {
      const url = (e && e.url) || urlArg || '';
      // Web pages may not navigate into the browser's own tp:// pages.
      if (/^tp:/i.test(url) && !/^tp:/i.test(wc.getURL())) {
        e.preventDefault();
        return;
      }
      if (isFocusBlocked(url)) {
        e.preventDefault();
        this.load(focusPageUrl(url));
      }
    });
    on('will-redirect', (e, urlArg, _inPlace, isMainFrameArg) => {
      const url = (e && e.url) || urlArg || '';
      const isMain = e && typeof e.isMainFrame === 'boolean' ? e.isMainFrame : isMainFrameArg !== false;
      if (isMain && isFocusBlocked(url)) {
        e.preventDefault();
        this.load(focusPageUrl(url));
      }
    });

    wc.setWindowOpenHandler(({ url, disposition, features }) => {
      if (/^tp:/i.test(url) && !/^tp:/i.test(wc.getURL())) return { action: 'deny' };
      if (disposition === 'new-window' && features) {
        // Real popups (e.g. "Sign in with ..." windows) stay popups so window.opener works.
        return {
          action: 'allow',
          overrideBrowserWindowOptions: {
            width: 520,
            height: 680,
            backgroundColor: '#ffffff',
            webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false },
          },
        };
      }
      if (disposition === 'new-window') new TPWindow({ urls: [url], spaceId: this.spaceId });
      else this.owner.addTab(url, { activate: disposition !== 'background-tab', after: this });
      return { action: 'deny' };
    });

    wc.on('did-create-window', (child, details) => {
      applyUserAgent(child.webContents);
      child.webContents.on('context-menu', (_e, params) => showPageMenu(child.webContents, params, this.owner, null));
      child.webContents.setWindowOpenHandler(({ url }) => {
        this.owner.addTab(url, { after: this });
        return { action: 'deny' };
      });
    });

    on('context-menu', (_e, params) => showPageMenu(wc, params, this.owner, this));
  }

  recordHistory(url) {
    if (!util.isHttpUrl(url)) return;
    const noHash = url.split('#')[0];
    if (this.lastHistoryEntry && this.lastHistoryEntry.url.split('#')[0] === noHash) return;
    const entry = {
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
      url,
      title: '',
      time: Date.now(),
    };
    historyStore.data.unshift(entry);
    if (historyStore.data.length > 8000) historyStore.data.length = 8000;
    this.lastHistoryEntry = entry;
    historyVersion += 1;
    historyStore.saveSoon();
  }

  destroy() {
    this.destroyContents();
  }
}

// ---------------------------------------------------------------------------
// Window
// ---------------------------------------------------------------------------

class TPWindow {
  constructor({ urls = [], spaceId = null, restore = null } = {}) {
    this.tabs = [];
    this.activeBySpace = new Map();
    this.mru = [];
    this.closedTabs = [];
    this.attached = new Set();
    this.pageRect = null;
    this.overlay = null;
    this.overlayOpen = false;
    this.overlayReady = null;
    this.split = null;
    this.htmlFullscreen = null;
    this.fullscreenForVideo = false;
    // The sidebar page covers the page area (reader view, sheets): tab views are taken off.
    this.covered = false;
    this._pushQueued = false;
    this._lazyTimer = null;

    const first = spaces()[0].id;
    this.activeSpaceId = spaceById(spaceId || (restore && restore.activeSpaceId)) ? spaceId || restore.activeSpaceId : first;
    this.sidebarCollapsed = restore && typeof restore.sidebarCollapsed === 'boolean' ? restore.sidebarCollapsed : !!settings.data.sidebarCollapsed;

    const opts = {
      width: 1320,
      height: 860,
      minWidth: 720,
      minHeight: 460,
      show: false,
      title: 'TP Browser',
      titleBarStyle: IS_MAC ? 'hidden' : 'default',
      trafficLightPosition: { x: 18, y: 18 },
      backgroundColor: nativeTheme.shouldUseDarkColors ? '#17171c' : '#ecebf3',
      webPreferences: {
        preload: PRELOAD_UI,
        contextIsolation: true,
        sandbox: true,
        nodeIntegration: false,
        spellcheck: false,
      },
    };
    Object.assign(opts, validBounds(restore && restore.bounds) || cascadeFrom(lastFocused));

    this.win = new BrowserWindow(opts);
    this.id = this.win.id;
    this.ui = this.win.webContents;
    windows.set(this.id, this);
    lastFocused = this;

    this.win.loadFile(path.join(UI_DIR, 'index.html'));
    this.win.once('ready-to-show', () => {
      if (!SMOKE_TEST) this.win.show();
    });
    this.win.on('focus', () => {
      lastFocused = this;
    });
    this.win.on('resize', () => this.layout());
    this.win.on('enter-full-screen', () => this.sendUi('fullscreen', true));
    this.win.on('leave-full-screen', () => {
      this.sendUi('fullscreen', false);
      const fsTab = this.htmlFullscreen;
      if (fsTab && fsTab.alive) {
        fsTab.wc.executeJavaScript('document.fullscreenElement && document.exitFullscreen()', true).catch(() => {});
      }
      this.htmlFullscreen = null;
      this.fullscreenForVideo = false;
      this.syncViews();
    });
    this.win.on('close', () => {
      // Closing the last window keeps its tabs for next time.
      if (!quitting && windows.size === 1) saveSession();
    });
    this.win.on('closed', () => this.destroy());

    // The sidebar page must never navigate away (e.g. a link dropped onto it).
    this.ui.on('will-navigate', (e) => e.preventDefault());
    this.ui.setWindowOpenHandler(() => ({ action: 'deny' }));
    this.ui.on('context-menu', (_e, params) => {
      if (params.isEditable) showEditMenu(params, this.win);
    });
    this.ui.on('did-finish-load', () => {
      this.sendInit();
      onWindowReady(this);
    });

    if (restore && Array.isArray(restore.tabs) && restore.tabs.length) {
      for (const spec of restore.tabs) {
        const sid = spaceById(spec.spaceId) ? spec.spaceId : first;
        const tab = new Tab(this, { url: spec.url, title: spec.title, favicon: spec.favicon, spaceId: sid, sleeping: true });
        this.tabs.push(tab);
      }
      for (const [sid, index] of Object.entries(restore.active || {})) {
        const t = this.tabs[index];
        if (t && t.spaceId === sid) this.activeBySpace.set(sid, t);
      }
    } else {
      for (const u of urls) {
        const tab = new Tab(this, { url: u, spaceId: this.activeSpaceId, sleeping: true });
        this.tabs.push(tab);
      }
    }

    let start = this.activeBySpace.get(this.activeSpaceId) || this.tabsIn(this.activeSpaceId)[0];
    if (!start) start = this.addTab(NEW_TAB_URL, { activate: false, spaceId: this.activeSpaceId });
    this.activate(start);
  }

  get activeTab() {
    const t = this.activeBySpace.get(this.activeSpaceId);
    return t && this.tabs.includes(t) ? t : null;
  }

  tabsIn(spaceId) {
    return this.tabs.filter((t) => t.spaceId === spaceId);
  }

  sendUi(channel, payload) {
    if (this.win.isDestroyed() || this.ui.isDestroyed()) return;
    this.ui.send(channel, payload);
  }

  sendInit() {
    this.sendUi('init', {
      platform: process.platform,
      fullscreen: this.win.isFullScreen(),
      settings: publicSettings(),
      favorites: favoritesPayload(),
      downloads: downloadsFor(this.id),
    });
    this.pushState();
  }

  toast(text, action = null) {
    let actionId = null;
    if (action) {
      actionId = nextToastId++;
      toastActions.set(actionId, action.run);
      setTimeout(() => toastActions.delete(actionId), 120000);
    }
    this.sendUi('toast', { text, actionLabel: action ? action.label : null, actionId });
  }

  addTab(url = NEW_TAB_URL, { activate = true, after = null, spaceId = null, sleeping = false } = {}) {
    const sid = spaceById(spaceId) ? spaceId : after ? after.spaceId : this.activeSpaceId;
    const tab = new Tab(this, { url, spaceId: sid, sleeping: true, openerId: after ? after.id : null });
    let index = this.tabs.length;
    if (after) {
      // Open next to the tab that opened it, after any tabs it already opened.
      let i = this.tabs.indexOf(after);
      if (i !== -1) {
        i += 1;
        while (i < this.tabs.length && this.tabs[i].openerId === after.id) i += 1;
        index = i;
      }
    } else {
      // New tabs go to the end of their space.
      const last = this.tabs.map((t) => t.spaceId).lastIndexOf(sid);
      if (last !== -1) index = last + 1;
    }
    this.tabs.splice(index, 0, tab);
    if (!sleeping) tab.load(url);
    if (activate) this.activate(tab);
    else {
      if (!this.activeBySpace.get(sid)) this.activeBySpace.set(sid, tab);
      this.pushState();
    }
    saveSessionSoon();
    return tab;
  }

  activate(tab, { focus = true } = {}) {
    if (!tab || this.win.isDestroyed() || !this.tabs.includes(tab)) return;
    const prev = this.activeTab;
    if (tab.spaceId !== this.activeSpaceId) {
      this.activeSpaceId = tab.spaceId;
      this.split = null;
    }
    if (this.split && !this.inSplit(tab)) this.split = null;
    this.activeBySpace.set(tab.spaceId, tab);
    const now = Date.now();
    if (prev && prev !== tab) {
      prev.lastActive = now;
      if (prev.alive) prev.wc.stopFindInPage('clearSelection');
      this.sendUi('find:close');
    }
    tab.lastActive = now;
    this.mru = [tab.id, ...this.mru.filter((id) => id !== tab.id)].slice(0, 60);
    tab.wake();
    this.syncViews();
    if (focus && tab.alive && !this.overlayOpen) tab.wc.focus();
    this.pushState();
    saveSessionSoon();
  }

  switchSpace(spaceId) {
    if (!spaceById(spaceId)) return;
    if (spaceId === this.activeSpaceId) return;
    this.split = null;
    let tab = this.activeBySpace.get(spaceId);
    if (!tab || !this.tabs.includes(tab)) tab = this.tabsIn(spaceId)[0];
    if (!tab) tab = this.addTab(NEW_TAB_URL, { activate: false, spaceId });
    this.activate(tab);
  }

  cycleSpace(delta) {
    const list = spaces();
    const i = list.findIndex((s) => s.id === this.activeSpaceId);
    this.switchSpace(list[(i + delta + list.length) % list.length].id);
  }

  closeTab(tab) {
    const idx = this.tabs.indexOf(tab);
    if (idx === -1) return;
    const url = tab.restorableUrl();
    if (url && !url.startsWith('tp://newtab')) {
      this.closedTabs.push({ url, spaceId: tab.spaceId });
      if (this.closedTabs.length > 30) this.closedTabs.shift();
    }
    const siblings = this.tabsIn(tab.spaceId);
    const si = siblings.indexOf(tab);
    const wasActive = this.activeBySpace.get(tab.spaceId) === tab;
    if (this.split && this.inSplit(tab)) this.split = null;
    if (this.htmlFullscreen === tab) this.htmlFullscreen = null;
    this.tabs.splice(idx, 1);
    this.detachView(tab);
    tab.destroy();
    this.mru = this.mru.filter((id) => id !== tab.id);

    if (this.tabs.length === 0) {
      this.win.close();
      return;
    }
    if (wasActive) {
      this.activeBySpace.delete(tab.spaceId);
      let next = siblings[si + 1] || siblings[si - 1] || null;
      if (!next && tab.spaceId === this.activeSpaceId) {
        next = this.addTab(NEW_TAB_URL, { activate: false, spaceId: tab.spaceId });
      }
      if (next) {
        this.activeBySpace.set(tab.spaceId, next);
        if (tab.spaceId === this.activeSpaceId) this.activate(next);
      }
    }
    this.syncViews();
    this.pushState();
    saveSessionSoon();
  }

  reopenClosedTab() {
    const last = this.closedTabs.pop();
    if (!last) return;
    this.addTab(last.url, { spaceId: spaceById(last.spaceId) ? last.spaceId : this.activeSpaceId });
  }

  /** Move a tab before/after another tab (drag and drop in the sidebar). */
  moveTab(tab, target, after) {
    if (!tab || tab === target) return;
    this.tabs.splice(this.tabs.indexOf(tab), 1);
    if (target && this.tabs.includes(target)) {
      tab.spaceId = target.spaceId;
      const ti = this.tabs.indexOf(target);
      this.tabs.splice(after ? ti + 1 : ti, 0, tab);
    } else {
      this.tabs.push(tab);
    }
    this.pushState();
    saveSessionSoon();
  }

  moveTabToSpace(tab, spaceId) {
    if (!tab || !spaceById(spaceId) || tab.spaceId === spaceId) return;
    const from = tab.spaceId;
    const wasActive = this.activeBySpace.get(from) === tab;
    if (this.split && this.inSplit(tab)) this.split = null;
    this.tabs.splice(this.tabs.indexOf(tab), 1);
    tab.spaceId = spaceId;
    const last = this.tabs.map((t) => t.spaceId).lastIndexOf(spaceId);
    this.tabs.splice(last === -1 ? this.tabs.length : last + 1, 0, tab);
    if (wasActive) {
      this.activeBySpace.delete(from);
      const next = this.tabsIn(from)[0] || null;
      if (next) this.activeBySpace.set(from, next);
    }
    this.activeBySpace.set(spaceId, tab);
    this.activate(tab);
    const s = spaceById(spaceId);
    this.toast(`Moved to ${s.icon} ${s.name}`);
  }

  selectTabIndex(i) {
    const list = this.tabsIn(this.activeSpaceId);
    const tab = i === -1 ? list[list.length - 1] : list[i];
    if (tab) this.activate(tab);
  }

  cycleTab(delta) {
    const list = this.tabsIn(this.activeSpaceId);
    if (!this.activeTab || list.length < 2) return;
    const i = list.indexOf(this.activeTab);
    this.activate(list[(i + delta + list.length) % list.length]);
  }

  // --- Split view ----------------------------------------------------------

  inSplit(tab) {
    return !!this.split && (this.split.a === tab || this.split.b === tab);
  }

  splitWith(other) {
    const a = this.activeTab;
    if (!a) return;
    let b = other && other !== a && other.spaceId === a.spaceId ? other : null;
    if (!b) {
      const prevId = this.mru.find((id) => id !== a.id && this.tabs.some((t) => t.id === id && t.spaceId === a.spaceId));
      b = this.tabs.find((t) => t.id === prevId) || null;
    }
    if (!b) {
      const list = this.tabsIn(a.spaceId);
      const i = list.indexOf(a);
      b = list[i + 1] || list[i - 1] || null;
    }
    if (!b) b = this.addTab(NEW_TAB_URL, { activate: false, after: a });
    b.wake();
    this.split = { a, b };
    this.syncViews();
    this.pushState();
  }

  exitSplit() {
    if (!this.split) return;
    this.split = null;
    this.syncViews();
    this.pushState();
  }

  onTabFocused(tab) {
    if (this.inSplit(tab) && this.activeTab !== tab) {
      this.activeBySpace.set(tab.spaceId, tab);
      this.mru = [tab.id, ...this.mru.filter((id) => id !== tab.id)];
      this.pushState();
    }
  }

  // --- Sidebar ----------------------------------------------------------------

  toggleSidebar(force) {
    this.sidebarCollapsed = typeof force === 'boolean' ? force : !this.sidebarCollapsed;
    settings.data.sidebarCollapsed = this.sidebarCollapsed;
    settings.saveSoon();
    this.pushState();
    buildAppMenuSoon();
  }

  focusAddressBar() {
    this.openOverlay('current');
  }

  // --- Views & layout -----------------------------------------------------

  detachView(tab) {
    if (!tab.view || !this.attached.has(tab.view)) return;
    try {
      this.win.contentView.removeChildView(tab.view);
    } catch {
      /* already gone */
    }
    this.attached.delete(tab.view);
  }

  visibleTabs() {
    if (this.htmlFullscreen && this.htmlFullscreen.alive && this.tabs.includes(this.htmlFullscreen)) return [this.htmlFullscreen];
    if (this.covered) return [];
    const s = this.split;
    if (s && s.a.alive && s.b.alive && this.tabs.includes(s.a) && this.tabs.includes(s.b) && s.a.spaceId === this.activeSpaceId) {
      return [s.a, s.b];
    }
    if (s) this.split = null;
    const t = this.activeTab;
    return t && t.alive ? [t] : [];
  }

  syncViews() {
    if (this.win.isDestroyed()) return;
    const want = this.visibleTabs().map((t) => t.view);
    if (this.overlayOpen && this.overlay) want.push(this.overlay);
    for (const v of [...this.attached]) {
      if (!want.includes(v)) {
        try {
          this.win.contentView.removeChildView(v);
        } catch {
          /* already gone */
        }
        this.attached.delete(v);
      }
    }
    for (const v of want) {
      if (!this.attached.has(v)) {
        this.win.contentView.addChildView(v);
        this.attached.add(v);
      }
    }
    // Keep the command bar on top.
    if (this.overlayOpen && this.overlay) this.win.contentView.addChildView(this.overlay);
    this.layout();
  }

  layout() {
    if (this.win.isDestroyed()) return;
    const [cw, ch] = this.win.getContentSize();
    const full = { x: 0, y: 0, width: cw, height: ch };
    const r = this.pageRect || full;
    const visible = this.visibleTabs();
    if (this.htmlFullscreen && visible[0] === this.htmlFullscreen) {
      visible[0].view.setBounds(full);
      setRadius(visible[0].view, 0);
    } else if (visible.length === 2) {
      const w1 = Math.floor((r.width - SPLIT_GAP) / 2);
      visible[0].view.setBounds({ x: r.x, y: r.y, width: w1, height: r.height });
      visible[1].view.setBounds({ x: r.x + w1 + SPLIT_GAP, y: r.y, width: Math.max(0, r.width - w1 - SPLIT_GAP), height: r.height });
      visible.forEach((t) => setRadius(t.view, PAGE_RADIUS));
    } else if (visible.length === 1) {
      visible[0].view.setBounds(r);
      setRadius(visible[0].view, PAGE_RADIUS);
    }
    if (this.overlay) this.overlay.setBounds(full);
  }

  // --- Command bar overlay -------------------------------------------------

  openOverlay(mode = 'current', text = '') {
    if (this.win.isDestroyed()) return;
    if (!this.overlay) {
      this.overlay = new WebContentsView({
        webPreferences: {
          preload: PRELOAD_OVERLAY,
          contextIsolation: true,
          sandbox: true,
          nodeIntegration: false,
          spellcheck: false,
        },
      });
      this.overlay.setBackgroundColor('#00000000');
      const owc = this.overlay.webContents;
      this.overlayReady = new Promise((resolve) => owc.once('did-finish-load', resolve));
      owc.loadFile(path.join(UI_DIR, 'overlay.html'));
      owc.on('will-navigate', (e) => e.preventDefault());
      owc.setWindowOpenHandler(() => ({ action: 'deny' }));
      owc.on('context-menu', (_e, params) => {
        if (params.isEditable) showEditMenu(params, this.win);
      });
    }
    this.overlayOpen = true;
    this.syncViews();
    const t = this.activeTab;
    const s = spaceById(this.activeSpaceId);
    const payload = {
      mode,
      text: mode === 'current' && t ? t.displayUrl() : text,
      space: { ...s, colors: SPACE_COLORS[s.color] || SPACE_COLORS.violet },
      engine: SEARCH_ENGINES[engineKey()].name,
    };
    const owc = this.overlay.webContents;
    this.overlayReady.then(() => {
      if (!this.overlayOpen || owc.isDestroyed()) return;
      owc.focus();
      owc.send('overlay:open', payload);
    });
  }

  closeOverlay({ refocus = true } = {}) {
    if (!this.overlayOpen) return;
    this.overlayOpen = false;
    this.syncViews();
    if (refocus) {
      const t = this.activeTab;
      if (t && t.alive) t.wc.focus();
    }
  }

  // --- State to the sidebar ---------------------------------------------------

  statePayload() {
    const t = this.activeTab;
    const url = t ? t.displayUrl() : '';
    const host = util.hostnameOf(url);
    return {
      tabs: this.tabs.map((x) => x.state()),
      activeId: t ? t.id : null,
      spaceId: this.activeSpaceId,
      spaces: publicSpaces().map((s) => ({ ...s, count: this.tabs.filter((x) => x.spaceId === s.id).length })),
      split: this.split ? [this.split.a.id, this.split.b.id] : null,
      canReopen: this.closedTabs.length > 0,
      collapsed: this.sidebarCollapsed,
      focus: focusState(),
      shield: {
        on: !!settings.data.shield,
        applicable: util.isHttpUrl(url),
        allowed: !!host && util.hostInList(host, settings.data.shieldAllow),
        blocked: t ? t.blocked : 0,
      },
    };
  }

  pushState() {
    if (this._pushQueued) return;
    this._pushQueued = true;
    setImmediate(() => {
      this._pushQueued = false;
      if (this.win.isDestroyed()) return;
      this.sendUi('state', this.statePayload());
      const t = this.activeTab;
      this.win.setTitle(t ? t.displayTitle() : 'TP Browser');
    });
  }

  /** For frequent updates (blocked counters): at most a few times a second. */
  pushStateLazy() {
    if (this._lazyTimer) return;
    this._lazyTimer = setTimeout(() => {
      this._lazyTimer = null;
      this.pushState();
    }, 500);
  }

  snapshot() {
    const active = {};
    for (const [sid, t] of this.activeBySpace) {
      const i = this.tabs.indexOf(t);
      if (i !== -1) active[sid] = i;
    }
    return {
      activeSpaceId: this.activeSpaceId,
      sidebarCollapsed: this.sidebarCollapsed,
      bounds: this.win.isDestroyed() ? null : this.win.getNormalBounds(),
      tabs: this.tabs.map((t) => ({
        url: t.restorableUrl(),
        title: t.title,
        favicon: t.favicon && t.favicon.length < 2000 ? t.favicon : null,
        spaceId: t.spaceId,
      })),
      active,
    };
  }

  destroy() {
    for (const tab of this.tabs) tab.destroy();
    if (this.overlay && !this.overlay.webContents.isDestroyed()) this.overlay.webContents.close();
    this.overlay = null;
    clearTimeout(this._lazyTimer);
    this.tabs = [];
    windows.delete(this.id);
    if (lastFocused === this) lastFocused = windows.values().next().value || null;
    buildAppMenuSoon();
  }
}

function validBounds(b) {
  if (!b || !Number.isFinite(b.width) || !Number.isFinite(b.height)) return null;
  const area = screen.getDisplayMatching(b).workArea;
  const onScreen =
    b.x < area.x + area.width - 80 && b.x + b.width > area.x + 80 && b.y >= area.y - 20 && b.y < area.y + area.height - 80;
  return onScreen ? { x: b.x, y: b.y, width: b.width, height: b.height } : { width: b.width, height: b.height };
}

function cascadeFrom(w) {
  if (!w || w.win.isDestroyed()) return null;
  const b = w.win.getBounds();
  return { x: b.x + 26, y: b.y + 26, width: b.width, height: b.height };
}

// ---------------------------------------------------------------------------
// Context menus
// ---------------------------------------------------------------------------

function showEditMenu(params, win) {
  const f = params.editFlags || {};
  Menu.buildFromTemplate([
    { role: 'undo', enabled: f.canUndo },
    { role: 'redo', enabled: f.canRedo },
    { type: 'separator' },
    { role: 'cut', enabled: f.canCut },
    { role: 'copy', enabled: f.canCopy },
    { role: 'paste', enabled: f.canPaste },
    { role: 'pasteAndMatchStyle', enabled: f.canPaste },
    { role: 'selectAll' },
  ]).popup({ window: win });
}

function showPageMenu(wc, p, owner, tab) {
  const t = [];
  const sep = { type: 'separator' };
  const openInTab = (url, activate = false) => owner.addTab(url, { activate, after: tab });

  if (p.misspelledWord) {
    for (const s of (p.dictionarySuggestions || []).slice(0, 5)) {
      t.push({ label: s, click: () => wc.replaceMisspelling(s) });
    }
    if (!p.dictionarySuggestions || !p.dictionarySuggestions.length) t.push({ label: 'No Guesses Found', enabled: false });
    t.push({ label: 'Add to Dictionary', click: () => wc.session.addWordToSpellCheckerDictionary(p.misspelledWord) }, sep);
  }

  if (p.linkURL) {
    t.push(
      { label: 'Open Link in New Tab', click: () => openInTab(p.linkURL) },
      {
        label: 'Open Link in Split View',
        enabled: !!tab,
        click: () => {
          const nt = owner.addTab(p.linkURL, { activate: false, after: tab });
          owner.activate(tab);
          owner.splitWith(nt);
        },
      },
      { label: 'Open Link in New Window', click: () => new TPWindow({ urls: [p.linkURL], spaceId: owner.activeSpaceId }) },
      { label: 'Copy Link Address', click: () => clipboard.writeText(p.linkURL) },
      sep
    );
  }

  if (p.mediaType === 'image' && p.srcURL) {
    t.push(
      { label: 'Open Image in New Tab', click: () => openInTab(p.srcURL) },
      { label: 'Save Image to Downloads', click: () => wc.downloadURL(p.srcURL) },
      { label: 'Copy Image', click: () => wc.copyImageAt(p.x, p.y) },
      { label: 'Copy Image Address', click: () => clipboard.writeText(p.srcURL) },
      sep
    );
  }

  if (p.mediaType === 'video') {
    t.push({ label: 'Picture in Picture', click: () => pictureInPicture(owner) }, sep);
  }

  if (p.isEditable) {
    const f = p.editFlags || {};
    t.push(
      { role: 'undo', enabled: f.canUndo },
      { role: 'redo', enabled: f.canRedo },
      sep,
      { role: 'cut', enabled: f.canCut },
      { role: 'copy', enabled: f.canCopy },
      { role: 'paste', enabled: f.canPaste },
      { role: 'selectAll' },
      sep
    );
  } else if (p.selectionText && p.selectionText.trim()) {
    const sel = p.selectionText.trim();
    const short = sel.length > 24 ? sel.slice(0, 24) + '…' : sel;
    t.push(
      { role: 'copy' },
      { label: `Ask TP AI About “${short}”`, click: () => owner.sendUi('command', { name: 'ai-ask', text: `Explain this simply:\n\n${sel.slice(0, 3000)}` }) },
      {
        label: `Search ${SEARCH_ENGINES[engineKey()].name} for “${short}”`,
        click: () => openInTab(util.searchUrl(sel, engineKey()), true),
      },
      sep
    );
  }

  if (!p.linkURL && !p.isEditable && !(p.selectionText || '').trim() && p.mediaType === 'none') {
    const nav = navOf(wc);
    t.push(
      { label: 'Back', enabled: nav.canGoBack(), click: () => nav.goBack() },
      { label: 'Forward', enabled: nav.canGoForward(), click: () => nav.goForward() },
      { label: 'Reload', click: () => wc.reload() },
      sep
    );
    if (tab) {
      const url = tab.displayUrl();
      const web = util.isHttpUrl(url);
      t.push(
        { label: 'Ask TP AI About This Page', enabled: web, click: () => owner.sendUi('command', { name: 'ai-ask', text: 'Summarize this page in 5 short bullet points.', withPage: true }) },
        { label: 'Reader View', enabled: web, click: () => owner.sendUi('command', { name: 'reader' }) },
        { label: 'Listen to This Page', enabled: web, click: () => owner.sendUi('command', { name: 'reader', listen: true }) },
        { label: 'Translate Page', enabled: web, submenu: translateMenuItems(owner) },
        { label: 'Dark Mode on This Site', type: 'checkbox', enabled: web, checked: darkOnFor(url), click: () => toggleSiteDark(owner) },
        sep,
        { label: 'Take Screenshot', click: () => takeScreenshot(owner) },
        { label: 'Copy Page Link', click: () => copyUrl(owner) },
        { label: 'Share with QR Code…', enabled: web, click: () => owner.sendUi('command', { name: 'qr' }) },
        sep
      );
    }
  }

  t.push({ label: 'Inspect Element', click: () => wc.inspectElement(p.x, p.y) });
  // Tabs pop their menu in the TP window; sign-in popups in their own window.
  const win = tab ? owner.win : BrowserWindow.fromWebContents(wc) || owner.win;
  if (!win || win.isDestroyed()) return;
  Menu.buildFromTemplate(t).popup({ window: win });
}

function showTabMenu(w, tab) {
  const others = spaces().filter((s) => s.id !== tab.spaceId);
  const list = w.tabsIn(tab.spaceId);
  const idx = list.indexOf(tab);
  Menu.buildFromTemplate([
    { label: 'New Tab', click: () => w.addTab(NEW_TAB_URL, { after: tab }) },
    { type: 'separator' },
    { label: 'Reload', enabled: tab.alive, click: () => tab.alive && tab.wc.reload() },
    { label: 'Duplicate', click: () => w.addTab(tab.restorableUrl(), { after: tab }) },
    { label: 'Copy Link', enabled: !!tab.displayUrl(), click: () => clipboard.writeText(tab.displayUrl()) },
    {
      label: (tab.alive ? tab.wc.isAudioMuted() : tab.mutedPref) ? 'Unmute Tab' : 'Mute Tab',
      click: () => toggleMute(w, tab),
    },
    {
      label: w.inSplit(tab) ? 'Exit Split View' : 'Open in Split View',
      enabled: w.inSplit(tab) || (tab !== w.activeTab && tab.spaceId === w.activeSpaceId),
      click: () => (w.inSplit(tab) ? w.exitSplit() : w.splitWith(tab)),
    },
    { label: 'Sleep Tab', enabled: tab.alive && tab !== w.activeTab && !w.inSplit(tab), click: () => tab.sleep() },
    {
      label: 'Move to Space',
      enabled: others.length > 0,
      submenu: others.length
        ? others.map((s) => ({ label: `${s.icon}  ${s.name}`, click: () => w.moveTabToSpace(tab, s.id) }))
        : [{ label: 'No other spaces', enabled: false }],
    },
    { type: 'separator' },
    { label: 'Close Tab', click: () => w.closeTab(tab) },
    {
      label: 'Close Other Tabs',
      enabled: list.length > 1,
      click: () => list.filter((t) => t !== tab).forEach((t) => w.closeTab(t)),
    },
    {
      label: 'Close Tabs Below',
      enabled: idx < list.length - 1,
      click: () => list.slice(idx + 1).forEach((t) => w.closeTab(t)),
    },
    { type: 'separator' },
    { label: 'Reopen Closed Tab', enabled: w.closedTabs.length > 0, click: () => w.reopenClosedTab() },
  ]).popup({ window: w.win });
}

function showSpaceMenu(w, id) {
  const s = spaceById(id);
  if (!s) return;
  Menu.buildFromTemplate([
    { label: `${s.icon}  ${s.name}`, enabled: false },
    { type: 'separator' },
    { label: 'Rename…', click: () => w.sendUi('command', { name: 'rename-space', id }) },
    {
      label: 'Icon',
      submenu: SPACE_ICONS.map((icon) => ({ label: icon, type: 'radio', checked: s.icon === icon, click: () => updateSpace(id, { icon }) })),
    },
    {
      label: 'Color',
      submenu: Object.keys(SPACE_COLORS).map((c) => ({
        label: c[0].toUpperCase() + c.slice(1),
        type: 'radio',
        checked: s.color === c,
        click: () => updateSpace(id, { color: c }),
      })),
    },
    { type: 'separator' },
    { label: 'New Space', click: () => newSpace(w) },
    { label: 'Delete Space…', enabled: spaces().length > 1, click: () => deleteSpace(id, w) },
  ]).popup({ window: w.win });
}

function showShieldMenu(w) {
  const t = w.activeTab;
  const url = t ? t.displayUrl() : '';
  const host = util.hostnameOf(url);
  const on = !!settings.data.shield;
  const allowed = !!host && util.hostInList(host, settings.data.shieldAllow);
  const items = [
    { label: on ? `TP Shield blocked ${t ? t.blocked : 0} ads & trackers here` : 'TP Shield is off', enabled: false },
    { label: `${statsSummary().blockedWeek.toLocaleString()} blocked this week`, enabled: false },
    { type: 'separator' },
  ];
  if (host && on) {
    items.push({ label: `Shield On for ${host.replace(/^www\./, '')}`, type: 'checkbox', checked: !allowed, click: () => toggleSiteShield(w) });
  }
  items.push(
    { label: on ? 'Turn Off Everywhere' : 'Turn On', click: () => setSetting('shield', !on) },
    {
      label: 'Skip YouTube Ads',
      type: 'checkbox',
      checked: !!settings.data.ytSkip,
      click: () => setSetting('ytSkip', !settings.data.ytSkip),
    },
    { type: 'separator' },
    { label: 'Shield Settings…', click: () => openInternal(w, 'tp://settings/#shield') }
  );
  Menu.buildFromTemplate(items).popup({ window: w.win });
}

function showFocusMenu(w) {
  const st = focusState();
  if (!st) {
    const opts = [15, 25, 45, 60, 90];
    Menu.buildFromTemplate([
      { label: 'Start a focus session', enabled: false },
      ...opts.map((m) => ({ label: `${m} minutes`, click: () => startFocus(m) })),
      { type: 'separator' },
      { label: 'Choose Distracting Sites…', click: () => openInternal(w, 'tp://settings/#focus') },
    ]).popup({ window: w.win });
    return;
  }
  Menu.buildFromTemplate([
    { label: 'Add 5 Minutes', click: () => extendFocus(5) },
    { label: 'Add 15 Minutes', click: () => extendFocus(15) },
    { type: 'separator' },
    { label: 'End Focus Session', click: () => endFocus({ completed: false }) },
  ]).popup({ window: w.win });
}

function toggleMute(w, tab) {
  if (tab.alive) tab.wc.setAudioMuted(!tab.wc.isAudioMuted());
  else tab.mutedPref = !tab.mutedPref;
  w.pushState();
}

// ---------------------------------------------------------------------------
// Spaces
// ---------------------------------------------------------------------------

function spacesChanged() {
  settings.save();
  broadcast('settings', publicSettings());
  for (const w of windows.values()) w.pushState();
  buildAppMenuSoon();
}

function newSpace(w) {
  const list = spaces();
  if (list.length >= 9) {
    if (w) w.toast('You can have up to 9 spaces.');
    return null;
  }
  const usedColors = new Set(list.map((s) => s.color));
  const color = Object.keys(SPACE_COLORS).find((c) => !usedColors.has(c)) || 'violet';
  const usedIcons = new Set(list.map((s) => s.icon));
  const icon = SPACE_ICONS.find((i) => !usedIcons.has(i)) || '✨';
  const space = { id: 's' + Date.now().toString(36), name: 'New Space', icon, color };
  settings.data.spaces = [...list, space];
  spacesChanged();
  if (w) {
    w.switchSpace(space.id);
    w.sendUi('command', { name: 'rename-space', id: space.id });
  }
  return space;
}

function updateSpace(id, patch = {}) {
  const s = spaceById(id);
  if (!s) return;
  const next = { ...s };
  if (typeof patch.name === 'string' && patch.name.trim()) next.name = patch.name.trim().slice(0, 24);
  if (typeof patch.icon === 'string' && patch.icon.trim() && [...patch.icon.trim()].length <= 4) next.icon = patch.icon.trim();
  if (typeof patch.color === 'string' && SPACE_COLORS[patch.color]) next.color = patch.color;
  settings.data.spaces = spaces().map((x) => (x.id === id ? next : x));
  spacesChanged();
}

async function deleteSpace(id, w) {
  const s = spaceById(id);
  if (!s || spaces().length <= 1) return false;
  let count = 0;
  for (const win of windows.values()) count += win.tabsIn(id).length;
  if (count > 0) {
    const opts = {
      type: 'warning',
      buttons: ['Delete Space', 'Cancel'],
      defaultId: 1,
      cancelId: 1,
      message: `Delete “${s.name}”?`,
      detail: `Its ${count} tab${count === 1 ? '' : 's'} will be closed.`,
    };
    const { response } = w ? await dialog.showMessageBox(w.win, opts) : await dialog.showMessageBox(opts);
    if (response !== 0) return false;
  }
  settings.data.spaces = spaces().filter((x) => x.id !== id);
  const fallback = spaces()[0].id;
  for (const win of [...windows.values()]) {
    if (win.activeSpaceId === id) win.switchSpace(fallback);
    for (const t of win.tabsIn(id)) {
      if (win.tabs.length > 1) win.closeTab(t);
      else {
        t.spaceId = fallback;
        win.activeBySpace.set(fallback, t);
      }
    }
    win.activeBySpace.delete(id);
  }
  spacesChanged();
  return true;
}

// ---------------------------------------------------------------------------
// Bookmarks & favorites
// ---------------------------------------------------------------------------

let bookmarkSet = new Set();
function refreshBookmarkSet() {
  bookmarkSet = new Set(bookmarks.data.map((b) => b.url));
}

function isBookmarked(url) {
  return !!url && bookmarkSet.has(url);
}

function favoritesPayload() {
  return bookmarks.data
    .filter((b) => b.pinned !== false)
    .slice(0, 12)
    .map((b) => ({ id: b.id, title: b.title, url: b.url, favicon: b.favicon || faviconFor(b.url) }));
}

function bookmarksChanged({ rebuildMenu = true } = {}) {
  refreshBookmarkSet();
  bookmarks.saveSoon(300);
  broadcast('favorites', favoritesPayload());
  for (const w of windows.values()) w.pushState();
  if (rebuildMenu) buildAppMenuSoon();
}

function newId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function toggleBookmark(w) {
  const tab = w && w.activeTab;
  if (!tab) return;
  const url = tab.displayUrl();
  if (!util.isHttpUrl(url) && !url.startsWith('file:')) return;
  const i = bookmarks.data.findIndex((b) => b.url === url);
  if (i !== -1) {
    bookmarks.data.splice(i, 1);
    w.toast('Removed from bookmarks');
  } else {
    const pinnedCount = bookmarks.data.filter((b) => b.pinned !== false).length;
    bookmarks.data.unshift({
      id: newId(),
      title: tab.title || util.hostnameOf(url) || url,
      url,
      favicon: tab.favicon || faviconFor(url),
      pinned: pinnedCount < 12,
    });
    w.toast(pinnedCount < 12 ? '⭐ Added to Favorites' : '⭐ Bookmarked');
  }
  bookmarksChanged();
}

function removeBookmark(id) {
  const i = bookmarks.data.findIndex((b) => b.id === id);
  if (i !== -1) {
    bookmarks.data.splice(i, 1);
    bookmarksChanged();
  }
}

function setPinned(id, pinned) {
  const b = bookmarks.data.find((x) => x.id === id);
  if (!b) return;
  b.pinned = !!pinned;
  bookmarksChanged();
}

function openFavorite(w, id, { newTab = false } = {}) {
  const b = bookmarks.data.find((x) => x.id === id);
  if (!b) return;
  if (!newTab) {
    // Jump to an open tab on the same site in this space instead of opening a duplicate.
    const host = util.hostnameOf(b.url);
    const existing = w.tabsIn(w.activeSpaceId).find((t) => util.hostnameOf(t.displayUrl()) === host);
    if (existing) {
      w.activate(existing);
      return;
    }
  }
  w.addTab(b.url);
}

function showFavoriteMenu(w, id) {
  const b = bookmarks.data.find((x) => x.id === id);
  if (!b) return;
  Menu.buildFromTemplate([
    { label: b.title.length > 40 ? b.title.slice(0, 40) + '…' : b.title, enabled: false },
    { type: 'separator' },
    { label: 'Open in New Tab', click: () => w.addTab(b.url) },
    { label: 'Open in New Window', click: () => new TPWindow({ urls: [b.url], spaceId: w.activeSpaceId }) },
    { label: 'Copy Address', click: () => clipboard.writeText(b.url) },
    { type: 'separator' },
    { label: 'Remove from Favorites', click: () => setPinned(id, false) },
    { label: 'Delete Bookmark', click: () => removeBookmark(id) },
  ]).popup({ window: w.win });
}

function importBookmarks(key) {
  const list = importer.readBrowser(app.getPath('appData'), key);
  const existing = new Set(bookmarks.data.map((b) => b.url));
  let pinBudget = Math.max(0, 8 - bookmarks.data.filter((b) => b.pinned !== false).length);
  let added = 0;
  for (const item of list) {
    if (existing.has(item.url) || bookmarks.data.length >= 5000) continue;
    existing.add(item.url);
    const pin = item.bar && pinBudget > 0;
    if (pin) pinBudget -= 1;
    bookmarks.data.push({
      id: newId(),
      title: item.title || util.hostnameOf(item.url),
      url: item.url,
      favicon: faviconFor(item.url),
      pinned: pin,
      folder: item.folder || '',
    });
    added += 1;
  }
  bookmarksChanged();
  return { added, total: list.length };
}

// ---------------------------------------------------------------------------
// Downloads
// ---------------------------------------------------------------------------

function downloadsFor(winId) {
  return [...downloads.values()]
    .filter((d) => d.winId === winId && !d.hidden)
    .sort((a, b) => b.id - a.id)
    .map(({ id, filename, received, total, state, paused }) => ({ id, filename, received, total, state, paused }));
}

function pushDownloads(winId) {
  const w = windows.get(winId);
  if (!w) return;
  w.sendUi('downloads', downloadsFor(winId));
  const active = [...downloads.values()].filter((d) => d.winId === winId && d.state === 'progressing');
  const total = active.reduce((s, d) => s + (d.total || 0), 0);
  const received = active.reduce((s, d) => s + (d.received || 0), 0);
  if (!w.win.isDestroyed()) w.win.setProgressBar(active.length && total > 0 ? received / total : -1);
}

function setupDownloads(ses) {
  ses.on('will-download', (_event, item, wc) => {
    const tab = wc ? tabsByWcId.get(wc.id) : null;
    const owner = tab ? tab.owner : currentWindow();
    const savePath = util.uniquePath(app.getPath('downloads'), item.getFilename());
    item.setSavePath(savePath);

    const d = {
      id: nextDownloadId++,
      item,
      winId: owner ? owner.id : null,
      filename: path.basename(savePath),
      path: savePath,
      received: 0,
      total: item.getTotalBytes(),
      state: 'progressing',
      paused: false,
    };
    downloads.set(d.id, d);

    item.on('updated', (_e, state) => {
      d.state = state === 'interrupted' ? 'interrupted' : 'progressing';
      d.paused = item.isPaused();
      d.received = item.getReceivedBytes();
      d.total = item.getTotalBytes();
      pushDownloads(d.winId);
    });
    item.once('done', (_e, state) => {
      d.state = state; // completed | cancelled | interrupted
      d.received = item.getReceivedBytes();
      d.item = null;
      if (state === 'completed' && IS_MAC && app.dock) app.dock.downloadFinished(savePath);
      pushDownloads(d.winId);
    });
    pushDownloads(d.winId);
  });
}

function downloadAction(id, action) {
  const d = downloads.get(id);
  if (!d) return;
  if (action === 'open' && d.state === 'completed') shell.openPath(d.path);
  else if (action === 'show') {
    if (fs.existsSync(d.path)) shell.showItemInFolder(d.path);
    else shell.openPath(app.getPath('downloads'));
  } else if (action === 'cancel' && d.item) d.item.cancel();
  else if (action === 'pause' && d.item) d.item.pause();
  else if (action === 'resume' && d.item && d.item.canResume()) d.item.resume();
}

// ---------------------------------------------------------------------------
// Permissions (camera, mic, location, notifications ...)
// ---------------------------------------------------------------------------

const ALWAYS_ALLOWED = new Set(['fullscreen', 'clipboard-sanitized-write', 'pointerLock', 'keyboardLock']);
const ASK = {
  media: 'use your camera and microphone',
  geolocation: 'know your location',
  notifications: 'show notifications',
  'clipboard-read': 'see text and images you copy',
  midi: 'use your MIDI devices',
  midiSysex: 'use your MIDI devices',
  'display-capture': 'see your screen',
  'idle-detection': 'know when you are using your device',
};

function originOf(url) {
  try {
    return new URL(url).origin;
  } catch {
    return '';
  }
}

function setupPermissions(ses) {
  ses.setPermissionRequestHandler((wc, permission, callback, details) => {
    const requestUrl = (details && (details.requestingUrl || details.securityOrigin)) || (wc ? wc.getURL() : '');
    if (/^tp:/i.test(requestUrl)) return callback(true);
    if (ALWAYS_ALLOWED.has(permission)) return callback(true);
    if (!ASK[permission]) return callback(false);

    const key = `${originOf(requestUrl)}|${permission}`;
    if (permissionDecisions.has(key)) return callback(permissionDecisions.get(key));

    let what = ASK[permission];
    if (permission === 'media' && details && Array.isArray(details.mediaTypes)) {
      const v = details.mediaTypes.includes('video');
      const a = details.mediaTypes.includes('audio');
      if (v && !a) what = 'use your camera';
      if (a && !v) what = 'use your microphone';
    }

    const tab = wc ? tabsByWcId.get(wc.id) : null;
    const parent = tab && !tab.owner.win.isDestroyed() ? tab.owner.win : BrowserWindow.getFocusedWindow();
    const opts = {
      type: 'question',
      buttons: ['Allow', 'Block'],
      defaultId: 0,
      cancelId: 1,
      message: `${util.hostOf(requestUrl) || 'This site'} wants to ${what}.`,
      detail: 'TP Browser will remember your choice until you quit the app.',
    };
    const ask = parent ? dialog.showMessageBox(parent, opts) : dialog.showMessageBox(opts);
    ask.then(({ response }) => {
      const allow = response === 0;
      permissionDecisions.set(key, allow);
      callback(allow);
    });
  });

  ses.setPermissionCheckHandler((_wc, permission, requestingOrigin) => {
    if (/^tp:/i.test(requestingOrigin || '')) return true;
    if (ALWAYS_ALLOWED.has(permission)) return true;
    const key = `${originOf(requestingOrigin)}|${permission}`;
    if (permissionDecisions.has(key)) return permissionDecisions.get(key);
    // Undecided: notifications stay off until a site asks and you allow it.
    return permission !== 'notifications';
  });
}

// ---------------------------------------------------------------------------
// TP Shield
// ---------------------------------------------------------------------------

function setupShield(ses) {
  ses.webRequest.onBeforeRequest({ urls: ['http://*/*', 'https://*/*', 'ws://*/*', 'wss://*/*'] }, (details, callback) => {
    if (!settings.data.shield || details.resourceType === 'mainFrame') return callback({});
    const requestHost = util.hostnameOf(details.url);
    if (!requestHost) return callback({});
    const tab = tabsByWcId.get(details.webContentsId);
    let pageUrl = '';
    if (tab && tab.alive) pageUrl = tab.wc.getURL();
    else if (details.webContents && !details.webContents.isDestroyed()) pageUrl = details.webContents.getURL();
    if (!pageUrl && details.webContentsId === undefined) return callback({}); // the browser's own requests
    const pageHost = util.hostnameOf(pageUrl);
    if (pageHost && util.hostInList(pageHost, settings.data.shieldAllow)) return callback({});
    if (!shield.shouldBlock(details.url, requestHost, pageHost)) return callback({});
    if (tab) {
      tab.blocked += 1;
      if (tab.owner.activeTab === tab) tab.owner.pushStateLazy();
    }
    countBlocked();
    callback({ cancel: true });
  });
}

function applyShieldToPage(tab) {
  if (!tab.alive) return;
  const url = tab.wc.getURL();
  if (!util.isHttpUrl(url) || !settings.data.shield) return;
  const host = util.hostnameOf(url);
  if (util.hostInList(host, settings.data.shieldAllow)) return;
  tab.wc.insertCSS(shield.COSMETIC_CSS, { cssOrigin: 'user' }).catch(() => {});
  if (settings.data.ytSkip && /(^|\.)youtube\.com$/.test(host)) {
    tab.wc.executeJavaScriptInIsolatedWorld(1001, [{ code: shield.YT_SKIPPER }]).catch(() => {});
  }
}

function toggleSiteShield(w) {
  const t = w.activeTab;
  const host = t ? util.hostnameOf(t.displayUrl()).replace(/^www\./, '') : '';
  if (!host) return;
  const list = settings.data.shieldAllow.filter((h) => h !== host && !host.endsWith('.' + h));
  const allowedBefore = list.length !== settings.data.shieldAllow.length;
  setSetting('shieldAllow', allowedBefore ? list : [...list, host]);
  w.toast(allowedBefore ? `🛡️ Shield back on for ${host}` : `Shield off for ${host}`);
  if (t.alive) t.wc.reload();
}

// ---------------------------------------------------------------------------
// Little power tools: screenshot, picture-in-picture, copy link
// ---------------------------------------------------------------------------

async function takeScreenshot(w) {
  const t = w && w.activeTab;
  if (!t || !t.alive) return;
  try {
    const img = await t.wc.capturePage();
    clipboard.writeImage(img);
    const d = new Date();
    const stamp = `${util.dayKey(d)} at ${String(d.getHours()).padStart(2, '0')}.${String(d.getMinutes()).padStart(2, '0')}.${String(d.getSeconds()).padStart(2, '0')}`;
    const file = util.uniquePath(app.getPath('downloads'), `TP Screenshot ${stamp}.png`);
    await fs.promises.writeFile(file, img.toPNG());
    w.toast('📸 Screenshot copied and saved to Downloads', { label: 'Show', run: () => shell.showItemInFolder(file) });
  } catch (err) {
    w.toast('Couldn’t take a screenshot of this page');
  }
}

const PIP_CODE = `(async () => {
  if (document.pictureInPictureElement) { await document.exitPictureInPicture(); return 'exit'; }
  const vids = [...document.querySelectorAll('video')].filter((v) => v.readyState > 0 && !v.disablePictureInPicture);
  if (!vids.length) return 'none';
  vids.sort((a, b) => b.clientWidth * b.clientHeight - a.clientWidth * a.clientHeight);
  const v = vids.find((x) => !x.paused) || vids[0];
  await v.requestPictureInPicture();
  return 'ok';
})()`;

async function pictureInPicture(w) {
  const t = w && w.activeTab;
  if (!t || !t.alive) return;
  const frames = [t.wc.mainFrame, ...(t.wc.mainFrame.framesInSubtree || []).filter((f) => f !== t.wc.mainFrame)];
  let sawError = false;
  for (const frame of frames) {
    try {
      const r = await frame.executeJavaScript(PIP_CODE, true);
      if (r === 'ok' || r === 'exit') return;
    } catch {
      sawError = true;
    }
  }
  w.toast(sawError ? 'This video can’t pop out' : 'No video found on this page');
}

function copyUrl(w) {
  const t = w && w.activeTab;
  const url = t ? t.displayUrl() : '';
  if (!url) return;
  clipboard.writeText(url);
  w.toast('🔗 Link copied');
}

function openInternal(w, url) {
  const target = w || currentWindow();
  if (!target) return new TPWindow({ urls: [url] });
  const base = url.split('#')[0];
  const existing = target.tabs.find((t) => t.rawUrl().split('#')[0] === base);
  if (existing) {
    if (url !== base && existing.alive) existing.wc.loadURL(url).catch(() => {});
    target.activate(existing);
  } else target.addTab(url);
  if (target.win.isMinimized()) target.win.restore();
  target.win.focus();
}


// ---------------------------------------------------------------------------
// Dark mode for websites (bright pages turn dark; pictures keep their colours)
// ---------------------------------------------------------------------------

function darkOnFor(url) {
  return !!settings.data.darkPages && util.isHttpUrl(url) && !util.hostInList(util.hostnameOf(url), settings.data.darkExcept);
}

function darkCode() {
  return DARK_JS.replace('__TP_EXCEPT__', JSON.stringify(Array.isArray(settings.data.darkExcept) ? settings.data.darkExcept : []));
}

/** After the setting changes: restyle every open page now (new pages get it from preload-tab.js). */
function applyDarkAll() {
  if (!DARK_JS) return;
  const code = settings.data.darkPages ? darkCode() : DARK_OFF_JS;
  for (const w of windows.values()) {
    for (const t of w.tabs) {
      if (t.alive && util.isHttpUrl(t.wc.getURL())) t.wc.executeJavaScriptInIsolatedWorld(WORLD_DARK, [{ code }]).catch(() => {});
    }
  }
}

function toggleSiteDark(w) {
  const t = w && w.activeTab;
  const url = t ? t.displayUrl() : '';
  const root = util.rootDomain(util.hostnameOf(url));
  if (!root) return;
  if (!settings.data.darkPages) {
    settings.data.darkExcept = (settings.data.darkExcept || []).filter((d) => !util.hostInList(root, [d]));
    setSetting('darkPages', true);
    w.toast('🌙 Dark mode is on for websites', { label: 'Settings', run: () => openInternal(w, 'tp://settings/#websites') });
  } else if (darkOnFor(url)) {
    setSetting('darkExcept', [...(settings.data.darkExcept || []), root]);
    w.toast(`☀️ ${root} stays bright`);
  } else {
    setSetting('darkExcept', (settings.data.darkExcept || []).filter((d) => !util.hostInList(util.hostnameOf(url), [d])));
    w.toast(`🌙 Dark mode on for ${root}`);
  }
}

// ---------------------------------------------------------------------------
// Translate (Google Translate's page translation)
// ---------------------------------------------------------------------------

const TRANSLATE_LANGS = [
  ['en', 'English'],
  ['th', 'ไทย (Thai)'],
  ['zh-CN', '中文 (Chinese)'],
  ['ja', '日本語 (Japanese)'],
  ['ko', '한국어 (Korean)'],
  ['es', 'Español (Spanish)'],
  ['fr', 'Français (French)'],
  ['de', 'Deutsch (German)'],
];

function translatePage(w, lang) {
  const t = w && w.activeTab;
  const url = t ? t.displayUrl() : '';
  if (!util.isHttpUrl(url)) return;
  if (lang === 'original') {
    const original = core.untranslateUrl(url);
    if (original) t.load(original);
    return;
  }
  if (!TRANSLATE_LANGS.some(([code]) => code === lang)) return;
  settings.data.translateTo = lang;
  settings.saveSoon();
  t.load(core.translateUrl(url, lang));
}

function translateMenuItems(w) {
  const t = w && w.activeTab;
  const url = t ? t.displayUrl() : '';
  const items = TRANSLATE_LANGS.map(([code, name]) => ({ label: name, enabled: util.isHttpUrl(url), click: () => translatePage(w, code) }));
  if (core.untranslateUrl(url)) items.unshift({ label: 'Show Original', click: () => translatePage(w, 'original') }, { type: 'separator' });
  return items;
}

// ---------------------------------------------------------------------------
// TP AI: the panel in the sidebar page asks, the main process reaches the network and tabs
// ---------------------------------------------------------------------------

const aiRequests = new Map(); // reqId -> AbortController

async function aiRequest(w, reqId, url, method, headers, body, stream) {
  const done = (o) => w.sendUi('ai:done', { reqId, ...o });
  let u;
  try {
    u = new URL(url);
  } catch {
    return done({ status: 0, body: '', error: 'bad address' });
  }
  if (u.protocol !== 'https:' || !AI_HOSTS.has(u.hostname)) return done({ status: 0, body: '', error: 'TP Browser can’t send requests there' });
  const ctrl = new AbortController();
  aiRequests.set(reqId, ctrl);
  try {
    const m = String(method || 'GET').toUpperCase();
    const res = await net.fetch(url, {
      method: m,
      headers: { ...(headers && typeof headers === 'object' ? headers : {}), 'User-Agent': `TPBrowser/${APP_VERSION} (Mac)` },
      body: m === 'GET' || !body ? undefined : String(body),
      signal: ctrl.signal,
    });
    const retryAfter = res.headers.get('retry-after') || '';
    if (stream && res.ok && res.body) {
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      for (;;) {
        const r = await reader.read();
        if (r.done) break;
        const text = dec.decode(r.value, { stream: true });
        if (text) w.sendUi('ai:chunk', { reqId, data: text });
      }
      const rest = dec.decode();
      if (rest) w.sendUi('ai:chunk', { reqId, data: rest });
      done({ status: res.status, body: '', retryAfter });
    } else {
      done({ status: res.status, body: (await res.text()).slice(0, 4 * 1024 * 1024), retryAfter });
    }
  } catch (err) {
    done({ status: 0, body: '', error: ctrl.signal.aborted ? 'aborted' : String((err && err.message) || err) });
  } finally {
    aiRequests.delete(reqId);
  }
}

/** Runs one of TP's own reading scripts in a tab; the answer comes back as JSON text. */
async function evalInTab(tab, script) {
  if (!tab) return { error: 'That tab isn’t open' };
  if (!tab.alive) return { error: 'That tab is asleep' };
  try {
    const value = await tab.wc.executeJavaScriptInIsolatedWorld(WORLD_AI, [{ code: String(script) }]);
    return { result: JSON.stringify(value === undefined ? null : value) };
  } catch (err) {
    return { error: String((err && err.message) || err).slice(0, 300) };
  }
}

/** Loads a page out of sight (search results for TP AI), reads it, and throws it away. */
async function loadAndRead(url, script) {
  if (!util.isHttpUrl(url)) return { error: 'Not a web address' };
  const view = new WebContentsView({ webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false, backgroundThrottling: false } });
  const wc = view.webContents;
  view.setBounds({ x: 0, y: 0, width: 1200, height: 900 });
  wc.setAudioMuted(true);
  wc.setWindowOpenHandler(() => ({ action: 'deny' }));
  const timeout = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  try {
    await Promise.race([wc.loadURL(url, { userAgent: userAgentFor() }).catch(() => {}), timeout(15000)]);
    await timeout(400);
    const value = await Promise.race([
      wc.executeJavaScriptInIsolatedWorld(WORLD_AI, [{ code: String(script) }]),
      timeout(6000).then(() => {
        throw new Error('The page took too long');
      }),
    ]);
    return { result: JSON.stringify(value === undefined ? null : value) };
  } catch (err) {
    return { error: String((err && err.message) || err).slice(0, 300) };
  } finally {
    if (!wc.isDestroyed()) wc.close();
  }
}

/** Files the sidebar page keeps for itself (TP AI chat and choices, reader preferences). */
const UI_STORE_KEYS = new Set(['aichat', 'aicfg', 'uiprefs']);

function uiStoreFile(key) {
  return UI_STORE_KEYS.has(key) ? path.join(app.getPath('userData'), `ui-${key}.json`) : null;
}

function uiStoreLoad(key) {
  const file = uiStoreFile(key);
  if (!file) return null;
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return null;
  }
}

function uiStoreSave(key, value) {
  const file = uiStoreFile(key);
  if (!file) return false;
  try {
    const text = JSON.stringify(value);
    if (text.length > 4 * 1024 * 1024) return false;
    fs.writeFileSync(file + '.tmp', text);
    fs.renameSync(file + '.tmp', file);
    return true;
  } catch {
    return false;
  }
}

// ---------------------------------------------------------------------------
// In-app updates and "Update completed"
// ---------------------------------------------------------------------------

let updates = null;
let updateTimer = null;

function updateStatePayload() {
  const st = updates ? updates.getState() : { state: 'idle' };
  return { ...st, current: APP_VERSION, auto: settings.data.autoUpdate !== false, lastCheck: settings.data.lastUpdateCheck || 0 };
}

function onUpdateState(st) {
  if (st.checkedAt) settings.data.lastUpdateCheck = st.checkedAt;
  broadcast('update', updateStatePayload());
  if (st.state === 'ready' && onUpdateState.toldFor !== st.version) {
    onUpdateState.toldFor = st.version;
    const w = currentWindow();
    if (w) w.toast(`✨ TP Browser ${st.version} is ready`, { label: 'Restart', run: () => restartToUpdate() });
  }
}

async function checkForUpdates(manual) {
  if (!updates) return updateStatePayload();
  await updates.check({ manual, autoDownload: settings.data.autoUpdate !== false });
  settings.saveSoon();
  const st = updates.getState();
  if (manual) {
    const w = currentWindow();
    if (w && st.state === 'uptodate') w.toast(`✅ TP Browser ${APP_VERSION} is up to date`);
    else if (w && st.state === 'failed') w.toast(`Couldn’t check for updates: ${st.message || 'no connection'}`);
    else if (w && st.state === 'rebuild') w.toast(st.message);
  }
  return updateStatePayload();
}

function scheduleUpdateChecks() {
  clearTimeout(updateTimer);
  const due = (settings.data.lastUpdateCheck || 0) + 6 * 3600000 - Date.now();
  updateTimer = setTimeout(async () => {
    await checkForUpdates(false);
    scheduleUpdateChecks();
  }, Math.max(8000, Math.min(due, 6 * 3600000)));
}

function restartToUpdate() {
  saveSession();
  app.relaunch();
  app.quit();
}

/** Notes for every version after `from` (newest first), from src/whats-new.json. */
function notesSince(from) {
  let all = {};
  try {
    all = JSON.parse(fs.readFileSync(path.join(__dirname, 'whats-new.json'), 'utf8'));
  } catch {
    all = {};
  }
  const lo = updater.versionCode(from);
  const hi = updater.versionCode(APP_VERSION);
  const out = [];
  Object.keys(all)
    .filter((v) => (!from || updater.versionCode(v) > lo) && updater.versionCode(v) <= hi)
    .sort((a, b) => updater.versionCode(b) - updater.versionCode(a))
    .forEach((v) => (Array.isArray(all[v]) ? all[v] : []).forEach((n) => out.push(String(n))));
  if (!from) return (all[APP_VERSION] || out).slice(0, 12);
  return out.slice(0, 12);
}

let windowReadyOnce = false;
let pendingWhatsNew = null;

function onWindowReady(w) {
  if (!windowReadyOnce) {
    windowReadyOnce = true;
    if (updates) updates.startedOk();
  }
  if (pendingWhatsNew && w === currentWindow()) {
    const payload = pendingWhatsNew;
    pendingWhatsNew = null;
    setTimeout(() => w.sendUi('whatsnew', payload), 900);
  }
  w.sendUi('update', updateStatePayload());
}

// ---------------------------------------------------------------------------
// Command bar: suggestions & commands
// ---------------------------------------------------------------------------

function historyPool() {
  if (historyPoolCache && historyPoolVersion === historyVersion) return historyPoolCache;
  const map = new Map();
  for (const h of historyStore.data) {
    let e = map.get(h.url);
    if (!e) {
      e = { url: h.url, title: h.title || '', visits: 0, last: h.time };
      map.set(h.url, e);
    }
    e.visits += 1;
    if (!e.title && h.title) e.title = h.title;
  }
  historyPoolCache = [...map.values()];
  historyPoolVersion = historyVersion;
  return historyPoolCache;
}

function frecency(e, now) {
  const days = (now - e.last) / 86400000;
  return e.visits * (days < 1 ? 4 : days < 7 ? 2 : days < 30 ? 1 : 0.3);
}

function tabItem(t) {
  const s = spaceById(t.spaceId);
  const host = util.hostnameOf(t.displayUrl()).replace(/^www\./, '');
  return {
    kind: 'tab',
    tabId: t.id,
    title: t.displayTitle(),
    subtitle: `${s ? s.icon + ' ' + s.name : ''}${host ? ' · ' + host : ''}`,
    icon: t.favicon,
    hint: 'Switch to Tab',
  };
}

function commandList(w) {
  const t = w && w.activeTab;
  const focus = focusState();
  const host = t ? util.hostnameOf(t.displayUrl()).replace(/^www\./, '') : '';
  const siteAllowed = !!host && util.hostInList(host, settings.data.shieldAllow);
  const muted = t ? (t.alive ? t.wc.isAudioMuted() : t.mutedPref) : false;
  const list = [
    { command: 'new-tab', title: 'New Tab', emoji: '➕', hint: '⌘T', keywords: 'open create' },
    { command: 'new-window', title: 'New Window', emoji: '🪟', hint: '⌘N' },
    w && w.split
      ? { command: 'exit-split', title: 'Exit Split View', emoji: '◫', keywords: 'side by side', featured: true }
      : { command: 'split', title: 'Split View', subtitle: 'Show two tabs side by side', emoji: '◫', keywords: 'side by side two pages', featured: true },
    focus
      ? { command: 'focus-end', title: 'End Focus Session', emoji: '🎯', keywords: 'stop timer pomodoro', featured: true }
      : {
          command: 'focus-start',
          title: `Start Focus Session (${settings.data.focusMinutes} min)`,
          subtitle: 'Pauses distracting sites until the timer ends',
          emoji: '🎯',
          keywords: 'pomodoro timer study concentrate block homework',
          featured: true,
        },
    { command: 'ai', title: 'Ask TP AI', subtitle: 'Summarize this page, ask anything, or tell it what to do', emoji: '✦', hint: '⌘J', keywords: 'assistant chat gpt help summarize question', featured: true },
    t && util.isHttpUrl(t.displayUrl())
      ? { command: 'reader', title: 'Reader View', subtitle: 'Just the article, in comfy text', emoji: '📖', hint: '⌥⌘R', keywords: 'read article clean text', featured: true }
      : null,
    t && util.isHttpUrl(t.displayUrl()) ? { command: 'listen', title: 'Listen to This Page', subtitle: 'Reads the page out loud', emoji: '🔊', keywords: 'read aloud speak voice tts audio' } : null,
    t && util.isHttpUrl(t.displayUrl()) ? { command: 'translate:' + (settings.data.translateTo || 'en'), title: `Translate Page to ${(TRANSLATE_LANGS.find(([c]) => c === (settings.data.translateTo || 'en')) || [0, 'English'])[1].replace(/ \(.*\)$/, '')}`, emoji: '🌐', keywords: 'translate language thai english google' } : null,
    t && util.isHttpUrl(t.displayUrl()) && settings.data.translateTo !== 'th' ? { command: 'translate:th', title: 'แปลหน้านี้เป็นภาษาไทย (Translate to Thai)', emoji: '🌐', keywords: 'translate thai ไทย แปล' } : null,
    t && util.isHttpUrl(t.displayUrl()) && settings.data.translateTo && settings.data.translateTo !== 'en' ? { command: 'translate:en', title: 'Translate Page to English', emoji: '🌐', keywords: 'translate english' } : null,
    t && core.untranslateUrl(t.displayUrl()) ? { command: 'translate:original', title: 'Show Original (Untranslated)', emoji: '🌐', keywords: 'translate original' } : null,
    t && util.isHttpUrl(t.displayUrl()) ? { command: 'qr', title: 'Share with QR Code', subtitle: 'Open this page on a phone by scanning', emoji: '🔳', keywords: 'qr code phone share scan' } : null,
    { command: 'dark-toggle', title: settings.data.darkPages ? 'Turn Off Dark Mode for Websites' : 'Dark Mode for Websites', subtitle: settings.data.darkPages ? '' : 'Bright sites turn dark, pictures keep their colours', emoji: '🌙', keywords: 'dark night black theme invert' },
    host && settings.data.darkPages ? { command: 'dark-site', title: darkOnFor(t.displayUrl()) ? `Keep ${host} Bright` : `Dark Mode on ${host}`, emoji: '🌙', keywords: 'dark night site' } : null,
    { command: 'screenshot', title: 'Take Screenshot', subtitle: 'Copies the page and saves it to Downloads', emoji: '📸', hint: '⇧⌘2', keywords: 'capture image picture', featured: true },
    { command: 'pip', title: 'Picture in Picture', subtitle: 'Pop the video out into a floating window', emoji: '🖼️', hint: '⌥⌘P', keywords: 'video float pip youtube', featured: true },
    { command: 'copy-url', title: 'Copy Page Link', emoji: '🔗', hint: '⇧⌘C', keywords: 'url address share' },
    { command: 'sidebar', title: w && w.sidebarCollapsed ? 'Show Sidebar' : 'Hide Sidebar', emoji: '◧', hint: '⌃⌘S', keywords: 'compact toggle' },
    host
      ? { command: 'shield-site', title: siteAllowed ? `Turn TP Shield On for ${host}` : `Turn TP Shield Off for ${host}`, emoji: '🛡️', keywords: 'ad blocker ads trackers' }
      : null,
    { command: 'shield-toggle', title: settings.data.shield ? 'Turn TP Shield Off Everywhere' : 'Turn TP Shield On', emoji: '🛡️', keywords: 'ad blocker ads trackers' },
    { command: 'bookmark', title: t && isBookmarked(t.displayUrl()) ? 'Remove Bookmark' : 'Bookmark This Page', emoji: '⭐', hint: '⌘D', keywords: 'favorite star save' },
    { command: 'history', title: 'History', emoji: '🕘', hint: '⌘Y', keywords: 'visited past' },
    { command: 'settings', title: 'Settings', emoji: '⚙️', hint: '⌘,', keywords: 'preferences options customize theme wallpaper name' },
    { command: 'check-updates', title: 'Check for Updates', subtitle: `TP Browser ${APP_VERSION}`, emoji: '🔄', keywords: 'update upgrade new version' },
    { command: 'reopen', title: 'Reopen Closed Tab', emoji: '↩️', hint: '⇧⌘T', keywords: 'undo restore' },
    { command: 'sleep-others', title: 'Sleep Other Tabs', subtitle: 'Free up memory right now', emoji: '💤', keywords: 'memory ram performance speed' },
    { command: 'mute', title: muted ? 'Unmute Tab' : 'Mute Tab', emoji: '🔇', keywords: 'sound audio' },
    { command: 'import', title: 'Import Bookmarks…', subtitle: 'From Chrome, Brave, Edge, Arc and more', emoji: '📥', keywords: 'chrome brave edge migrate switch' },
    { command: 'default-browser', title: 'Make TP Browser Your Default', emoji: '✅', keywords: 'default main' },
    { command: 'new-space', title: 'New Space', emoji: '✨', keywords: 'workspace' },
    ...spaces().map((s) => ({ command: 'space:' + s.id, title: `Go to ${s.name}`, emoji: s.icon, keywords: 'space switch' })),
    { command: 'theme:light', title: 'Theme: Light', emoji: '☀️', keywords: 'appearance mode' },
    { command: 'theme:dark', title: 'Theme: Dark', emoji: '🌙', keywords: 'appearance mode night' },
    { command: 'theme:system', title: 'Theme: Match System', emoji: '🌗', keywords: 'appearance mode auto' },
    { command: 'downloads', title: 'Open Downloads Folder', emoji: '📂', keywords: 'files' },
    { command: 'clear-data', title: 'Clear Browsing Data…', emoji: '🧹', keywords: 'history cookies cache privacy' },
    { command: 'devtools', title: 'Developer Tools', emoji: '🛠️', hint: '⌥⌘I', keywords: 'inspect console' },
  ].filter(Boolean);
  return list.map((c) => ({ kind: 'command', ...c }));
}

function matchCommands(cmds, q) {
  const words = q.toLowerCase().split(/\s+/).filter(Boolean);
  return cmds
    .map((c) => {
      const title = c.title.toLowerCase();
      const hay = `${title} ${c.keywords || ''}`.toLowerCase();
      let score = 0;
      for (const word of words) {
        if (title.startsWith(word)) score += 3;
        else if (title.split(/[^a-z0-9]+/).some((x) => x.startsWith(word))) score += 2;
        else if (hay.includes(word)) score += 1;
        else return null;
      }
      return { c, score };
    })
    .filter(Boolean)
    .sort((a, b) => b.score - a.score)
    .map((x) => x.c);
}

function computeSuggestions(w, text, mode) {
  const q = String(text || '').trim().slice(0, 500);
  const ql = q.toLowerCase();
  const items = [];
  const seen = new Set();
  const add = (it) => {
    const key =
      it.kind === 'command' ? 'c:' + it.command : it.kind === 'tab' ? 't:' + it.tabId : 'u:' + String(it.url || '').replace(/\/$/, '');
    if (seen.has(key)) return false;
    seen.add(key);
    items.push(it);
    return true;
  };
  const cmds = mode === 'home' ? [] : commandList(w);
  const now = Date.now();

  if (!q) {
    if (w) {
      for (const id of w.mru) {
        const t = w.tabs.find((x) => x.id === id);
        if (t && t !== w.activeTab) add(tabItem(t));
        if (items.length >= 5) break;
      }
    }
    for (const c of cmds) if (c.featured) add(c);
    return items.slice(0, 10);
  }

  const engine = SEARCH_ENGINES[engineKey()];
  const isUrl = util.looksLikeUrl(q);
  const target = util.resolveInput(q, engineKey());
  const pool = historyPool();

  const answer = isUrl ? null : core.calc(q);
  if (answer !== null) {
    add({ kind: 'calc', title: '= ' + core.fmtNumber(answer), subtitle: `${q} · press Enter to copy`, value: String(answer), emoji: '🧮', hint: 'Copy' });
  }
  const askAi = !isUrl && answer === null && q.length >= 6 && (/\s\S/.test(q) || /\?$/.test(q));

  // Autocomplete: the site you most likely mean ("you" -> youtube.com).
  if (q.length >= 2 && !/\s/.test(q) && !/^[a-z]+:/i.test(q)) {
    let best = null;
    const consider = (url, title, base, kind) => {
      const host = util.hostnameOf(url).replace(/^www\./, '');
      let pathname = '';
      try {
        pathname = new URL(url).pathname;
      } catch {
        return;
      }
      if (!host.startsWith(ql) && !(host + pathname).startsWith(ql)) return;
      const isRoot = pathname === '/' || pathname === '';
      const score = base + (isRoot ? 25 : 0) - url.length * 0.02;
      if (!best || score > best.score) best = { url, title, score, kind };
    };
    for (const b of bookmarks.data) consider(b.url, b.title, 30, 'bookmark');
    for (const e of pool) consider(e.url, e.title, frecency(e, now), 'history');
    if (best) {
      add({ kind: best.kind, title: best.title || prettyUrl(best.url), subtitle: prettyUrl(best.url), url: best.url, icon: faviconFor(best.url), hint: 'Open' });
    }
  }

  add(
    isUrl
      ? { kind: 'url', title: prettyUrl(target), subtitle: 'Open website', url: target, hint: 'Go' }
      : { kind: 'search', title: q, subtitle: `Search ${engine.name}`, url: target, hint: 'Search' }
  );
  if (askAi && mode !== 'home') add({ kind: 'ai', title: 'Ask TP AI', subtitle: q, text: q, emoji: '✦', hint: 'Ask' });

  if (q.length >= 2) for (const c of matchCommands(cmds, q).slice(0, 3)) add(c);

  if (w) {
    let n = 0;
    for (const t of w.tabs) {
      if (n >= 4) break;
      const u = t.displayUrl().toLowerCase();
      if (t.displayTitle().toLowerCase().includes(ql) || u.includes(ql)) if (add(tabItem(t))) n += 1;
    }
  }

  let nb = 0;
  for (const b of bookmarks.data) {
    if (nb >= 3) break;
    if ((b.title || '').toLowerCase().includes(ql) || b.url.toLowerCase().includes(ql)) {
      if (add({ kind: 'bookmark', title: b.title || prettyUrl(b.url), subtitle: prettyUrl(b.url), url: b.url, icon: b.favicon || faviconFor(b.url) })) nb += 1;
    }
  }

  const hist = pool
    .filter((e) => (e.title || '').toLowerCase().includes(ql) || e.url.toLowerCase().includes(ql))
    .sort((a, b) => frecency(b, now) - frecency(a, now))
    .slice(0, 15);
  let nh = 0;
  for (const e of hist) {
    if (nh >= 5) break;
    if (add({ kind: 'history', title: e.title || prettyUrl(e.url), subtitle: prettyUrl(e.url), url: e.url, icon: faviconFor(e.url) })) nh += 1;
  }

  return items.slice(0, 12);
}

async function remoteSuggest(text) {
  const q = String(text || '').trim();
  if (!settings.data.suggestions || !q || q.length > 200 || util.looksLikeUrl(q)) return [];
  const key = engineKey();
  const engine = SEARCH_ENGINES[key];
  if (!engine.suggest) return [];
  try {
    const res = await Promise.race([
      net.fetch(engine.suggest + encodeURIComponent(q) + (key === 'google' ? '&ie=utf-8&oe=utf-8' : '')),
      new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 1500)),
    ]);
    if (!res.ok) return [];
    const data = JSON.parse(await res.text());
    const list = Array.isArray(data) && Array.isArray(data[1]) ? data[1] : [];
    return list
      .filter((s) => typeof s === 'string' && s && s.toLowerCase() !== q.toLowerCase())
      .slice(0, 4)
      .map((s) => ({ kind: 'suggest', title: s, subtitle: `Search ${engine.name}`, url: util.searchUrl(s, key) }));
  } catch {
    return [];
  }
}

const OPENABLE_TP = /^tp:\/\/(newtab|history|settings|welcome)\//i;

function executeItem(w, item, { newTab = false } = {}, sourceTab = null) {
  if (!item || typeof item !== 'object') return;
  if (item.kind === 'command') {
    runCommand(w, String(item.command || ''));
    return;
  }
  if (item.kind === 'calc') {
    clipboard.writeText(String(item.value || ''));
    if (w) w.toast(`🧮 Copied ${String(item.value || '')}`);
    return;
  }
  if (item.kind === 'ai') {
    const target = w || currentWindow();
    if (target) target.sendUi('command', { name: 'ai-ask', text: String(item.text || '').slice(0, 2000) });
    return;
  }
  if (item.kind === 'tab') {
    const t = findTab(item.tabId);
    if (t) {
      t.owner.activate(t);
      t.owner.win.focus();
    }
    return;
  }
  const url = typeof item.url === 'string' ? item.url : '';
  if (!/^(https?|file):/i.test(url) && !OPENABLE_TP.test(url) && url !== 'about:blank') return;
  if (!w) {
    new TPWindow({ urls: [url] });
    return;
  }
  const tab = sourceTab || w.activeTab;
  if (newTab || !tab) w.addTab(url);
  else {
    tab.load(url);
    if (tab.alive) tab.wc.focus();
  }
}

function runCommand(w, id) {
  const t = w && w.activeTab;
  if (id.startsWith('space:')) {
    if (w) w.switchSpace(id.slice(6));
    return;
  }
  if (id.startsWith('theme:')) {
    setSetting('appearance', id.slice(6));
    return;
  }
  if (id.startsWith('translate:')) {
    translatePage(w, id.slice(10));
    return;
  }
  switch (id) {
    case 'new-tab':
      newTab();
      break;
    case 'new-window':
      new TPWindow({ spaceId: w ? w.activeSpaceId : null });
      break;
    case 'split':
      if (w) w.splitWith(null);
      break;
    case 'exit-split':
      if (w) w.exitSplit();
      break;
    case 'focus-start':
      startFocus(settings.data.focusMinutes);
      break;
    case 'focus-end':
      endFocus({ completed: false });
      break;
    case 'screenshot':
      takeScreenshot(w);
      break;
    case 'ai':
      if (w) w.sendUi('command', { name: 'ai-open' });
      break;
    case 'reader':
      if (w) w.sendUi('command', { name: 'reader' });
      break;
    case 'listen':
      if (w) w.sendUi('command', { name: 'reader', listen: true });
      break;
    case 'qr':
      if (w) w.sendUi('command', { name: 'qr' });
      break;
    case 'dark-toggle':
      setSetting('darkPages', !settings.data.darkPages);
      if (w) w.toast(settings.data.darkPages ? '🌙 Dark mode is on for websites' : 'Dark mode for websites is off');
      break;
    case 'dark-site':
      toggleSiteDark(w);
      break;
    case 'check-updates':
      checkForUpdates(true);
      break;
    case 'pip':
      pictureInPicture(w);
      break;
    case 'copy-url':
      copyUrl(w);
      break;
    case 'sidebar':
      if (w) w.toggleSidebar();
      break;
    case 'shield-site':
      if (w) toggleSiteShield(w);
      break;
    case 'shield-toggle':
      setSetting('shield', !settings.data.shield);
      if (w) w.toast(settings.data.shield ? '🛡️ TP Shield is on' : 'TP Shield is off');
      break;
    case 'bookmark':
      toggleBookmark(w);
      break;
    case 'history':
      openInternal(w, 'tp://history/');
      break;
    case 'settings':
      openInternal(w, 'tp://settings/');
      break;
    case 'import':
      openInternal(w, 'tp://settings/#import');
      break;
    case 'reopen':
      if (w) w.reopenClosedTab();
      break;
    case 'sleep-others': {
      if (!w) break;
      let n = 0;
      for (const x of w.tabs) {
        if (x.alive && x !== w.activeTab && !w.visibleTabs().includes(x) && !x.audible) {
          x.sleep();
          n += 1;
        }
      }
      w.toast(n ? `💤 Put ${n} tab${n === 1 ? '' : 's'} to sleep` : 'No other tabs to put to sleep');
      break;
    }
    case 'mute':
      if (w && t) toggleMute(w, t);
      break;
    case 'default-browser':
      makeDefaultBrowser();
      break;
    case 'new-space':
      newSpace(w);
      break;
    case 'downloads':
      shell.openPath(app.getPath('downloads'));
      break;
    case 'clear-data':
      clearBrowsingData(w);
      break;
    case 'devtools':
      if (t && t.alive) t.wc.toggleDevTools();
      break;
    default:
      break;
  }
}

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------

const bool = (v) => !!v;
const siteList = (v) =>
  Array.isArray(v) ? [...new Set(v.map(util.normalizeSite).filter(Boolean))].slice(0, 200) : undefined;

const SETTERS = {
  name: (v) => (typeof v === 'string' ? v.trim().slice(0, 40) : undefined),
  onboarded: bool,
  searchEngine: (v) => (SEARCH_ENGINES[v] ? v : undefined),
  suggestions: bool,
  appearance: (v) => (['system', 'light', 'dark'].includes(v) ? v : undefined),
  restoreTabs: bool,
  sidebarCollapsed: bool,
  sidebarWidth: (v) => {
    const n = Math.round(Number(v));
    return n >= 200 && n <= 420 ? n : undefined;
  },
  shield: bool,
  ytSkip: bool,
  shieldAllow: siteList,
  sleepAfter: (v) => ([0, 15, 30, 60, 120, 240].includes(Number(v)) ? Number(v) : undefined),
  focusMinutes: (v) => {
    const n = Math.round(Number(v));
    return n >= 5 && n <= 180 ? n : undefined;
  },
  focusSites: siteList,
  city: (v) =>
    v && typeof v.name === 'string' && Number.isFinite(Number(v.lat)) && Number.isFinite(Number(v.lon))
      ? {
          name: v.name.slice(0, 80),
          region: String(v.region || '').slice(0, 80),
          country: String(v.country || '').slice(0, 80),
          lat: Number(v.lat),
          lon: Number(v.lon),
        }
      : undefined,
  tempUnit: (v) => (['C', 'F'].includes(v) ? v : undefined),
  wallpaper: (v) => (WALLPAPERS.includes(v) && (v !== 'custom' || settings.data.wallpaperFile) ? v : undefined),
  note: (v) => (typeof v === 'string' ? v.slice(0, 5000) : undefined),
  darkPages: bool,
  darkExcept: siteList,
  autoUpdate: bool,
  speechRate: (v) => {
    const n = Number(v);
    return n >= 0.5 && n <= 2.5 ? Math.round(n * 100) / 100 : undefined;
  },
};

function setSetting(key, value) {
  const fn = SETTERS[key];
  if (!fn) return false;
  const v = fn(value);
  if (v === undefined) return false;
  settings.data[key] = v;
  if (key === 'note') {
    settings.saveSoon(600);
    return true;
  }
  settings.save();
  if (key === 'appearance') nativeTheme.themeSource = v;
  if (key === 'darkPages' || key === 'darkExcept') applyDarkAll();
  if (key === 'autoUpdate' && v) scheduleUpdateChecks();
  broadcast('settings', publicSettings());
  for (const w of windows.values()) w.pushState();
  buildAppMenuSoon();
  return true;
}

async function chooseWallpaper(w) {
  const opts = {
    title: 'Choose a home page wallpaper',
    properties: ['openFile'],
    filters: [{ name: 'Images', extensions: ['jpg', 'jpeg', 'png', 'webp', 'gif'] }],
  };
  const res = w ? await dialog.showOpenDialog(w.win, opts) : await dialog.showOpenDialog(opts);
  if (res.canceled || !res.filePaths[0]) return false;
  const src = res.filePaths[0];
  const ext = path.extname(src).toLowerCase();
  const name = 'wallpaper' + ext;
  const dir = app.getPath('userData');
  if (settings.data.wallpaperFile && settings.data.wallpaperFile !== name) {
    fs.promises.unlink(path.join(dir, settings.data.wallpaperFile)).catch(() => {});
  }
  await fs.promises.copyFile(src, path.join(dir, name));
  settings.data.wallpaperFile = name;
  settings.data.wallpaper = 'custom';
  settings.data.wallpaperVersion = Date.now();
  settings.save();
  broadcast('settings', publicSettings());
  return true;
}

async function clearBrowsingData(w) {
  const opts = {
    type: 'warning',
    buttons: ['Clear History', 'Clear Everything', 'Cancel'],
    defaultId: 0,
    cancelId: 2,
    message: 'Clear browsing data?',
    detail: '“Clear Everything” also signs you out of websites and removes cookies, cached files and site data.',
  };
  const { response } = w ? await dialog.showMessageBox(w.win, opts) : await dialog.showMessageBox(opts);
  if (response === 2) return false;
  historyStore.data = [];
  historyVersion += 1;
  historyStore.save();
  if (response === 1) {
    const ses = session.defaultSession;
    await ses.clearCache();
    await ses.clearStorageData();
    permissionDecisions.clear();
  }
  if (w) w.toast(response === 1 ? '🧹 Browsing data cleared' : '🧹 History cleared');
  return true;
}

function isDefaultBrowser() {
  try {
    return app.isDefaultProtocolClient('https');
  } catch {
    return false;
  }
}

function makeDefaultBrowser() {
  app.setAsDefaultProtocolClient('http');
  app.setAsDefaultProtocolClient('https');
  setTimeout(buildAppMenuSoon, 3000);
}

function newTab() {
  const w = currentWindow();
  if (w) {
    w.addTab(NEW_TAB_URL);
    if (w.win.isMinimized()) w.win.restore();
    w.win.focus();
  } else new TPWindow();
}

// ---------------------------------------------------------------------------
// tp:// pages
// ---------------------------------------------------------------------------

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.json': 'application/json',
};

function readFileCb(file) {
  // fs.readFile (callback form) reads straight out of a packaged app.asar too.
  return new Promise((resolve, reject) => fs.readFile(file, (err, data) => (err ? reject(err) : resolve(data))));
}

function setupTpProtocol(ses) {
  ses.protocol.handle('tp', async (request) => {
    const url = new URL(request.url);
    try {
      if (url.hostname === 'newtab' && url.pathname === '/wallpaper') {
        const name = settings.data.wallpaperFile;
        if (!name || !/^wallpaper\.[a-z]+$/.test(name)) return new Response('Not found', { status: 404 });
        const body = await readFileCb(path.join(app.getPath('userData'), name));
        return new Response(body, { headers: { 'content-type': MIME[path.extname(name)] || 'image/jpeg' } });
      }
      let rel = decodeURIComponent(url.pathname).replace(/^\/+/, '');
      if (!rel) rel = `${url.hostname}.html`;
      const file = path.normalize(path.join(PAGES_DIR, rel));
      if (!file.startsWith(PAGES_DIR + path.sep)) return new Response('Not found', { status: 404 });
      const body = await readFileCb(file);
      return new Response(body, { headers: { 'content-type': MIME[path.extname(file)] || 'application/octet-stream' } });
    } catch {
      return new Response('Not found', { status: 404 });
    }
  });
}

// Internal pages (tp://...) get a small API. Web pages never do.
function internalOnly(handler) {
  return (event, ...args) => {
    const url = event.senderFrame ? event.senderFrame.url : '';
    if (!/^tp:\/\//i.test(url)) throw new Error('Not allowed');
    smoke.internalCalls += 1;
    return handler(event, ...args);
  };
}

function searchHistory(query) {
  const q = String(query || '').trim().toLowerCase();
  const list = q
    ? historyStore.data.filter((h) => h.url.toLowerCase().includes(q) || (h.title || '').toLowerCase().includes(q))
    : historyStore.data;
  return list.slice(0, 600);
}

function homeData(event) {
  const tab = tabsByWcId.get(event.sender.id);
  const s = spaceById(tab ? tab.spaceId : null) || spaces()[0];
  const favs = favoritesPayload();
  return {
    name: settings.data.name,
    space: { ...s, colors: SPACE_COLORS[s.color] || SPACE_COLORS.violet },
    favorites: favs,
    settings: publicSettings(),
    stats: statsSummary(),
    focus: focusState(),
    note: settings.data.note,
    shieldCount: shield.DOMAINS.length,
  };
}

function setupIpc() {
  // --- From the sidebar UI ---------------------------------------------------
  const fromUi = (handler) => (event, ...args) => {
    const w = [...windows.values()].find((x) => !x.ui.isDestroyed() && x.ui.id === event.sender.id);
    if (w) return handler(w, ...args);
    return undefined;
  };
  const tabIn = (w, id) => w.tabs.find((t) => t.id === id);

  ipcMain.on('ui:layout', fromUi((w, rect) => {
    if (!rect) return;
    const r = {
      x: Math.round(Number(rect.x)),
      y: Math.round(Number(rect.y)),
      width: Math.round(Number(rect.width)),
      height: Math.round(Number(rect.height)),
    };
    if (![r.x, r.y, r.width, r.height].every(Number.isFinite) || r.width < 0 || r.height < 0) return;
    w.pageRect = r;
    w.layout();
  }));
  ipcMain.on('ui:sidebar-width', fromUi((_w, width) => setSetting('sidebarWidth', width)));
  ipcMain.on('ui:toggle-sidebar', fromUi((w) => w.toggleSidebar()));
  ipcMain.on('ui:menu', fromUi((w, pos = {}) => {
    Menu.buildFromTemplate(appMenuItems(w)).popup({ window: w.win, x: Math.round(pos.x || 0), y: Math.round(pos.y || 0) });
  }));
  ipcMain.on('ui:overlay', fromUi((w, mode) => w.openOverlay(mode === 'commands' ? 'commands' : 'current')));
  ipcMain.on('ui:toast-action', fromUi((_w, id) => {
    const fn = toastActions.get(id);
    if (fn) fn();
  }));

  ipcMain.on('tab:new', fromUi((w, url) => {
    const target = typeof url === 'string' && url ? util.resolveInput(url, engineKey()) : null;
    w.addTab(target || NEW_TAB_URL);
  }));
  ipcMain.on('tab:close', fromUi((w, id) => {
    const t = tabIn(w, id);
    if (t) w.closeTab(t);
  }));
  ipcMain.on('tab:activate', fromUi((w, id) => w.activate(tabIn(w, id))));
  ipcMain.on('tab:menu', fromUi((w, id) => {
    const t = tabIn(w, id);
    if (t) showTabMenu(w, t);
  }));
  ipcMain.on('tab:mute', fromUi((w, id) => {
    const t = tabIn(w, id);
    if (t) toggleMute(w, t);
  }));
  ipcMain.on('tab:move', fromUi((w, id, targetId, after) => {
    const t = tabIn(w, id);
    if (t) w.moveTab(t, tabIn(w, targetId), !!after);
  }));
  ipcMain.on('tab:to-space', fromUi((w, id, spaceId) => {
    const t = tabIn(w, id);
    if (t) w.moveTabToSpace(t, spaceId);
  }));
  ipcMain.on('split:exit', fromUi((w) => w.exitSplit()));

  ipcMain.on('nav:back', fromUi((w) => w.activeTab && w.activeTab.alive && navOf(w.activeTab.wc).goBack()));
  ipcMain.on('nav:forward', fromUi((w) => w.activeTab && w.activeTab.alive && navOf(w.activeTab.wc).goForward()));
  ipcMain.on('nav:reload', fromUi((w) => reload(w, false)));
  ipcMain.on('nav:stop', fromUi((w) => w.activeTab && w.activeTab.alive && w.activeTab.wc.stop()));
  ipcMain.on('page:focus', fromUi((w) => w.activeTab && w.activeTab.alive && w.activeTab.wc.focus()));
  ipcMain.on('zoom:reset', fromUi((w) => zoom(w, 0)));
  ipcMain.on('url:copy', fromUi((w) => copyUrl(w)));
  ipcMain.on('shield:menu', fromUi((w) => showShieldMenu(w)));
  ipcMain.on('focus:menu', fromUi((w) => showFocusMenu(w)));
  ipcMain.on('bookmark:toggle', fromUi((w) => toggleBookmark(w)));

  ipcMain.on('space:switch', fromUi((w, id) => w.switchSpace(id)));
  ipcMain.on('space:add', fromUi((w) => newSpace(w)));
  ipcMain.on('space:menu', fromUi((w, id) => showSpaceMenu(w, id)));
  ipcMain.on('space:rename', fromUi((_w, id, name) => updateSpace(id, { name })));

  ipcMain.on('fav:open', fromUi((w, id, opts = {}) => openFavorite(w, id, { newTab: !!opts.newTab })));
  ipcMain.on('fav:menu', fromUi((w, id) => showFavoriteMenu(w, id)));

  ipcMain.on('find:query', fromUi((w, q = {}) => {
    const tab = w.activeTab;
    if (!tab || !tab.alive) return;
    const text = String(q.text || '');
    if (!text) {
      tab.wc.stopFindInPage('clearSelection');
      w.sendUi('find:result', { active: 0, total: 0 });
      return;
    }
    tab.wc.findInPage(text, { forward: q.forward !== false, findNext: !!q.newSearch });
  }));
  ipcMain.on('find:stop', fromUi((w) => {
    const tab = w.activeTab;
    if (tab && tab.alive) {
      tab.wc.stopFindInPage('keepSelection');
      tab.wc.focus();
    }
  }));

  ipcMain.on('download:action', fromUi((_w, id, action) => downloadAction(id, action)));
  ipcMain.on('downloads:clear', fromUi((w) => {
    for (const d of downloads.values()) if (d.winId === w.id && d.state !== 'progressing') d.hidden = true;
    pushDownloads(w.id);
  }));
  ipcMain.on('downloads:folder', fromUi(() => shell.openPath(app.getPath('downloads'))));

  // --- New in 2.2: TP AI, reader view, sheets, dark mode, translate, updates ----------
  const tabById = (w, id) => w.tabs.find((t) => String(t.id) === String(id)) || null;
  const handleUi = (channel, fn) => ipcMain.handle(channel, fromUi(fn));

  /** The sidebar page covers the page area (reader view and sheets). Returns a picture of the page if asked. */
  handleUi('ui:cover', async (w, on, opts = {}) => {
    if (on) {
      let shot = null;
      const t = w.activeTab;
      if (opts && opts.snapshot && t && t.alive && w.visibleTabs().includes(t)) {
        try {
          const img = await t.wc.capturePage();
          if (!img.isEmpty()) shot = 'data:image/jpeg;base64,' + img.toJPEG(82).toString('base64');
        } catch {
          shot = null;
        }
      }
      // captureOnly: the sidebar page paints the snapshot first, then asks again to cover (no flash).
      if (opts && opts.captureOnly) return shot;
      w.covered = true;
      w.syncViews();
      return shot;
    }
    w.covered = false;
    w.syncViews();
    if (!(opts && opts.focus === false) && w.activeTab && w.activeTab.alive && !w.overlayOpen) w.activeTab.wc.focus();
    return null;
  });
  handleUi('ui:store-load', (_w, key) => uiStoreLoad(String(key)));
  ipcMain.on('ui:store-save', fromUi((_w, key, value) => uiStoreSave(String(key), value)));
  ipcMain.on('ui:copy', fromUi((_w, text) => clipboard.writeText(String(text || '').slice(0, 100000))));
  ipcMain.on('ui:open-internal', fromUi((w, url) => {
    if (OPENABLE_TP.test(String(url || ''))) openInternal(w, String(url));
  }));
  ipcMain.on('ui:screenshot', fromUi((w) => takeScreenshot(w)));
  ipcMain.on('ui:pip', fromUi((w) => pictureInPicture(w)));
  ipcMain.on('ui:translate', fromUi((w, lang) => translatePage(w, String(lang || ''))));
  ipcMain.on('ui:dark-site', fromUi((w) => toggleSiteDark(w)));
  ipcMain.on('ui:set', fromUi((_w, key, value) => setSetting(String(key), value)));
  ipcMain.on('ui:share', fromUi((w) => {
    const t = w.activeTab;
    const url = t ? t.displayUrl() : '';
    if (!util.isHttpUrl(url)) return;
    // macOS share sheet (AirDrop, Messages, Notes…)
    const { ShareMenu } = require('electron');
    if (IS_MAC && ShareMenu) new ShareMenu({ urls: [url] }).popup({ window: w.win });
  }));
  // Voice typing on the Mac is the system's own Dictation (Fn Fn, or the 🎤 key).
  ipcMain.on('ui:dictate', fromUi((w) => {
    w.ui.focus();
    if (IS_MAC && typeof Menu.sendActionToFirstResponder === 'function') {
      setTimeout(() => Menu.sendActionToFirstResponder('startDictation:'), 80);
    }
  }));
  ipcMain.on('ui:update-check', fromUi(() => checkForUpdates(true)));
  ipcMain.on('ui:update-restart', fromUi(() => restartToUpdate()));

  ipcMain.on('ai:request', fromUi((w, reqId, url, method, headers, body, stream) => {
    aiRequest(w, String(reqId), String(url || ''), method, headers, body, !!stream);
  }));
  ipcMain.on('ai:abort', fromUi((_w, reqId) => {
    const c = aiRequests.get(String(reqId));
    if (c) c.abort();
  }));
  handleUi('ai:eval', (w, tabId, script) => evalInTab(tabById(w, tabId), script));
  handleUi('ai:load-and-read', (_w, url, script) => loadAndRead(String(url || ''), script));
  handleUi('ai:open', (w, url, opts = {}) => {
    const target = util.resolveInput(String(url || ''), engineKey());
    if (!target || !util.isHttpUrl(target)) return null;
    const tab = w.addTab(target, { activate: !(opts && opts.background) });
    return tab.state();
  });
  handleUi('ai:navigate', (w, url) => {
    const target = util.resolveInput(String(url || ''), engineKey());
    const t = w.activeTab;
    if (!target || !t) return null;
    t.load(target);
    return t.state();
  });
  ipcMain.on('ai:wake', fromUi((w, tabId) => {
    const t = tabById(w, tabId);
    if (t) t.wake();
  }));
  ipcMain.on('ai:activate', fromUi((w, tabId) => {
    const t = tabById(w, tabId);
    if (t) w.activate(t);
  }));
  ipcMain.on('ai:close', fromUi((w, tabId) => {
    const t = tabById(w, tabId);
    if (t) w.closeTab(t);
  }));
  ipcMain.on('ai:nav', fromUi((w, tabId, action) => {
    const t = tabById(w, tabId);
    if (!t || !t.alive) return;
    if (action === 'back') navOf(t.wc).goBack();
    else if (action === 'forward') navOf(t.wc).goForward();
    else if (action === 'reload') t.wc.reload();
  }));
  ipcMain.on('ai:find', fromUi((w, tabId, text) => {
    const t = tabById(w, tabId);
    if (t && t.alive && text) t.wc.findInPage(String(text).slice(0, 200));
  }));
  ipcMain.on('ai:focus', fromUi((_w, minutes) => startFocus(minutes)));
  ipcMain.on('ai:favorite', fromUi((w) => {
    const t = w.activeTab;
    if (t && !isBookmarked(t.displayUrl())) toggleBookmark(w);
  }));

  // Pages ask (synchronously, before they draw) whether to start dark.
  ipcMain.on('tab:dark-code', (e) => {
    let url = '';
    try {
      url = e.senderFrame ? e.senderFrame.url : e.sender.getURL();
    } catch {
      url = '';
    }
    e.returnValue = settings && DARK_JS && darkOnFor(url) ? darkCode() : '';
  });

  // --- From the command bar overlay ---------------------------------------
  const fromOverlay = (handler) => (event, ...args) => {
    const w = [...windows.values()].find((x) => x.overlay && !x.overlay.webContents.isDestroyed() && x.overlay.webContents.id === event.sender.id);
    if (w) return handler(w, ...args);
    return undefined;
  };
  ipcMain.handle('overlay:suggest', fromOverlay((w, text, mode) => computeSuggestions(w, text, mode)));
  ipcMain.handle('overlay:remote', fromOverlay((_w, text) => remoteSuggest(text)));
  ipcMain.on('overlay:choose', fromOverlay((w, item, opts = {}) => {
    w.closeOverlay({ refocus: false });
    executeItem(w, item, { newTab: !!opts.newTab });
    const t = w.activeTab;
    if (t && t.alive && !(item && item.kind === 'command')) t.wc.focus();
  }));
  ipcMain.on('overlay:close', fromOverlay((w) => w.closeOverlay()));

  // --- From tp:// pages -------------------------------------------------------
  const tabOf = (event) => tabsByWcId.get(event.sender.id) || null;
  const winOf = (event) => {
    const t = tabOf(event);
    return t ? t.owner : currentWindow();
  };
  const handle = (channel, fn) => ipcMain.handle(channel, internalOnly(fn));

  handle('internal:home', (e) => homeData(e));
  handle('internal:weather', async () => {
    try {
      return await weather.current((u) => net.fetch(u), settings.data.city, settings.data.tempUnit);
    } catch {
      return null;
    }
  });
  handle('internal:searchCity', async (_e, q) => {
    try {
      return await weather.searchCity((u) => net.fetch(u), q);
    } catch {
      return [];
    }
  });
  handle('internal:suggest', (e, text) => computeSuggestions(winOf(e), text, 'home'));
  handle('internal:remoteSuggest', (_e, text) => remoteSuggest(text));
  handle('internal:open', (e, item, opts = {}) => {
    executeItem(winOf(e), item, { newTab: !!opts.newTab }, opts.newTab ? null : tabOf(e));
    return true;
  });
  handle('internal:getSettings', () => ({
    ...publicSettings(),
    version: APP_VERSION,
    update: updateStatePayload(),
    ai: { control: (uiStoreLoad('aicfg') || {}).control !== false },
    chromium: process.versions.chrome,
    electron: process.versions.electron,
    isDefault: isDefaultBrowser(),
    stats: statsSummary(),
    shieldCount: shield.DOMAINS.length,
  }));
  handle('internal:set', (_e, key, value) => {
    setSetting(key, value);
    return publicSettings();
  });
  handle('internal:chooseWallpaper', async (e) => {
    await chooseWallpaper(winOf(e));
    return publicSettings();
  });
  handle('internal:detectBrowsers', () => importer.detect(app.getPath('appData')));
  handle('internal:import', (_e, key) => importBookmarks(key));
  handle('internal:makeDefault', () => {
    makeDefaultBrowser();
    return true;
  });
  handle('internal:isDefault', () => isDefaultBrowser());
  handle('internal:clearData', (e) => clearBrowsingData(winOf(e)));
  handle('internal:updateSpace', (_e, id, patch) => {
    updateSpace(id, patch || {});
    return publicSettings();
  });
  handle('internal:addSpace', () => {
    newSpace(null);
    return publicSettings();
  });
  handle('internal:deleteSpace', async (e, id) => {
    await deleteSpace(id, winOf(e));
    return publicSettings();
  });
  handle('internal:getHistory', (_e, q) => searchHistory(q));
  handle('internal:deleteHistory', (_e, id) => {
    const i = historyStore.data.findIndex((h) => h.id === id);
    if (i !== -1) historyStore.data.splice(i, 1);
    historyVersion += 1;
    historyStore.saveSoon(200);
    return true;
  });
  handle('internal:clearHistory', () => {
    historyStore.data = [];
    historyVersion += 1;
    historyStore.save();
    return true;
  });
  handle('internal:getBookmarks', () => bookmarks.data.slice(0, 5000));
  handle('internal:removeBookmark', (_e, id) => {
    removeBookmark(id);
    return favoritesPayload();
  });
  handle('internal:setPinned', (_e, id, pinned) => {
    setPinned(id, pinned);
    return favoritesPayload();
  });
  handle('internal:startFocus', (_e, minutes) => {
    startFocus(minutes);
    return focusState();
  });
  handle('internal:endFocus', () => {
    endFocus({ completed: false });
    return null;
  });
  handle('internal:focusStatus', () => ({ focus: focusState(), stats: statsSummary() }));
  handle('internal:checkUpdates', () => checkForUpdates(true));
  handle('internal:updateState', () => updateStatePayload());
  handle('internal:restartToUpdate', () => {
    restartToUpdate();
    return true;
  });
  handle('internal:setAiControl', (_e, on) => {
    const cfg = uiStoreLoad('aicfg') || {};
    cfg.control = !!on;
    uiStoreSave('aicfg', cfg);
    broadcast('ai:config', { control: !!on });
    return true;
  });
  handle('internal:clearAiChat', () => {
    uiStoreSave('aichat', []);
    broadcast('ai:clear', true);
    return true;
  });
  handle('internal:finishOnboarding', (e) => {
    setSetting('onboarded', true);
    const t = tabOf(e);
    if (t) t.load(NEW_TAB_URL);
    return true;
  });
}

// ---------------------------------------------------------------------------
// Actions shared by the app menu and the sidebar
// ---------------------------------------------------------------------------

function reload(w, ignoreCache) {
  const tab = w.activeTab;
  if (!tab) return;
  if (!tab.alive) return tab.wake();
  const raw = tab.rawUrl();
  if (/^tp:\/\/(error|focus)/.test(raw)) {
    const original = tab.displayUrl();
    if (original) return tab.load(original);
  }
  if (ignoreCache) tab.wc.reloadIgnoringCache();
  else tab.wc.reload();
}

function zoom(w, dir) {
  const tab = w.activeTab;
  if (!tab || !tab.alive) return;
  if (dir === 0) tab.wc.setZoomLevel(0);
  else tab.wc.setZoomLevel(Math.max(-5, Math.min(5, tab.wc.getZoomLevel() + dir * 0.5)));
  w.pushState();
}

function openHistory(w) {
  openInternal(w, 'tp://history/');
}

/** Items in the "⋯" menu at the bottom of the sidebar. */
function appMenuItems(w) {
  const s = publicSettings();
  return [
    { label: 'New Tab', accelerator: 'CmdOrCtrl+T', click: () => newTab() },
    { label: 'New Window', accelerator: 'CmdOrCtrl+N', click: () => new TPWindow({ spaceId: w.activeSpaceId }) },
    { label: 'Command Bar…', accelerator: 'CmdOrCtrl+K', click: () => w.openOverlay('commands') },
    { label: 'TP AI', accelerator: 'CmdOrCtrl+J', click: () => w.sendUi('command', { name: 'ai-toggle' }) },
    { type: 'separator' },
    { label: 'History', accelerator: 'CmdOrCtrl+Y', click: () => openHistory(w) },
    { label: 'Downloads Folder', click: () => shell.openPath(app.getPath('downloads')) },
    { label: w.sidebarCollapsed ? 'Show Sidebar' : 'Hide Sidebar', accelerator: 'Ctrl+Cmd+S', click: () => w.toggleSidebar() },
    { type: 'separator' },
    {
      label: 'Search Engine',
      submenu: s.searchEngines.map((e) => ({
        label: e.name,
        type: 'radio',
        checked: e.key === s.searchEngine,
        click: () => setSetting('searchEngine', e.key),
      })),
    },
    {
      label: 'Appearance',
      submenu: [
        ['system', 'Match System'],
        ['light', 'Light'],
        ['dark', 'Dark'],
      ].map(([key, label]) => ({ label, type: 'radio', checked: s.appearance === key, click: () => setSetting('appearance', key) })),
    },
    {
      label: isDefaultBrowser() ? 'TP Browser Is Your Default Browser' : 'Make TP Browser the Default Browser…',
      enabled: !isDefaultBrowser(),
      click: () => makeDefaultBrowser(),
    },
    { label: 'Import Bookmarks…', click: () => openInternal(w, 'tp://settings/#import') },
    { label: 'Clear Browsing Data…', click: () => clearBrowsingData(w) },
    { type: 'separator' },
    { label: 'Settings…', accelerator: 'CmdOrCtrl+,', click: () => openInternal(w, 'tp://settings/') },
    { label: 'Check for Updates…', click: () => checkForUpdates(true) },
    { label: 'About TP Browser', click: () => app.showAboutPanel() },
  ];
}

function buildAppMenuSoon() {
  clearTimeout(menuTimer);
  menuTimer = setTimeout(buildAppMenu, 150);
}

function buildAppMenu() {
  if (!settings) return;
  const act = (fn) => () => {
    const w = currentWindow();
    if (w) fn(w);
  };
  const tabAct = (fn) => act((w) => w.activeTab && w.activeTab.alive && fn(w.activeTab, w));
  const popupOr = (popupFn, fn) => () => {
    const p = focusedPopup();
    if (p) popupFn(p);
    else act(fn)();
  };
  const s = publicSettings();
  const w0 = currentWindow();

  const hidden = (label, accelerator, click) => ({ label, accelerator, visible: false, acceleratorWorksWhenHidden: true, click });
  const tabSelectors = [];
  for (let i = 1; i <= 8; i++) tabSelectors.push(hidden(`Select Tab ${i}`, `CmdOrCtrl+${i}`, act((w) => w.selectTabIndex(i - 1))));

  // Bookmarks grouped by folder.
  const byFolder = new Map();
  for (const b of bookmarks.data.slice(0, 400)) {
    const f = b.folder || '';
    if (!byFolder.has(f)) byFolder.set(f, []);
    byFolder.get(f).push(b);
  }
  const bmItem = (b) => ({
    label: (b.title || b.url).length > 60 ? (b.title || b.url).slice(0, 60) + '…' : b.title || b.url,
    click: () => {
      const w = currentWindow();
      if (w && w.activeTab) w.activeTab.load(b.url);
      else new TPWindow({ urls: [b.url] });
    },
  });
  const bookmarkItems = [];
  for (const b of byFolder.get('') || []) bookmarkItems.push(bmItem(b));
  for (const [folder, list] of byFolder) {
    if (folder) bookmarkItems.push({ label: `📁 ${folder}`, submenu: list.slice(0, 200).map(bmItem) });
  }

  const template = [
    ...(IS_MAC
      ? [
          {
            label: app.name,
            submenu: [
              { label: 'About TP Browser', click: () => app.showAboutPanel() },
              { label: 'Check for Updates…', click: () => checkForUpdates(true) },
              { type: 'separator' },
              { label: 'Settings…', accelerator: 'CmdOrCtrl+,', click: () => openInternal(currentWindow(), 'tp://settings/') },
              {
                label: isDefaultBrowser() ? 'TP Browser Is Your Default Browser' : 'Make TP Browser the Default Browser…',
                enabled: !isDefaultBrowser(),
                click: () => makeDefaultBrowser(),
              },
              { label: 'Import Bookmarks…', click: () => openInternal(currentWindow(), 'tp://settings/#import') },
              { type: 'separator' },
              { label: 'Clear Browsing Data…', accelerator: 'CmdOrCtrl+Shift+Backspace', click: () => clearBrowsingData(currentWindow()) },
              { type: 'separator' },
              { role: 'services' },
              { type: 'separator' },
              { role: 'hide' },
              { role: 'hideOthers' },
              { role: 'unhide' },
              { type: 'separator' },
              { role: 'quit' },
            ],
          },
        ]
      : []),
    {
      label: 'File',
      submenu: [
        { label: 'New Tab', accelerator: 'CmdOrCtrl+T', click: () => newTab() },
        { label: 'New Window', accelerator: 'CmdOrCtrl+N', click: () => new TPWindow({ spaceId: w0 ? w0.activeSpaceId : null }) },
        { label: 'Reopen Closed Tab', accelerator: 'CmdOrCtrl+Shift+T', click: act((w) => w.reopenClosedTab()) },
        { type: 'separator' },
        { label: 'Open Location…', accelerator: 'CmdOrCtrl+L', click: act((w) => w.openOverlay('current')) },
        { label: 'Command Bar…', accelerator: 'CmdOrCtrl+K', click: act((w) => w.openOverlay('commands')) },
        { type: 'separator' },
        { label: 'Take Screenshot', accelerator: 'CmdOrCtrl+Shift+2', click: act((w) => takeScreenshot(w)) },
        { type: 'separator' },
        {
          label: 'Close Tab',
          accelerator: 'CmdOrCtrl+W',
          click: popupOr((p) => p.close(), (w) => {
            if (w.overlayOpen) w.closeOverlay();
            else if (w.activeTab) w.closeTab(w.activeTab);
          }),
        },
        { label: 'Close Window', accelerator: 'CmdOrCtrl+Shift+W', click: popupOr((p) => p.close(), (w) => w.win.close()) },
        ...(IS_MAC ? [] : [{ type: 'separator' }, { role: 'quit' }]),
      ],
    },
    {
      label: 'Edit',
      submenu: [
        { role: 'undo' },
        { role: 'redo' },
        { type: 'separator' },
        { role: 'cut' },
        { role: 'copy' },
        { role: 'paste' },
        { role: 'pasteAndMatchStyle' },
        { role: 'delete' },
        { role: 'selectAll' },
        { type: 'separator' },
        { label: 'Copy Page Link', accelerator: 'CmdOrCtrl+Shift+C', click: act((w) => copyUrl(w)) },
        { type: 'separator' },
        { label: 'Find…', accelerator: 'CmdOrCtrl+F', click: act((w) => w.sendUi('command', { name: 'find-open' })) },
        { label: 'Find Next', accelerator: 'CmdOrCtrl+G', click: act((w) => w.sendUi('command', { name: 'find-next' })) },
        { label: 'Find Previous', accelerator: 'CmdOrCtrl+Shift+G', click: act((w) => w.sendUi('command', { name: 'find-prev' })) },
      ],
    },
    {
      label: 'View',
      submenu: [
        {
          label: w0 && w0.sidebarCollapsed ? 'Show Sidebar' : 'Hide Sidebar',
          accelerator: 'Ctrl+Cmd+S',
          click: act((w) => w.toggleSidebar()),
        },
        {
          label: w0 && w0.split ? 'Exit Split View' : 'Split View',
          click: act((w) => (w.split ? w.exitSplit() : w.splitWith(null))),
        },
        { type: 'separator' },
        { label: 'Reload Page', accelerator: 'CmdOrCtrl+R', click: popupOr((p) => p.webContents.reload(), (w) => reload(w, false)) },
        { label: 'Force Reload', accelerator: 'CmdOrCtrl+Shift+R', click: act((w) => reload(w, true)) },
        { label: 'Stop', accelerator: 'CmdOrCtrl+.', click: tabAct((t) => t.wc.stop()) },
        { type: 'separator' },
        { label: 'Actual Size', accelerator: 'CmdOrCtrl+0', click: act((w) => zoom(w, 0)) },
        { label: 'Zoom In', accelerator: 'CmdOrCtrl+Plus', click: act((w) => zoom(w, 1)) },
        hidden('Zoom In', 'CmdOrCtrl+=', act((w) => zoom(w, 1))),
        { label: 'Zoom Out', accelerator: 'CmdOrCtrl+-', click: act((w) => zoom(w, -1)) },
        { type: 'separator' },
        { label: 'TP AI', accelerator: 'CmdOrCtrl+J', click: act((w) => w.sendUi('command', { name: 'ai-toggle' })) },
        { label: 'Reader View', accelerator: 'Alt+CmdOrCtrl+R', click: act((w) => w.sendUi('command', { name: 'reader' })) },
        { label: 'Listen to This Page', click: act((w) => w.sendUi('command', { name: 'reader', listen: true })) },
        {
          label: 'Translate Page',
          submenu: [
            { label: 'Show Original', click: act((w) => translatePage(w, 'original')) },
            { type: 'separator' },
            ...TRANSLATE_LANGS.map(([code, name]) => ({ label: name, click: act((w) => translatePage(w, code)) })),
          ],
        },
        {
          label: 'Dark Mode for Websites',
          type: 'checkbox',
          checked: !!settings.data.darkPages,
          click: () => setSetting('darkPages', !settings.data.darkPages),
        },
        { label: 'Share with QR Code…', click: act((w) => w.sendUi('command', { name: 'qr' })) },
        { type: 'separator' },
        { label: 'Picture in Picture', accelerator: 'Alt+CmdOrCtrl+P', click: act((w) => pictureInPicture(w)) },
        { role: 'togglefullscreen' },
        { type: 'separator' },
        {
          label: 'Developer Tools',
          accelerator: 'Alt+CmdOrCtrl+I',
          click: popupOr((p) => p.webContents.toggleDevTools(), (w) => w.activeTab && w.activeTab.alive && w.activeTab.wc.toggleDevTools()),
        },
      ],
    },
    {
      label: 'History',
      submenu: [
        {
          label: 'Back',
          accelerator: 'CmdOrCtrl+[',
          click: popupOr((p) => navOf(p.webContents).goBack(), (w) => w.activeTab && w.activeTab.alive && navOf(w.activeTab.wc).goBack()),
        },
        {
          label: 'Forward',
          accelerator: 'CmdOrCtrl+]',
          click: popupOr((p) => navOf(p.webContents).goForward(), (w) => w.activeTab && w.activeTab.alive && navOf(w.activeTab.wc).goForward()),
        },
        { label: 'Home', accelerator: 'CmdOrCtrl+Shift+H', click: act((w) => w.activeTab && w.activeTab.load(NEW_TAB_URL)) },
        { type: 'separator' },
        { label: 'Show All History', accelerator: 'CmdOrCtrl+Y', click: () => openHistory(currentWindow()) },
        { label: 'Clear Browsing Data…', click: () => clearBrowsingData(currentWindow()) },
      ],
    },
    {
      label: 'Bookmarks',
      submenu: [
        { label: 'Bookmark This Page', accelerator: 'CmdOrCtrl+D', click: act((w) => toggleBookmark(w)) },
        { label: 'Import Bookmarks…', click: () => openInternal(currentWindow(), 'tp://settings/#import') },
        { type: 'separator' },
        ...(bookmarkItems.length ? bookmarkItems : [{ label: 'No Bookmarks Yet', enabled: false }]),
      ],
    },
    {
      label: 'Spaces',
      submenu: [
        ...spaces().map((sp, i) => ({
          label: `${sp.icon}  ${sp.name}`,
          type: 'radio',
          checked: !!w0 && w0.activeSpaceId === sp.id,
          accelerator: i < 9 ? `Ctrl+${i + 1}` : undefined,
          click: act((w) => w.switchSpace(sp.id)),
        })),
        { type: 'separator' },
        { label: 'Next Space', accelerator: 'Ctrl+Cmd+Right', click: act((w) => w.cycleSpace(1)) },
        { label: 'Previous Space', accelerator: 'Ctrl+Cmd+Left', click: act((w) => w.cycleSpace(-1)) },
        { type: 'separator' },
        { label: 'New Space', click: act((w) => newSpace(w)) },
      ],
    },
    {
      label: 'Focus',
      submenu: focusState()
        ? [
            { label: 'Add 5 Minutes', click: () => extendFocus(5) },
            { label: 'End Focus Session', click: () => endFocus({ completed: false }) },
          ]
        : [
            ...[15, 25, 45, 60].map((m) => ({ label: `Start ${m}-Minute Session`, click: () => startFocus(m) })),
            { type: 'separator' },
            { label: 'Choose Distracting Sites…', click: () => openInternal(currentWindow(), 'tp://settings/#focus') },
          ],
    },
    {
      label: 'Window',
      role: 'window',
      submenu: [
        { role: 'minimize' },
        { role: 'zoom' },
        { type: 'separator' },
        { label: 'Next Tab', accelerator: 'Alt+CmdOrCtrl+Down', click: act((w) => w.cycleTab(1)) },
        { label: 'Previous Tab', accelerator: 'Alt+CmdOrCtrl+Up', click: act((w) => w.cycleTab(-1)) },
        hidden('Next Tab', 'Ctrl+Tab', act((w) => w.cycleTab(1))),
        hidden('Previous Tab', 'Ctrl+Shift+Tab', act((w) => w.cycleTab(-1))),
        hidden('Next Tab', 'CmdOrCtrl+Shift+]', act((w) => w.cycleTab(1))),
        hidden('Previous Tab', 'CmdOrCtrl+Shift+[', act((w) => w.cycleTab(-1))),
        ...tabSelectors,
        hidden('Select Last Tab', 'CmdOrCtrl+9', act((w) => w.selectTabIndex(-1))),
        { type: 'separator' },
        ...(IS_MAC ? [{ role: 'front' }] : []),
      ],
    },
  ];

  Menu.setApplicationMenu(Menu.buildFromTemplate(template));

  if (IS_MAC && app.dock) {
    app.dock.setMenu(
      Menu.buildFromTemplate([
        { label: 'New Window', click: () => new TPWindow() },
        { label: 'New Tab', click: () => newTab() },
      ])
    );
  }
}

// ---------------------------------------------------------------------------
// Background tab sleeping
// ---------------------------------------------------------------------------

function sleepIdleTabs() {
  const minutes = settings.data.sleepAfter;
  if (!minutes) return;
  const cutoff = Date.now() - minutes * 60000;
  for (const w of windows.values()) {
    const visible = new Set(w.visibleTabs());
    if (w.covered && w.activeTab) visible.add(w.activeTab);
    for (const t of w.tabs) {
      if (t.alive && !visible.has(t) && !t.audible && t.lastActive < cutoff) t.sleep();
    }
  }
}

// ---------------------------------------------------------------------------
// Opening links from other apps / default browser
// ---------------------------------------------------------------------------

function openFromOutside(url) {
  if (!startupDone) {
    pendingOpen.push(url);
    return;
  }
  const w = currentWindow();
  if (w) {
    w.addTab(url);
    if (w.win.isMinimized()) w.win.restore();
    w.win.show();
    w.win.focus();
  } else {
    new TPWindow({ urls: [url] });
  }
}

app.on('will-finish-launching', () => {
  app.on('open-url', (event, url) => {
    event.preventDefault();
    if (util.isHttpUrl(url)) openFromOutside(url);
  });
  app.on('open-file', (event, file) => {
    event.preventDefault();
    openFromOutside(pathToFileURL(file).href);
  });
});

// ---------------------------------------------------------------------------
// Startup & shutdown
// ---------------------------------------------------------------------------

function saveSession() {
  if (!sessionStore) return;
  clearTimeout(sessionTimer);
  const open = [...windows.values()].filter((w) => !w.win.isDestroyed() && w.tabs.length);
  sessionStore.data = { version: 2, windows: open.map((w) => w.snapshot()) };
  sessionStore.save();
}

function saveSessionSoon() {
  if (!startupDone) return;
  clearTimeout(sessionTimer);
  sessionTimer = setTimeout(() => {
    if (windows.size) saveSession();
  }, 1500);
}

function restorableWindows() {
  const list = settings.data.restoreTabs && Array.isArray(sessionStore.data.windows) ? sessionStore.data.windows : [];
  return list
    .map((w) => {
      if (!w || !Array.isArray(w.tabs)) return null;
      // Sessions from TP Browser 1.x stored plain URL strings.
      const tabs = w.tabs
        .map((t) => (typeof t === 'string' ? { url: t } : t))
        .filter((t) => t && typeof t.url === 'string' && (/^(https?|file):/i.test(t.url) || OPENABLE_TP.test(t.url)));
      return tabs.length ? { ...w, tabs } : null;
    })
    .filter(Boolean);
}

app.whenReady().then(() => {
  const dir = app.getPath('userData');
  settings = new util.JsonStore(path.join(dir, 'settings.json'), DEFAULT_SETTINGS);
  bookmarks = new util.JsonStore(path.join(dir, 'bookmarks.json'), []);
  historyStore = new util.JsonStore(path.join(dir, 'history.json'), []);
  sessionStore = new util.JsonStore(path.join(dir, 'session.json'), { windows: [] });
  stats = new util.JsonStore(path.join(dir, 'stats.json'), { blocked: {}, focus: {}, sessions: 0 });
  favicons = new util.JsonStore(path.join(dir, 'favicons.json'), {});
  refreshBookmarkSet();
  if (!stats.data.blocked || typeof stats.data.blocked !== 'object') stats.data.blocked = {};
  if (!stats.data.focus || typeof stats.data.focus !== 'object') stats.data.focus = {};
  for (const key of ['shieldAllow', 'focusSites']) if (!Array.isArray(settings.data[key])) settings.data[key] = DEFAULT_SETTINGS[key];
  if (!Array.isArray(settings.data.spaces) || !settings.data.spaces.length) settings.data.spaces = DEFAULT_SPACES;

  nativeTheme.themeSource = settings.data.appearance || 'system';

  for (const key of ['darkExcept']) if (!Array.isArray(settings.data[key])) settings.data[key] = [];

  // "Update completed": the first start of a new version shows what's new.
  const lastRun = settings.data.lastRunVersion || '';
  if (settings.data.onboarded && lastRun !== APP_VERSION) {
    // Versions before 2.2 didn't record this, so an empty value means "updated from 2.0 or 2.1".
    const from = lastRun || '2.0.0';
    const notes = notesSince(updater.versionCode(from) < updater.versionCode(APP_VERSION) ? from : '');
    if (notes.length) pendingWhatsNew = { version: APP_VERSION, from: lastRun, notes };
  }
  settings.data.lastRunVersion = APP_VERSION;
  settings.saveSoon();

  updates = updater.createUpdater({
    feedUrl: UPDATE_FEED,
    userData: app.getPath('userData'),
    codeVersion: APP_VERSION,
    electronVersion: process.versions.electron,
    builtInDir: (global.TP_CODE && global.TP_CODE.builtInDir) || path.join(__dirname, '..'),
    fetch: (u) => net.fetch(u, { headers: { 'User-Agent': `TPBrowser/${APP_VERSION} (Mac)` } }),
    onChange: onUpdateState,
  });

  app.setAboutPanelOptions({
    applicationName: 'TP Browser',
    applicationVersion: APP_VERSION,
    version: `Chromium ${process.versions.chrome}`,
    credits: 'Made by Tonpoon. Fast, private and focused, built on Chromium.',
    copyright: 'Copyright © 2026 Tonpoon',
  });

  const ses = session.defaultSession;
  setupTpProtocol(ses);
  setupPermissions(ses);
  setupDownloads(ses);
  setupShield(ses);
  setupIpc();
  buildAppMenu();

  // A focus session that ended while the app was closed.
  if (settings.data.focusStartedAt && !focusState()) endFocus({ completed: true, notify: false });
  scheduleFocusEnd();

  const restore = restorableWindows();
  if (!settings.data.onboarded) {
    new TPWindow({ urls: ['tp://welcome/'] });
  } else if (restore.length) {
    for (const r of restore) new TPWindow({ restore: r });
  } else if (!pendingOpen.length) {
    new TPWindow();
  }

  startupDone = true;
  for (const url of pendingOpen.splice(0)) openFromOutside(url);
  if (SMOKE_TEST) runSmokeTest();

  setInterval(sleepIdleTabs, 60 * 1000);
  if (!SMOKE_TEST && settings.data.autoUpdate !== false) scheduleUpdateChecks();

  app.on('activate', () => {
    if (windows.size === 0) new TPWindow();
  });
});

/** Build check: the sidebar and a tp:// page must both load and talk to the main process. */
function runSmokeTest() {
  const started = Date.now();
  const finish = (ok, detail) => {
    try {
      fs.writeFileSync(
        SMOKE_TEST,
        JSON.stringify({ ok, detail, electron: process.versions.electron, chrome: process.versions.chrome, ms: Date.now() - started })
      );
    } catch {
      /* nothing to report to */
    }
    app.exit(ok ? 0 : 1);
  };
  const poll = setInterval(() => {
    const w = currentWindow();
    const t = w && w.activeTab;
    if (w && w.pageRect && t && t.alive && !t.wc.isLoading() && smoke.internalCalls > 0) {
      clearInterval(poll);
      finish(true, `sidebar ${w.pageRect.width}x${w.pageRect.height}, page ${t.wc.getURL()}`);
    } else if (Date.now() - started > 30000) {
      clearInterval(poll);
      finish(false, `timeout: rect=${!!(w && w.pageRect)} tab=${!!(t && t.alive)} internal=${smoke.internalCalls}`);
    }
  }, 200);
  app.on('render-process-gone', (_e, _wc, details) => finish(false, 'renderer crashed: ' + details.reason));
}

app.on('before-quit', () => {
  quitting = true;
  saveSession();
  if (historyStore) historyStore.flush();
  if (stats) stats.save();
  if (favicons) favicons.flush();
  if (bookmarks) bookmarks.flush();
  if (settings) settings.flush();
});

app.on('window-all-closed', () => {
  if (!IS_MAC) app.quit();
});
