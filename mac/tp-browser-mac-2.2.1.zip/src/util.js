'use strict';
// Pure helpers with no Electron dependency, so they can be unit-tested with plain Node.

const fs = require('fs');
const path = require('path');

const SEARCH_ENGINES = {
  google: {
    name: 'Google',
    url: 'https://www.google.com/search?q=',
    suggest: 'https://suggestqueries.google.com/complete/search?client=firefox&q=',
  },
  duckduckgo: {
    name: 'DuckDuckGo',
    url: 'https://duckduckgo.com/?q=',
    suggest: 'https://duckduckgo.com/ac/?type=list&q=',
  },
  bing: {
    name: 'Bing',
    url: 'https://www.bing.com/search?q=',
    suggest: 'https://api.bing.com/osjson.aspx?query=',
  },
  brave: {
    name: 'Brave Search',
    url: 'https://search.brave.com/search?q=',
    suggest: 'https://search.brave.com/api/suggest?q=',
  },
};

const NEW_TAB_URL = 'tp://newtab/';

function searchUrl(query, engineKey) {
  const engine = SEARCH_ENGINES[engineKey] || SEARCH_ENGINES.google;
  return engine.url + encodeURIComponent(query);
}

/** True when the text looks like an address rather than a search. */
function looksLikeUrl(input) {
  const text = String(input || '').trim();
  if (!text || /\s/.test(text)) return false;
  if (/^(https?|file|tp):/i.test(text) || /^about:blank$/i.test(text)) return true;
  if (/^localhost(:\d+)?([/?#].*)?$/i.test(text)) return true;
  if (/^(\d{1,3}\.){3}\d{1,3}(:\d+)?([/?#].*)?$/.test(text)) return true;
  return /^[^\s/?#:]+\.[a-z¡-￿]{2,}(:\d+)?([/?#].*)?$/i.test(text);
}

/**
 * Turn whatever the user typed into a URL.
 * "example.com" -> https://example.com, "localhost:3000" -> http://localhost:3000,
 * "how tall is everest" -> a web search.
 */
function resolveInput(input, engineKey) {
  const text = String(input || '').trim();
  if (!text) return null;
  if (/^(https?|file|tp):/i.test(text)) return text;
  if (/^about:blank$/i.test(text)) return 'about:blank';
  if (/^localhost(:\d+)?([/?#].*)?$/i.test(text)) return 'http://' + text;
  if (/^(\d{1,3}\.){3}\d{1,3}(:\d+)?([/?#].*)?$/.test(text)) return 'http://' + text;
  if (looksLikeUrl(text)) return 'https://' + text;
  return searchUrl(text, engineKey);
}

/** Pick a file path that does not exist yet: "file.pdf", "file (1).pdf", ... */
function uniquePath(dir, filename, exists = fs.existsSync) {
  const safe = sanitizeFilename(filename) || 'download';
  const { name, ext } = path.parse(safe);
  let candidate = path.join(dir, safe);
  let n = 1;
  while (exists(candidate)) {
    candidate = path.join(dir, `${name} (${n})${ext}`);
    n += 1;
  }
  return candidate;
}

function sanitizeFilename(filename) {
  return String(filename || '')
    .replace(/[/\\:*?"<>|\u0000-\u001f]/g, '_')
    .replace(/^\.+/, '')
    .trim()
    .slice(0, 200);
}

/** Small JSON file store with atomic writes and a debounced save. */
class JsonStore {
  constructor(file, defaults) {
    this.file = file;
    this.data = defaults;
    this._timer = null;
    try {
      const parsed = JSON.parse(fs.readFileSync(file, 'utf8'));
      if (Array.isArray(defaults)) {
        if (Array.isArray(parsed)) this.data = parsed;
      } else if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
        this.data = { ...defaults, ...parsed };
      }
    } catch {
      // Missing or corrupt file: start from defaults.
    }
  }

  save() {
    clearTimeout(this._timer);
    this._timer = null;
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      const tmp = this.file + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(this.data, null, 2));
      fs.renameSync(tmp, this.file);
    } catch (err) {
      console.error('Could not save', this.file, err);
    }
  }

  saveSoon(ms = 800) {
    clearTimeout(this._timer);
    this._timer = setTimeout(() => this.save(), ms);
  }

  flush() {
    if (this._timer) this.save();
  }
}

function isHttpUrl(url) {
  return /^https?:\/\//i.test(String(url || ''));
}

/** Host including port, e.g. "localhost:3000". */
function hostOf(url) {
  try {
    return new URL(url).host;
  } catch {
    return '';
  }
}

/** Hostname without port, lower case. */
function hostnameOf(url) {
  try {
    return new URL(url).hostname.toLowerCase();
  } catch {
    return '';
  }
}

// Country-code second-level domains such as .co.th, .ac.th, .co.uk, .com.au.
const SECOND_LEVEL = new Set(['co', 'com', 'net', 'org', 'ac', 'go', 'or', 'gov', 'edu', 'in', 'mi', 'ne', 'gr']);

/** "news.bbc.co.uk" -> "bbc.co.uk", "a.b.example.com" -> "example.com". */
function rootDomain(host) {
  const h = String(host || '').toLowerCase().replace(/\.$/, '');
  if (!h || /^[\d.]+$/.test(h) || h.includes(':')) return h;
  const parts = h.split('.');
  if (parts.length <= 2) return h;
  const tld = parts[parts.length - 1];
  const sld = parts[parts.length - 2];
  if (tld.length === 2 && SECOND_LEVEL.has(sld)) return parts.slice(-3).join('.');
  return parts.slice(-2).join('.');
}

/** True if host is one of the domains in the list, or a subdomain of one. */
function hostInList(host, list) {
  const h = String(host || '').toLowerCase().replace(/^www\./, '');
  if (!h || !Array.isArray(list)) return false;
  return list.some((d) => h === d || h.endsWith('.' + d));
}

/** Clean up what a user typed as a site: "https://www.YouTube.com/watch" -> "youtube.com". */
function normalizeSite(input) {
  let s = String(input || '').trim().toLowerCase();
  if (!s) return '';
  s = s.replace(/^[a-z]+:\/\//, '').replace(/[/?#].*$/, '').replace(/:\d+$/, '').replace(/^www\./, '').replace(/\.$/, '');
  if (!/^[a-z0-9.-]+\.[a-z]{2,}$|^localhost$/.test(s)) return '';
  return s;
}

/** Read bookmarks from a Chrome/Brave/Edge "Bookmarks" JSON file. */
function parseChromiumBookmarks(json) {
  const out = [];
  let data;
  try {
    data = typeof json === 'string' ? JSON.parse(json) : json;
  } catch {
    return out;
  }
  if (!data || !data.roots) return out;
  const walk = (node, folder, inBar, depth) => {
    if (!node || depth > 30) return;
    if (node.type === 'url') {
      if (isHttpUrl(node.url)) out.push({ title: String(node.name || '').slice(0, 300), url: node.url, folder, bar: inBar && depth === 1 });
      return;
    }
    if (Array.isArray(node.children)) {
      const name = depth === 0 ? '' : String(node.name || '');
      for (const child of node.children) walk(child, depth === 0 ? '' : folder ? `${folder} / ${name}` : name, inBar, depth + 1);
    }
  };
  walk(data.roots.bookmark_bar, '', true, 0);
  walk(data.roots.other, '', false, 0);
  walk(data.roots.synced, '', false, 0);
  return out;
}

/** "2026-10-25" in local time. */
function dayKey(date = new Date()) {
  const d = new Date(date);
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}-${m}-${day}`;
}

function sumLastDays(byDay, days, now = new Date()) {
  let total = 0;
  for (let i = 0; i < days; i++) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    total += Number((byDay || {})[dayKey(d)] || 0);
  }
  return total;
}

function pruneDays(byDay, keep = 60, now = new Date()) {
  const cutoff = new Date(now);
  cutoff.setDate(cutoff.getDate() - keep);
  const min = dayKey(cutoff);
  for (const k of Object.keys(byDay || {})) if (k < min) delete byDay[k];
  return byDay;
}

module.exports = {
  SEARCH_ENGINES,
  NEW_TAB_URL,
  searchUrl,
  looksLikeUrl,
  resolveInput,
  uniquePath,
  sanitizeFilename,
  JsonStore,
  isHttpUrl,
  hostOf,
  hostnameOf,
  rootDomain,
  hostInList,
  normalizeSite,
  parseChromiumBookmarks,
  dayKey,
  sumLastDays,
  pruneDays,
};
